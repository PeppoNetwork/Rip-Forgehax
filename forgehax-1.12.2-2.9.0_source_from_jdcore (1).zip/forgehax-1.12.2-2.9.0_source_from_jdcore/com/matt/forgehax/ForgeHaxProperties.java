package com.matt.forgehax;

import com.google.common.base.Strings;
import java.util.Properties;





public class ForgeHaxProperties
{
  private static final Properties CONFIG_PROPERTIES = new Properties();
  







  public ForgeHaxProperties() {}
  






  public static Properties getConfigProperties()
  {
    return CONFIG_PROPERTIES;
  }
  
  public static String getVersion() {
    return Strings.nullToEmpty(getConfigProperties().getProperty("forgehax.version"));
  }
  
  public static String getMcVersion() {
    return Strings.nullToEmpty(getConfigProperties().getProperty("forgehax.mc.version"));
  }
  
  public static String getForgeVersion() {
    return Strings.nullToEmpty(getConfigProperties().getProperty("forgehax.forge.version"));
  }
  
  public static String getMcpVersion() {
    return Strings.nullToEmpty(getConfigProperties().getProperty("forgehax.mcp.version"));
  }
  
  public static String getMcpChannel() {
    return Strings.nullToEmpty(getConfigProperties().getProperty("forgehax.mcp.channel"));
  }
  
  public static String getMcpMapping() {
    return Strings.nullToEmpty(getConfigProperties().getProperty("forgehax.mcp.mapping"));
  }
  
  public static String getMcpMappingUrl() {
    return String.format("%s_%s_%s", new Object[] { getMcpVersion(), getMcpChannel(), getMcpMapping() });
  }
  
  /* Error */
  static
  {
    // Byte code:
    //   0: new 25	java/util/Properties
    //   3: dup
    //   4: invokespecial 68	java/util/Properties:<init>	()V
    //   7: putstatic 17	com/matt/forgehax/ForgeHaxProperties:CONFIG_PROPERTIES	Ljava/util/Properties;
    //   10: aconst_null
    //   11: astore_0
    //   12: ldc 2
    //   14: invokevirtual 74	java/lang/Class:getClassLoader	()Ljava/lang/ClassLoader;
    //   17: ldc 76
    //   19: invokevirtual 82	java/lang/ClassLoader:getResourceAsStream	(Ljava/lang/String;)Ljava/io/InputStream;
    //   22: astore_0
    //   23: getstatic 17	com/matt/forgehax/ForgeHaxProperties:CONFIG_PROPERTIES	Ljava/util/Properties;
    //   26: aload_0
    //   27: invokevirtual 86	java/util/Properties:load	(Ljava/io/InputStream;)V
    //   30: aload_0
    //   31: ifnull +45 -> 76
    //   34: aload_0
    //   35: invokevirtual 91	java/io/InputStream:close	()V
    //   38: goto +38 -> 76
    //   41: astore_1
    //   42: goto +34 -> 76
    //   45: astore_1
    //   46: aload_0
    //   47: ifnull +29 -> 76
    //   50: aload_0
    //   51: invokevirtual 91	java/io/InputStream:close	()V
    //   54: goto +22 -> 76
    //   57: astore_1
    //   58: goto +18 -> 76
    //   61: astore_2
    //   62: aload_0
    //   63: ifnull +11 -> 74
    //   66: aload_0
    //   67: invokevirtual 91	java/io/InputStream:close	()V
    //   70: goto +4 -> 74
    //   73: astore_3
    //   74: aload_2
    //   75: athrow
    //   76: return
    // Line number table:
    //   Java source line #12	-> byte code offset #0
    //   Java source line #15	-> byte code offset #10
    //   Java source line #17	-> byte code offset #12
    //   Java source line #18	-> byte code offset #23
    //   Java source line #21	-> byte code offset #30
    //   Java source line #23	-> byte code offset #34
    //   Java source line #25	-> byte code offset #38
    //   Java source line #24	-> byte code offset #41
    //   Java source line #25	-> byte code offset #42
    //   Java source line #19	-> byte code offset #45
    //   Java source line #21	-> byte code offset #46
    //   Java source line #23	-> byte code offset #50
    //   Java source line #25	-> byte code offset #54
    //   Java source line #24	-> byte code offset #57
    //   Java source line #25	-> byte code offset #58
    //   Java source line #21	-> byte code offset #61
    //   Java source line #23	-> byte code offset #66
    //   Java source line #25	-> byte code offset #70
    //   Java source line #24	-> byte code offset #73
    //   Java source line #27	-> byte code offset #74
    //   Java source line #28	-> byte code offset #76
    // Local variable table:
    //   start	length	slot	name	signature
    //   11	56	0	input	java.io.InputStream
    //   41	1	1	localThrowable	Throwable
    //   45	1	1	localThrowable1	Throwable
    //   57	1	1	localThrowable2	Throwable
    //   61	14	2	localObject	Object
    //   73	1	3	localThrowable3	Throwable
    // Exception table:
    //   from	to	target	type
    //   34	38	41	java/lang/Throwable
    //   12	30	45	java/lang/Throwable
    //   50	54	57	java/lang/Throwable
    //   12	30	61	finally
    //   66	70	73	java/lang/Throwable
  }
}
