package com.matt.forgehax.gui;

import com.google.common.collect.Lists;
import com.matt.forgehax.Globals;
import com.matt.forgehax.gui.windows.GuiWindow;
import com.matt.forgehax.gui.windows.GuiWindowMod;
import com.matt.forgehax.util.mod.Category;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraftforge.client.event.GuiScreenEvent.InitGuiEvent.Post;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Mouse;


public class ClickGui
  extends GuiScreen
  implements Globals
{
  private static ClickGui INSTANCE;
  public final List<GuiWindow> windowList = new ArrayList();
  
  private GuiWindowMod combatWindow = new GuiWindowMod(Category.COMBAT);
  private GuiWindowMod playerWindow = new GuiWindowMod(Category.PLAYER);
  private GuiWindowMod renderWindow = new GuiWindowMod(Category.RENDER);
  private GuiWindowMod worldWindow = new GuiWindowMod(Category.WORLD);
  private GuiWindowMod miscWindow = new GuiWindowMod(Category.MISC);
  








  public static ScaledResolution scaledRes = new ScaledResolution(MC);
  public int baseColor;
  
  private ClickGui()
  {
    windowList.add(combatWindow);
    windowList.add(playerWindow);
    windowList.add(renderWindow);
    windowList.add(worldWindow);
    windowList.add(miscWindow);
    









    for (int i = 0; i < windowList.size(); i++)
    {

      int x = (i + 1) * scaledRes.func_78326_a() / (windowList.size() + 1) - windowList.get(i)).width / 2 - 10;
      
      int y = scaledRes.func_78328_b() / 15;
      ((GuiWindow)windowList.get(i)).setPosition(x, y);
    }
  }
  
  public static ClickGui getInstance() {
    return INSTANCE == null ? (ClickGui.INSTANCE = new ClickGui()) : INSTANCE;
  }
  
  public boolean func_73868_f()
  {
    return false;
  }
  
  @SubscribeEvent
  public void onScreenUpdated(GuiScreenEvent.InitGuiEvent.Post ev) {
    scaledRes = new ScaledResolution(MC);
  }
  
  public void moveWindowToTop(GuiWindow window) {
    if (windowList.remove(window))
    {
      windowList.add(window);
    }
  }
  
  public boolean isMouseInWindow(int mouseX, int mouseY, GuiWindow window) {
    return (mouseX > posX) && (mouseX < bottomX) && (mouseY > headerY) && (mouseY < bottomY);
  }
  


  public void func_73863_a(int mouseX, int mouseY, float partialTicks)
  {
    for (GuiWindow window : windowList) {
      window.drawWindow(mouseX, mouseY);
    }
    
    for (GuiWindow window : windowList) {
      window.drawTooltip(mouseX, mouseY);
    }
  }
  
  public void func_73864_a(int mouseX, int mouseY, int b) throws IOException {
    try {
      for (GuiWindow window : Lists.reverse(windowList)) {
        if (isMouseInWindow(mouseX, mouseY, window)) {
          window.mouseClicked(mouseX, mouseY, b);
          moveWindowToTop(window);
          return;
        }
      }
      super.func_73864_a(mouseX, mouseY, b);
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
  
  public void func_146286_b(int x, int y, int state) {
    for (GuiWindow window : windowList) {
      window.mouseReleased(x, y, state);
    }
    super.func_146286_b(x, y, state);
  }
  
  public void func_73869_a(char typedChar, int keyCode) throws IOException {
    super.func_73869_a(typedChar, keyCode);
    for (GuiWindow window : windowList) {
      window.keyTyped(typedChar, keyCode);
    }
  }
  
  public void func_146274_d() throws IOException
  {
    super.func_146274_d();
    
    int scale = scaledRes.func_78325_e();
    for (GuiWindow window : Lists.reverse(windowList)) {
      if (isMouseInWindow(
        Mouse.getEventX() / scale, (MCfield_71440_d - Mouse.getEventY()) / scale, window)) {
        window.handleMouseInput();
        break;
      }
    }
  }
}
