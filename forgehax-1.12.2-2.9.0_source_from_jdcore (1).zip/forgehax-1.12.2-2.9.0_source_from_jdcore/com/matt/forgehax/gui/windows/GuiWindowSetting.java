package com.matt.forgehax.gui.windows;

import com.matt.forgehax.gui.ClickGui;
import com.matt.forgehax.gui.elements.GuiElement;
import com.matt.forgehax.gui.elements.GuiTextInput;
import com.matt.forgehax.util.mod.BaseMod;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;



public class GuiWindowSetting
  extends GuiWindow
{
  public List<GuiElement> inputList = new ArrayList();
  
  private BaseMod mod;
  
  public GuiWindowSetting(BaseMod modIn, int x, int y)
  {
    super(modIn.getModName() + " Settings");
    mod = modIn;
    initializeInputs();
  }
  

  private void initializeInputs()
  {
    inputList.add(new GuiTextInput(null, this));
    height += 13;
  }
  
  public String getModName() {
    return mod.getModName();
  }
  
  public BaseMod getMod() {
    return mod;
  }
  
  public void drawWindow(int mouseX, int mouseY) {
    super.drawWindow(mouseX, mouseY);
    
    for (GuiElement input : inputList) {
      x = 2;
      y = (height + 2);
      width = width;
      input.draw(mouseX, mouseY);
    }
    

    bottomX = (posX + width);
    bottomY = (windowY + height);
  }
  
  public void keyTyped(char typedChar, int keyCode) throws IOException {
    for (GuiElement element : inputList) {
      element.keyTyped(typedChar, keyCode);
    }
  }
  
  public void mouseClicked(int x, int y, int state) {
    super.mouseClicked(x, y, state);
    if ((state == 2) && (isMouseInHeader(x, y))) {
      getInstancewindowList.remove(this);
    } else {
      for (GuiElement input : inputList)
      {
        input.mouseClicked(x, y, state);
      }
    }
  }
  
  public void mouseReleased(int x, int y, int state) {
    super.mouseReleased(x, y, state);
    for (GuiElement input : inputList) {
      input.mouseReleased(x, y, state);
    }
  }
}
