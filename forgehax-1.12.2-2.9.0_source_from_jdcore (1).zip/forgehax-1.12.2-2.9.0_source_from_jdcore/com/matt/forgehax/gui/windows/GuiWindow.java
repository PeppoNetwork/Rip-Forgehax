package com.matt.forgehax.gui.windows;

import com.matt.forgehax.Globals;
import com.matt.forgehax.gui.ClickGui;
import com.matt.forgehax.util.color.Color;
import com.matt.forgehax.util.color.Colors;
import com.matt.forgehax.util.draw.SurfaceHelper;
import java.io.IOException;
import net.minecraft.client.gui.ScaledResolution;










public abstract class GuiWindow
{
  public boolean isHidden;
  private String title;
  public int posX;
  public int headerY;
  public int windowY;
  public int bottomX;
  public int bottomY;
  private int dragX;
  private int dragY;
  private boolean dragging;
  final int maxHeight = (int)(ClickGui.scaledRes.func_78328_b() * 0.8D);
  public int width;
  public int height;
  
  GuiWindow(String titleIn) {
    title = titleIn;
    width = (SurfaceHelper.getTextWidth(title) + 15);
  }
  
  public void setPosition(int x, int y) {
    posX = x;
    headerY = y;
  }
  
  private String getTitle() {
    return title;
  }
  
  boolean isMouseInHeader(int mouseX, int mouseY) {
    return (mouseX > posX) && (mouseX < posX + width) && (mouseY > headerY) && (mouseY < headerY + 20);
  }
  


  public void mouseClicked(int mouseX, int mouseY, int state)
  {
    if (state != 0) {
      return;
    }
    if (isMouseInHeader(mouseX, mouseY)) {
      dragging = true;
      
      dragX = (mouseX - posX);
      dragY = (mouseY - headerY);
    }
  }
  
  public void mouseReleased(int x, int y, int state) {
    dragging = false;
  }
  
  public void handleMouseInput()
    throws IOException
  {}
  
  public void keyTyped(char typedChar, int keyCode) throws IOException
  {}
  
  public void drawWindow(int mouseX, int mouseY)
  {
    ClickGui.scaledRes = new ScaledResolution(Globals.MC);
    if (dragging) {
      posX = (mouseX - dragX);
      headerY = (mouseY - dragY);
    }
    drawHeader();
    windowY = (headerY + 21);
    SurfaceHelper.drawOutlinedRectShaded(posX, windowY, width, height, Colors.GRAY
      .toBuffer(), 80, 3.0F);
  }
  

  public void drawTooltip(int mouseX, int mouseY) {}
  
  public void drawHeader()
  {
    SurfaceHelper.drawOutlinedRectShaded(posX, headerY, width, 20, 
    
      Color.of(150, 150, 150, 255).toBuffer(), 50, 5.0F);
    SurfaceHelper.drawTextShadowCentered(
      getTitle(), posX + width / 2.0F, headerY + 10, Colors.WHITE.toBuffer());
  }
}
