package com.matt.forgehax.gui.elements;

import com.matt.forgehax.gui.windows.GuiWindowSetting;
import com.matt.forgehax.util.command.Setting;
import java.io.IOException;


public class GuiElement
{
  public GuiWindowSetting parentWindow;
  public int width;
  public int height;
  public int subX;
  public int subY;
  public int x;
  public int y;
  public Setting setting;
  
  public GuiElement(Setting settingIn, GuiWindowSetting parent)
  {
    parentWindow = parent;
    setting = settingIn;
  }
  
  public void mouseClicked(int x, int y, int state) {}
  
  public void mouseReleased(int x, int y, int state) {}
  
  public void keyTyped(char typedChar, int keyCode)
    throws IOException
  {}
  
  public void draw(int mouseX, int mouseY)
  {
    x = (getPosX() + subX + 1);
    y = (getPosY() + subY + 21);
  }
  
  public int getPosX() {
    return parentWindow.posX;
  }
  
  public int getPosY() {
    return parentWindow.headerY;
  }
  
  public boolean isMouseInElement(int mouseX, int mouseY) {
    return (mouseX > x) && (mouseX < x + width) && (mouseY > y) && (mouseY < y + height);
  }
}
