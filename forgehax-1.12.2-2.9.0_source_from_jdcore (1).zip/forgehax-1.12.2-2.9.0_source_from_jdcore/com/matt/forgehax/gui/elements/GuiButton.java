package com.matt.forgehax.gui.elements;

import com.matt.forgehax.util.color.Color;
import com.matt.forgehax.util.mod.BaseMod;





public class GuiButton
{
  private final BaseMod mod;
  private static final int COLOR_ENABLED = Color.of(65, 65, 65, 200).toBuffer();
  private static final int COLOR_DISABLED = Color.of(100, 100, 100, 150).toBuffer();
  public int width;
  public static final int height = 15;
  public int x;
  public int y;
  
  public GuiButton(BaseMod modIn)
  {
    mod = modIn;
  }
  
  public void setCoords(int xIn, int yIn) {
    x = xIn;
    y = yIn;
  }
  
  public boolean isModEnabled() {
    return mod.isEnabled();
  }
  
  public void toggleMod() {
    if (!mod.isEnabled()) {
      mod.enable();
    } else {
      mod.disable();
    }
  }
  
  public String getName() {
    return mod.getModName();
  }
  
  public BaseMod getMod() {
    return mod;
  }
  
  public int getColor() {
    return isModEnabled() ? COLOR_ENABLED : COLOR_DISABLED;
  }
}
