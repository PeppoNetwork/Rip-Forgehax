package com.matt.forgehax.gui.elements;

import com.matt.forgehax.Globals;
import com.matt.forgehax.gui.windows.GuiWindowSetting;
import com.matt.forgehax.util.color.Color;
import com.matt.forgehax.util.color.Colors;
import com.matt.forgehax.util.command.Setting;
import com.matt.forgehax.util.draw.SurfaceHelper;
import java.io.IOException;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.text.TextComponentString;


public class GuiTextInput
  extends GuiElement
{
  private final int blinkSpeed = 30;
  
  private int ticks;
  private boolean isActive;
  private int selectedIndex = -1;
  private StringBuilder input = new StringBuilder();
  
  public GuiTextInput(Setting settingIn, GuiWindowSetting parent) {
    super(settingIn, parent);
    height = 12;
  }
  
  public void mouseClicked(int mouseX, int mouseY, int state) {
    isActive = isMouseInElement(mouseX, mouseY);
  }
  
  public void keyTyped(char typedChar, int keyCode) throws IOException {
    if (isActive) {
      switch (keyCode) {
      case 1: 
        isActive = false;
        break;
      
      case 28: 
        isActive = false;
        
        MCfield_71439_g.func_145747_a(new TextComponentString(input.toString()));
        break;
      
      case 14: 
        if (selectedIndex > -1) {
          input.deleteCharAt(selectedIndex);
          selectedIndex -= 1;
        }
        
        break;
      case 203: 
        selectedIndex -= 1;
        break;
      
      case 205: 
        selectedIndex += 1;
        break;
      
      default: 
        if (isValidChar(typedChar)) {
          selectedIndex += 1;
          input.insert(selectedIndex, typedChar);
        }
        break; }
      selectedIndex = MathHelper.func_76125_a(selectedIndex, -1, input.length() - 1);
    }
  }
  
  public void draw(int mouseX, int mouseY) {
    super.draw(x, y);
    SurfaceHelper.drawRect(x, y, width - 2, height, Colors.WHITE.toBuffer());
    SurfaceHelper.drawOutlinedRect(x, y, width - 2, height, Colors.BLACK.toBuffer());
    if ((ticks % 30 * 2 > 30) && (isActive)) {
      int i = getBlinkWidth();
    }
    
    SurfaceHelper.drawText(getInputString(), x + 1, y + 2, Colors.BLACK.toBuffer());
    
    ticks += 1;
  }
  
  private int getBlinkWidth() {
    if (input.length() > 0) {
      return SurfaceHelper.getTextWidth(input.substring(0, selectedIndex + 1));
    }
    return 0;
  }
  
  private String getInputString()
  {
    return input.toString();
  }
  
  private boolean isValidChar(char charIn) {
    return !Character.isISOControl(charIn);
  }
  
  private void setValue(String in) {
    setting.set(in);
  }
}
