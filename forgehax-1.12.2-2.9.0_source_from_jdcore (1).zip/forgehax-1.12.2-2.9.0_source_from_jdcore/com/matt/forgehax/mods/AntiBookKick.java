package com.matt.forgehax.mods;

import com.matt.forgehax.Helper;
import com.matt.forgehax.asm.events.PacketEvent.Outgoing.Pre;
import com.matt.forgehax.util.mod.Category;
import com.matt.forgehax.util.mod.ToggleMod;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.inventory.Container;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemWrittenBook;
import net.minecraft.network.play.client.CPacketClickWindow;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@RegisterMod
public class AntiBookKick
  extends ToggleMod
{
  public AntiBookKick()
  {
    super(Category.MISC, "AntiBookKick", false, "Doesn't let you click on slots that have books");
  }
  
  @SubscribeEvent
  public void onPacket(PacketEvent.Outgoing.Pre event) {
    if (!(event.getPacket() instanceof CPacketClickWindow)) {
      return;
    }
    
    CPacketClickWindow packet = (CPacketClickWindow)event.getPacket();
    if (!(packet.func_149546_g().func_77973_b() instanceof ItemWrittenBook)) {
      return;
    }
    
    event.setCanceled(true);
    Helper.printInform("Don't press the book \"" + packet.func_149546_g().func_82833_r() + "\"!", new Object[0]);
    MCfield_71439_g.field_71070_bA.func_184996_a(packet.func_149544_d(), packet.func_149543_e(), packet.func_186993_f(), MCfield_71439_g);
  }
}
