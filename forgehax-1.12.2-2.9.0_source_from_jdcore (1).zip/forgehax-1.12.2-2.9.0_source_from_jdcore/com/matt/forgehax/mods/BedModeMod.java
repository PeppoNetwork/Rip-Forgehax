package com.matt.forgehax.mods;

import com.matt.forgehax.Helper;
import com.matt.forgehax.asm.reflection.FastReflection.Fields;
import com.matt.forgehax.asm.utils.fasttype.FastField;
import com.matt.forgehax.events.LocalPlayerUpdateEvent;
import com.matt.forgehax.util.mod.ToggleMod;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import net.minecraft.client.gui.GuiSleepMP;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@RegisterMod
public class BedModeMod extends ToggleMod
{
  public BedModeMod()
  {
    super(com.matt.forgehax.util.mod.Category.PLAYER, "BedMode", false, "Sleep walking");
  }
  
  @SubscribeEvent
  public void onLocalPlayerUpdate(LocalPlayerUpdateEvent event) {
    FastReflection.Fields.EntityPlayer_sleeping.set(Helper.getLocalPlayer(), Boolean.valueOf(false));
    FastReflection.Fields.EntityPlayer_sleepTimer.set(Helper.getLocalPlayer(), Integer.valueOf(0));
  }
  
  @SubscribeEvent
  public void onGuiUpdate(GuiOpenEvent event) {
    if ((event.getGui() instanceof GuiSleepMP)) {
      event.setCanceled(true);
    }
  }
}
