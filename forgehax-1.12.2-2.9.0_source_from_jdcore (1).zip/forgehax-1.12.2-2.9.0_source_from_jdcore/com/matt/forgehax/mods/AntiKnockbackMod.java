package com.matt.forgehax.mods;

import com.matt.forgehax.Helper;
import com.matt.forgehax.asm.events.ApplyCollisionMotionEvent;
import com.matt.forgehax.asm.events.EntityBlockSlipApplyEvent;
import com.matt.forgehax.asm.events.PacketEvent.Incoming.Pre;
import com.matt.forgehax.asm.events.PushOutOfBlocksEvent;
import com.matt.forgehax.asm.events.WaterMovementEvent;
import com.matt.forgehax.asm.reflection.FastReflection.Fields;
import com.matt.forgehax.asm.utils.fasttype.FastField;
import com.matt.forgehax.util.command.Command;
import com.matt.forgehax.util.command.CommandBuilders;
import com.matt.forgehax.util.command.Setting;
import com.matt.forgehax.util.command.SettingBuilder;
import com.matt.forgehax.util.math.VectorUtils;
import com.matt.forgehax.util.mod.Category;
import com.matt.forgehax.util.mod.ToggleMod;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.EntityFishHook;
import net.minecraft.network.Packet;
import net.minecraft.network.play.server.SPacketEntityStatus;
import net.minecraft.network.play.server.SPacketEntityVelocity;
import net.minecraft.network.play.server.SPacketExplosion;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;


@RegisterMod
public class AntiKnockbackMod
  extends ToggleMod
{
  private final Setting<Double> multiplier_x = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("x-multiplier")).description("Multiplier for X axis"))
    .defaultTo(Double.valueOf(0.0D))
    .build();
  





  private final Setting<Double> multiplier_y = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("y-multiplier")).description("Multiplier for Y axis"))
    .defaultTo(Double.valueOf(0.0D))
    .build();
  





  private final Setting<Double> multiplier_z = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("z-multiplier")).description("Multiplier for Z axis"))
    .defaultTo(Double.valueOf(0.0D))
    .build();
  





  private final Setting<Boolean> explosions = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("explosions")).description("Disable velocity from SPacketExplosion"))
    .defaultTo(Boolean.valueOf(true))
    .build();
  





  private final Setting<Boolean> velocity = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("velocity")).description("Disable velocity from SPacketEntityVelocity"))
    .defaultTo(Boolean.valueOf(true))
    .build();
  





  private final Setting<Boolean> fishhook = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("fishhook")).description("Disable velocity from a fishhook"))
    .defaultTo(Boolean.valueOf(true))
    .build();
  





  private final Setting<Boolean> water = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("water")).description("Disable velocity from flowing water"))
    .defaultTo(Boolean.valueOf(true))
    .build();
  





  private final Setting<Boolean> push = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("push")).description("Disable velocity from entity pushing"))
    .defaultTo(Boolean.valueOf(true))
    .build();
  





  private final Setting<Boolean> blocks = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("blocks")).description("Disable velocity from block pushing"))
    .defaultTo(Boolean.valueOf(true))
    .build();
  





  private final Setting<Boolean> slipping = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("slipping")).description("Disable velocity from ice slipping"))
    .defaultTo(Boolean.valueOf(true))
    .build();
  
  public AntiKnockbackMod() {
    super(Category.COMBAT, "AntiKnockback", false, "Removes knockback movement");
  }
  
  private Vec3d getMultiplier() {
    return new Vec3d(((Double)multiplier_x.get()).doubleValue(), ((Double)multiplier_y.get()).doubleValue(), ((Double)multiplier_z.get()).doubleValue());
  }
  
  private Vec3d getPacketMotion(Packet<?> packet) {
    if ((packet instanceof SPacketExplosion))
      return new Vec3d(
        ((Float)FastReflection.Fields.SPacketExplosion_motionX.get(packet)).floatValue(), 
        ((Float)FastReflection.Fields.SPacketExplosion_motionY.get(packet)).floatValue(), 
        ((Float)FastReflection.Fields.SPacketExplosion_motionZ.get(packet)).floatValue());
    if ((packet instanceof SPacketEntityVelocity)) {
      return new Vec3d(
        ((Integer)FastReflection.Fields.SPacketEntityVelocity_motionX.get(packet)).intValue(), 
        ((Integer)FastReflection.Fields.SPacketEntityVelocity_motionY.get(packet)).intValue(), 
        ((Integer)FastReflection.Fields.SPacketEntityVelocity_motionZ.get(packet)).intValue());
    }
    throw new IllegalArgumentException();
  }
  
  private void setPacketMotion(Packet<?> packet, Vec3d in)
  {
    if ((packet instanceof SPacketExplosion)) {
      FastReflection.Fields.SPacketExplosion_motionX.set(packet, Float.valueOf((float)field_72450_a));
      FastReflection.Fields.SPacketExplosion_motionY.set(packet, Float.valueOf((float)field_72448_b));
      FastReflection.Fields.SPacketExplosion_motionZ.set(packet, Float.valueOf((float)field_72449_c));
    } else if ((packet instanceof SPacketEntityVelocity)) {
      FastReflection.Fields.SPacketEntityVelocity_motionX.set(packet, Integer.valueOf((int)Math.round(field_72450_a)));
      FastReflection.Fields.SPacketEntityVelocity_motionY.set(packet, Integer.valueOf((int)Math.round(field_72448_b)));
      FastReflection.Fields.SPacketEntityVelocity_motionZ.set(packet, Integer.valueOf((int)Math.round(field_72449_c)));
    } else {
      throw new IllegalArgumentException();
    }
  }
  
  private void addEntityVelocity(Entity in, Vec3d velocity) {
    field_70159_w += field_72450_a;
    field_70181_x += field_72448_b;
    field_70179_y += field_72449_c;
  }
  


  @SubscribeEvent
  public void onPacketRecieved(PacketEvent.Incoming.Pre event)
  {
    if ((Helper.getLocalPlayer() == null) || (Helper.getWorld() == null))
      return;
    if ((((Boolean)explosions.get()).booleanValue()) && ((event.getPacket() instanceof SPacketExplosion))) {
      Vec3d multiplier = getMultiplier();
      Vec3d motion = getPacketMotion(event.getPacket());
      setPacketMotion(event.getPacket(), VectorUtils.multiplyBy(motion, multiplier));
    } else if ((((Boolean)velocity.get()).booleanValue()) && ((event.getPacket() instanceof SPacketEntityVelocity)))
    {
      if (((SPacketEntityVelocity)event.getPacket()).func_149412_c() == Helper.getLocalPlayer().func_145782_y()) {
        Vec3d multiplier = getMultiplier();
        if (multiplier.func_189985_c() > 0.0D) {
          setPacketMotion(event
            .getPacket(), 
            VectorUtils.multiplyBy(getPacketMotion(event.getPacket()), multiplier));
        } else {
          event.setCanceled(true);
        }
      }
    } else if ((((Boolean)fishhook.get()).booleanValue()) && ((event.getPacket() instanceof SPacketEntityStatus)))
    {

      SPacketEntityStatus packet = (SPacketEntityStatus)event.getPacket();
      switch (packet.func_149160_c()) {
      case 31: 
        Entity offender = packet.func_149161_a(Helper.getWorld());
        if ((offender instanceof EntityFishHook)) {
          EntityFishHook hook = (EntityFishHook)offender;
          if (Helper.getLocalPlayer().equals(field_146043_c))
            event.setCanceled(true);
        }
        break;
      }
      
    }
  }
  





  @SubscribeEvent
  public void onWaterMovementEvent(WaterMovementEvent event)
  {
    if ((((Boolean)water.get()).booleanValue()) && (Helper.getLocalPlayer() != null) && (Helper.getLocalPlayer().equals(event.getEntity()))) {
      addEntityVelocity(event
        .getEntity(), 
        VectorUtils.multiplyBy(event.getMoveDir().func_72432_b().func_186678_a(0.014D), getMultiplier()));
      event.setCanceled(true);
    }
  }
  


  @SubscribeEvent
  public void onApplyCollisionMotion(ApplyCollisionMotionEvent event)
  {
    if ((((Boolean)push.get()).booleanValue()) && (Helper.getLocalPlayer() != null) && (Helper.getLocalPlayer().equals(event.getEntity()))) {
      addEntityVelocity(event
        .getEntity(), 
        VectorUtils.multiplyBy(new Vec3d(event
        .getMotionX(), event.getMotionY(), event.getMotionZ()), 
        getMultiplier()));
      event.setCanceled(true);
    }
  }
  
  @SubscribeEvent
  public void onPushOutOfBlocks(PushOutOfBlocksEvent event) {
    if (((Boolean)blocks.get()).booleanValue()) {
      event.setCanceled(true);
    }
  }
  
  @SubscribeEvent
  public void onBlockSlip(EntityBlockSlipApplyEvent event) {
    if ((((Boolean)slipping.get()).booleanValue()) && 
      (Helper.getLocalPlayer() != null) && 
      (Helper.getLocalPlayer().equals(event.getEntityLivingBase()))) {
      event.setSlipperiness(0.6F);
    }
  }
}
