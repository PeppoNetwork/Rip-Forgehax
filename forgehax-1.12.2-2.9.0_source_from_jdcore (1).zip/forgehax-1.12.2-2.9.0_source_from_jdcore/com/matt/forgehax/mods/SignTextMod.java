package com.matt.forgehax.mods;

import com.matt.forgehax.Helper;
import com.matt.forgehax.util.mod.ToggleMod;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.tileentity.TileEntitySign;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.RayTraceResult.Type;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.TextFormatting;
import net.minecraftforge.client.event.MouseEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Mouse;

@RegisterMod
public class SignTextMod extends ToggleMod
{
  public SignTextMod()
  {
    super(com.matt.forgehax.util.mod.Category.MISC, "SignText", false, "get sign text");
  }
  
  @SubscribeEvent
  public void onInput(MouseEvent event) {
    if ((event.getButton() == 2) && (Mouse.getEventButtonState())) {
      RayTraceResult result = MCfield_71439_g.func_174822_a(999.0D, 0.0F);
      if (result == null) {
        return;
      }
      if (field_72313_a == RayTraceResult.Type.BLOCK) {
        net.minecraft.tileentity.TileEntity tileEntity = MCfield_71441_e.func_175625_s(result.func_178782_a());
        
        if ((tileEntity instanceof TileEntitySign)) {
          TileEntitySign sign = (TileEntitySign)tileEntity;
          
          int signTextLength = 0;
          
          for (int i = 3; i >= 0; i--) {
            if (!field_145915_a[i].func_150260_c().isEmpty()) {
              signTextLength = i + 1;
              break;
            }
          }
          if (signTextLength == 0) {
            return;
          }
          
          String[] lines = new String[signTextLength];
          
          for (int i = 0; i < signTextLength; i++)
          {
            lines[i] = field_145915_a[i].func_150254_d().replace(TextFormatting.RESET.toString(), "");
          }
          
          String fullText = String.join("\n", lines);
          
          Helper.printMessage("Copied sign");
          setClipboardString(fullText);
        }
      }
    }
  }
  
  private static void setClipboardString(String stringIn) {
    StringSelection selection = new StringSelection(stringIn);
    Toolkit.getDefaultToolkit().getSystemClipboard().setContents(selection, null);
  }
}
