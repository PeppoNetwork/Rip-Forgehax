package com.matt.forgehax.mods;

import com.matt.forgehax.Helper;
import com.matt.forgehax.events.Render2DEvent;
import com.matt.forgehax.util.color.Color;
import com.matt.forgehax.util.color.Colors;
import com.matt.forgehax.util.command.Command;
import com.matt.forgehax.util.command.CommandBuilders;
import com.matt.forgehax.util.command.Setting;
import com.matt.forgehax.util.command.SettingBuilder;
import com.matt.forgehax.util.draw.SurfaceHelper;
import com.matt.forgehax.util.mod.Category;
import com.matt.forgehax.util.mod.ToggleMod;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;



@RegisterMod
public class CompassMod
  extends ToggleMod
{
  public final Setting<Double> scale = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("scale")).description("size of the compass"))
    .defaultTo(Double.valueOf(3.0D))
    .build();
  private static final double HALF_PI = 1.5707963267948966D;
  
  private static enum Direction
  {
    N, 
    W, 
    S, 
    E;
    
    private Direction() {} }
  
  public CompassMod() { super(Category.RENDER, "Compass", false, "cool compass overlay"); }
  
  @SubscribeEvent
  public void onRender(Render2DEvent event)
  {
    double centerX = event.getScreenWidth() / 2.0D;
    double centerY = event.getScreenHeight() * 0.8D;
    
    for (Direction dir : Direction.values()) {
      double rad = getPosOnCompass(dir);
      SurfaceHelper.drawTextShadowCentered(dir
        .name(), 
        (float)(centerX + getX(rad)), 
        (float)(centerY + getY(rad)), dir == Direction.N ? Colors.RED
        .toBuffer() : Colors.WHITE.toBuffer());
    }
  }
  

  private double getX(double rad)
  {
    return Math.sin(rad) * (scale.getAsDouble() * 10.0D);
  }
  
  private double getY(double rad)
  {
    double epicPitch = MathHelper.func_76131_a(getRenderEntityfield_70125_A + 30.0F, -90.0F, 90.0F);
    double pitchRadians = Math.toRadians(epicPitch);
    return Math.cos(rad) * Math.sin(pitchRadians) * (scale.getAsDouble() * 10.0D);
  }
  

  private static double getPosOnCompass(Direction dir)
  {
    double yaw = Math.toRadians(
      MathHelper.func_76142_g(getRenderEntityfield_70177_z));
    int index = dir.ordinal();
    return yaw + index * 1.5707963267948966D;
  }
}
