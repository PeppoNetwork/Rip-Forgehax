package com.matt.forgehax.mods;

import com.google.common.base.Strings;
import com.google.common.collect.Sets;
import com.matt.forgehax.asm.events.PacketEvent.Incoming.Pre;
import com.matt.forgehax.asm.events.PacketEvent.Outgoing.Pre;
import com.matt.forgehax.util.mod.Category;
import com.matt.forgehax.util.mod.ToggleMod;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import io.netty.buffer.ByteBuf;
import java.util.Scanner;
import java.util.Set;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.CPacketCustomPayload;
import net.minecraft.network.play.server.SPacketCustomPayload;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.network.internal.FMLProxyPacket;


@RegisterMod
public class PayloadSpoofer
  extends ToggleMod
{
  private static final Set<String> IGNORE_LIST = ;
  

  static
  {
    IGNORE_LIST.add("WDL|INIT");
    IGNORE_LIST.add("WDL|CONTROL");
    IGNORE_LIST.add("WDL|REQUEST");
    
    IGNORE_LIST.add("wdl:init");
    IGNORE_LIST.add("wdl:control");
    IGNORE_LIST.add("wdl:request");
    
    IGNORE_LIST.add("schematica");
    IGNORE_LIST.add("journeymap_channel");
    IGNORE_LIST.add("jm_dim_permission");
    IGNORE_LIST.add("jm_init_login");
  }
  
  public PayloadSpoofer() {
    super(Category.MISC, "PayloadSpoofer", false, "Will cancel packets sent by some mods");
  }
  
  private boolean isBlockedPacket(String channel, ByteBuf buffer) {
    if (IGNORE_LIST.contains(channel))
      return true;
    if ("REGISTER".equals(channel)) {
      Scanner scanner = new Scanner(new String(buffer.array()));
      scanner.useDelimiter("\\u0000");
      if (scanner.hasNext()) {
        String next = scanner.next();
        return (!Strings.isNullOrEmpty(next)) && (IGNORE_LIST.contains(next));
      }
    }
    return false;
  }
  

  @SubscribeEvent(priority=EventPriority.HIGHEST)
  public void onIncomingPacket(PacketEvent.Incoming.Pre event)
  {
    Packet packet = event.getPacket();
    
    if (((packet instanceof SPacketCustomPayload)) || ((packet instanceof FMLProxyPacket))) { ByteBuf packetBuffer;
      String channel; ByteBuf packetBuffer; if ((packet instanceof SPacketCustomPayload)) {
        String channel = ((SPacketCustomPayload)packet).func_149169_c();
        packetBuffer = ((SPacketCustomPayload)packet).func_180735_b();
      } else {
        channel = ((FMLProxyPacket)packet).channel();
        packetBuffer = ((FMLProxyPacket)packet).payload();
      }
      
      if (isBlockedPacket(channel, packetBuffer)) {
        event.setCanceled(true);
      }
    }
  }
  

  @SubscribeEvent(priority=EventPriority.HIGHEST)
  public void onOutgoingPacket(PacketEvent.Outgoing.Pre event)
  {
    Packet packet = event.getPacket();
    
    if (((packet instanceof CPacketCustomPayload)) || ((packet instanceof FMLProxyPacket))) { ByteBuf packetBuffer;
      String channel; ByteBuf packetBuffer; if ((packet instanceof CPacketCustomPayload)) {
        String channel = ((CPacketCustomPayload)packet).func_149559_c();
        packetBuffer = ((CPacketCustomPayload)packet).func_180760_b();
      } else {
        channel = ((FMLProxyPacket)packet).channel();
        packetBuffer = ((FMLProxyPacket)packet).payload();
      }
      
      if (isBlockedPacket(channel, packetBuffer)) {
        event.setCanceled(true);
      }
    }
  }
}
