package com.matt.forgehax.mods;

import com.matt.forgehax.asm.ForgeHaxHooks;
import com.matt.forgehax.asm.events.DoBlockCollisionsEvent;
import com.matt.forgehax.util.mod.ToggleMod;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import java.util.Set;
import net.minecraft.block.Block;
import net.minecraft.block.BlockSoulSand;
import net.minecraft.block.state.IBlockState;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@RegisterMod
public class NoSlowdown extends ToggleMod
{
  public NoSlowdown()
  {
    super(com.matt.forgehax.util.mod.Category.PLAYER, "NoSlowDown", false, "Disables block slowdown");
  }
  
  public void onEnabled()
  {
    ForgeHaxHooks.isNoSlowDownActivated = true;
    try {
      ForgeHaxHooks.LIST_BLOCK_FILTER.add(BlockSoulSand.class);
    }
    catch (Exception localException) {}
  }
  
  public void onDisabled()
  {
    ForgeHaxHooks.isNoSlowDownActivated = false;
    try {
      ForgeHaxHooks.LIST_BLOCK_FILTER.remove(BlockSoulSand.class);
    }
    catch (Exception localException) {}
  }
  
  @SubscribeEvent
  public void onDoApplyBlockMovement(DoBlockCollisionsEvent event) {
    if ((event.getEntity().equals(com.matt.forgehax.Helper.getLocalPlayer())) && 
      (Block.func_149682_b(event.getState().func_177230_c()) == 88)) {
      event.setCanceled(true);
    }
  }
}
