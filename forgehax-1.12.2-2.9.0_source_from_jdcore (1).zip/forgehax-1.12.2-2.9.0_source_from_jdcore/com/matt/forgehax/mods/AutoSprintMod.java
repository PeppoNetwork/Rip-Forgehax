package com.matt.forgehax.mods;

import com.matt.forgehax.Helper;
import com.matt.forgehax.events.LocalPlayerUpdateEvent;
import com.matt.forgehax.util.command.SettingEnumBuilder;
import com.matt.forgehax.util.key.Bindings;
import com.matt.forgehax.util.key.KeyBindingHandler;
import com.matt.forgehax.util.mod.ToggleMod;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.EntityLivingBase;

@RegisterMod
public class AutoSprintMod extends ToggleMod
{
  private boolean isBound = false;
  
  static enum Modes {
    ALWAYS, 
    LEGIT;
    


    private Modes() {}
  }
  

  public final com.matt.forgehax.util.command.Setting<Modes> mode = ((SettingEnumBuilder)((SettingEnumBuilder)getCommandStub().builders().newSettingEnumBuilder().name("mode")).description("Sprint mode"))
    .defaultTo(Modes.ALWAYS)
    .build();
  
  public AutoSprintMod() {
    super(com.matt.forgehax.util.mod.Category.PLAYER, "AutoSprint", false, "Automatically sprints");
  }
  
  private void startSprinting() {
    switch (1.$SwitchMap$com$matt$forgehax$mods$AutoSprintMod$Modes[((Modes)mode.get()).ordinal()]) {
    case 1: 
      if ((!getLocalPlayerfield_70123_F) && (!Helper.getLocalPlayer().func_70051_ag())) {
        Helper.getLocalPlayer().func_70031_b(true);
      }
      break;
    case 2: 
    default: 
      if (!isBound) {
        Bindings.sprint.bind();
        isBound = true;
      }
      if (!Bindings.sprint.getBinding().func_151470_d()) {
        Bindings.sprint.setPressed(true);
      }
      break;
    }
  }
  
  private void stopSprinting() {
    if (isBound) {
      Bindings.sprint.setPressed(false);
      Bindings.sprint.unbind();
      isBound = false;
    }
  }
  



  public void onDisabled()
  {
    stopSprinting();
  }
  


  @net.minecraftforge.fml.common.eventhandler.SubscribeEvent
  public void onUpdate(LocalPlayerUpdateEvent event)
  {
    if ((getEntityLivingfield_191988_bg > 0.0F) && 
      (!getEntityLivingfield_70123_F) && 
      (!event.getEntityLiving().func_70093_af())) {
      startSprinting();
    }
  }
}
