package com.matt.forgehax.mods;

import com.matt.forgehax.Helper;
import com.matt.forgehax.asm.reflection.FastReflection.Fields;
import com.matt.forgehax.asm.utils.fasttype.FastField;
import com.matt.forgehax.util.command.Command;
import com.matt.forgehax.util.command.CommandBuilders;
import com.matt.forgehax.util.command.Setting;
import com.matt.forgehax.util.command.SettingBuilder;
import com.matt.forgehax.util.mod.ToggleMod;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.ai.attributes.IAttribute;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.entity.passive.AbstractHorse;
import net.minecraftforge.event.entity.living.LivingEvent.LivingUpdateEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@RegisterMod
public class HorseStats extends ToggleMod
{
  public HorseStats()
  {
    super(com.matt.forgehax.util.mod.Category.PLAYER, "HorseStats", false, "Change the stats of your horse");
  }
  





  private final Setting<Double> jumpHeight = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("JumpHeight")).description("Modified horse jump height attribute. Default: 1"))
    .defaultTo(Double.valueOf(1.0D))
    .build();
  




  private final Setting<Double> speed = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("Speed")).description("Modified horse speed attribute. Default: 0.3375"))
    .defaultTo(Double.valueOf(0.3375D))
    .build();
  





  private final Setting<Double> multiplier = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("multiplier")).description("multiplier while sprinting"))
    .defaultTo(Double.valueOf(1.0D))
    .build();
  
  public void onDisabled()
  {
    if ((Helper.getRidingEntity() instanceof AbstractHorse)) {
      applyStats(((Double)jumpHeight.getDefault()).doubleValue(), ((Double)speed.getDefault()).doubleValue());
    }
  }
  
  @SubscribeEvent
  public void onLivingUpdate(LivingEvent.LivingUpdateEvent event) {
    if ((com.matt.forgehax.util.entity.EntityUtils.isDrivenByPlayer(event.getEntity())) && 
      ((Helper.getRidingEntity() instanceof AbstractHorse)))
    {
      double newSpeed = speed.getAsDouble();
      if (Helper.getLocalPlayer().func_70051_ag()) {
        newSpeed *= multiplier.getAsDouble();
      }
      applyStats(jumpHeight.getAsDouble(), newSpeed);
    }
  }
  
  private void applyStats(double newJump, double newSpeed)
  {
    IAttribute jump_strength = (IAttribute)FastReflection.Fields.AbstractHorse_JUMP_STRENGTH.get(Helper.getRidingEntity());
    
    IAttribute movement_speed = (IAttribute)FastReflection.Fields.SharedMonsterAttributes_MOVEMENT_SPEED.get(Helper.getRidingEntity());
    
    ((EntityLivingBase)Helper.getRidingEntity())
      .func_110148_a(jump_strength)
      .func_111128_a(newJump);
    ((EntityLivingBase)Helper.getRidingEntity())
      .func_110148_a(movement_speed)
      .func_111128_a(newSpeed);
  }
}
