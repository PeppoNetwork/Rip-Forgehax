package com.matt.forgehax.mods;

import com.matt.forgehax.Helper;
import com.matt.forgehax.asm.events.PacketEvent.Incoming.Pre;
import com.matt.forgehax.asm.reflection.FastReflection.Methods;
import com.matt.forgehax.asm.utils.fasttype.FastMethod;
import com.matt.forgehax.events.LocalPlayerUpdateEvent;
import com.matt.forgehax.util.command.Command;
import com.matt.forgehax.util.command.CommandBuilders;
import com.matt.forgehax.util.command.Setting;
import com.matt.forgehax.util.command.SettingBuilder;
import com.matt.forgehax.util.mod.ToggleMod;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.server.SPacketSoundEffect;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent.MouseInputEvent;

@RegisterMod
public class AutoFishMod extends ToggleMod
{
  private int ticksCastDelay = 0;
  private int ticksHookDeployed = 0;
  
  private boolean previouslyHadRodEquipped = false;
  





  public final Setting<Integer> casting_delay = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("casting_delay")).description("Number of ticks to wait after casting the rod to attempt a recast"))
    .defaultTo(Integer.valueOf(20))
    .build();
  





  public final Setting<Double> max_sound_distance = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("max_sound_distance")).description("Maximum distance between the splash sound and hook entity allowed (set to 0 to disable this feature)"))
  
    .defaultTo(Double.valueOf(2.0D))
    .build();
  





  public final Setting<Integer> fail_safe_time = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("fail_safe_time")).description("Maximum amount of time (in ticks) allowed until the hook is pulled in (set to 0 to disable this feature)"))
  
    .defaultTo(Integer.valueOf(600))
    .build();
  
  public AutoFishMod() {
    super(com.matt.forgehax.util.mod.Category.PLAYER, "AutoFish", false, "Auto fish");
  }
  
  private boolean isCorrectSplashPacket(SPacketSoundEffect packet) {
    EntityPlayerSP me = Helper.getLocalPlayer();
    if ((packet.func_186978_a().equals(SoundEvents.field_187609_F)) && (me != null) && (field_71104_cf != null)) {} return 
    

      (((Double)max_sound_distance.get()).doubleValue() == 0.0D) || 
      



      (field_71104_cf.func_174791_d().func_72438_d(new Vec3d(packet.func_149207_d(), packet.func_149211_e(), packet.func_149210_f())) <= ((Double)max_sound_distance.get()).doubleValue());
  }
  
  private void rightClick() {
    if (ticksCastDelay <= 0) {
      FastReflection.Methods.Minecraft_rightClickMouse.invoke(MC, new Object[0]);
      ticksCastDelay = ((Integer)casting_delay.get()).intValue();
    }
  }
  
  private void resetLocals() {
    ticksCastDelay = 0;
    ticksHookDeployed = 0;
    previouslyHadRodEquipped = false;
  }
  
  public void onEnabled()
  {
    resetLocals();
  }
  
  @SubscribeEvent
  public void onUpdate(LocalPlayerUpdateEvent event) {
    EntityPlayer me = Helper.getLocalPlayer();
    ItemStack heldStack = me.func_184614_ca();
    

    if (ticksCastDelay > ((Integer)casting_delay.get()).intValue()) {
      ticksCastDelay = ((Integer)casting_delay.get()).intValue();
    } else if (ticksCastDelay > 0) {
      ticksCastDelay -= 1;
    }
    

    if (heldStack != null)
    {
      if ((heldStack.func_77973_b() instanceof net.minecraft.item.ItemFishingRod))
      {
        if (!previouslyHadRodEquipped) {
          ticksCastDelay = ((Integer)casting_delay.get()).intValue();
          previouslyHadRodEquipped = true; return; }
        if (field_71104_cf == null)
        {
          rightClick(); return;
        }
        
        ticksHookDeployed += 1;
        
        if ((((Integer)fail_safe_time.get()).intValue() == 0) || (ticksHookDeployed <= ((Integer)fail_safe_time.get()).intValue())) return;
        rightClick();
        resetLocals(); return;
      }
    }
    
    resetLocals();
  }
  
  @SubscribeEvent
  public void onMouseEvent(InputEvent.MouseInputEvent event)
  {
    if ((MCfield_71474_y.field_74313_G.func_151470_d()) && (ticksHookDeployed > 0)) {
      ticksCastDelay = ((Integer)casting_delay.get()).intValue();
    }
  }
  
  @SubscribeEvent
  public void onPacketIncoming(PacketEvent.Incoming.Pre event) {
    if ((event.getPacket() instanceof SPacketSoundEffect)) {
      SPacketSoundEffect packet = (SPacketSoundEffect)event.getPacket();
      if (isCorrectSplashPacket(packet)) {
        rightClick();
      }
    }
  }
}
