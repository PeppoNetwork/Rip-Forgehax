package com.matt.forgehax.mods;

import com.matt.forgehax.Helper;
import com.matt.forgehax.events.LocalPlayerUpdateEvent;
import com.matt.forgehax.util.command.Command;
import com.matt.forgehax.util.command.CommandBuilders;
import com.matt.forgehax.util.command.Setting;
import com.matt.forgehax.util.command.SettingBuilder;
import com.matt.forgehax.util.key.Bindings;
import com.matt.forgehax.util.key.KeyBindingHandler;
import com.matt.forgehax.util.mod.ToggleMod;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.world.chunk.Chunk;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@RegisterMod
public class AutoWalkMod extends ToggleMod
{
  public final Setting<Boolean> stop_at_unloaded_chunks = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("stop_at_unloaded_chunks")).description("Stops moving at unloaded chunks"))
    .defaultTo(Boolean.valueOf(true))
    .build();
  
  private boolean isBound = false;
  
  public AutoWalkMod() {
    super(com.matt.forgehax.util.mod.Category.PLAYER, "AutoWalk", false, "Automatically walks forward");
  }
  
  public void onDisabled()
  {
    if (isBound) {
      Bindings.forward.setPressed(false);
      Bindings.forward.unbind();
      isBound = false;
    }
  }
  
  @SubscribeEvent
  public void onUpdate(LocalPlayerUpdateEvent event) {
    if (!isBound) {
      Bindings.forward.bind();
      isBound = true;
    }
    if (!Bindings.forward.getBinding().func_151470_d()) {
      Bindings.forward.setPressed(true);
    }
    
    if ((((Boolean)stop_at_unloaded_chunks.get()).booleanValue()) && 
      (!Helper.getWorld().func_175726_f(Helper.getLocalPlayer().func_180425_c()).func_177410_o())) {
      Bindings.forward.setPressed(false);
    }
  }
}
