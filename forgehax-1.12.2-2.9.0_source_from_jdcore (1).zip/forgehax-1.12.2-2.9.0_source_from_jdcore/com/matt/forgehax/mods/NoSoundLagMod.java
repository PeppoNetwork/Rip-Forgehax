package com.matt.forgehax.mods;

import com.google.common.collect.Sets;
import com.matt.forgehax.asm.events.PacketEvent.Incoming.Pre;
import com.matt.forgehax.util.mod.Category;
import com.matt.forgehax.util.mod.ToggleMod;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import java.util.Set;
import net.minecraft.init.SoundEvents;
import net.minecraft.network.play.server.SPacketSoundEffect;
import net.minecraft.util.SoundEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@RegisterMod
public class NoSoundLagMod extends ToggleMod
{
  private static final Set<SoundEvent> BLACKLIST = Sets.newHashSet(new SoundEvent[] { SoundEvents.field_187719_p, SoundEvents.field_191258_p, SoundEvents.field_187716_o, SoundEvents.field_187725_r, SoundEvents.field_187722_q, SoundEvents.field_187713_n, SoundEvents.field_187728_s });
  







  public NoSoundLagMod()
  {
    super(Category.MISC, "NoSoundLag", false, "lag exploit fix");
  }
  
  @SubscribeEvent
  public void onPacketReceived(PacketEvent.Incoming.Pre event) {
    if ((event.getPacket() instanceof SPacketSoundEffect)) {
      SPacketSoundEffect packet = (SPacketSoundEffect)event.getPacket();
      if (BLACKLIST.contains(packet.func_186978_a())) {
        event.setCanceled(true);
      }
    }
  }
}
