package com.matt.forgehax.mods;

import com.matt.forgehax.Helper;
import com.matt.forgehax.asm.events.BlockControllerProcessEvent;
import com.matt.forgehax.asm.events.LeftClickCounterUpdateEvent;
import com.matt.forgehax.util.entity.LocalPlayerUtils;
import com.matt.forgehax.util.key.Bindings;
import com.matt.forgehax.util.key.KeyBindingHandler;
import com.matt.forgehax.util.mod.Category;
import com.matt.forgehax.util.mod.ToggleMod;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import net.minecraft.util.math.RayTraceResult;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.ClientTickEvent;

@RegisterMod
public class AutoMine
  extends ToggleMod
{
  private boolean pressed = false;
  
  public AutoMine() {
    super(Category.PLAYER, "AutoMine", false, "Auto mine blocks");
  }
  
  private void setPressed(boolean state) {
    Bindings.attack.setPressed(state);
    pressed = state;
  }
  
  protected void onEnabled()
  {
    Bindings.attack.bind();
  }
  
  protected void onDisabled()
  {
    setPressed(false);
    Bindings.attack.unbind();
  }
  
  @SubscribeEvent
  public void onTick(TickEvent.ClientTickEvent event) {
    if ((Helper.getLocalPlayer() == null) || (Helper.getWorld() == null)) {
      return;
    }
    
    switch (1.$SwitchMap$net$minecraftforge$fml$common$gameevent$TickEvent$Phase[phase.ordinal()]) {
    case 1: 
      RayTraceResult tr = LocalPlayerUtils.getMouseOverBlockTrace();
      
      if (tr == null) {
        setPressed(false);
        return;
      }
      
      setPressed(true);
      break;
    
    case 2: 
      setPressed(false);
    }
    
  }
  
  @SubscribeEvent(priority=EventPriority.HIGHEST)
  public void onGuiOpened(GuiOpenEvent event)
  {
    if ((Helper.getWorld() != null) && (Helper.getLocalPlayer() != null) && (event.getGui() != null)) {
      getGuifield_146291_p = true;
    }
  }
  
  @SubscribeEvent
  public void onLeftClickCouterUpdate(LeftClickCounterUpdateEvent event)
  {
    event.setCanceled(true);
  }
  

  @SubscribeEvent
  public void onBlockCounterUpdate(BlockControllerProcessEvent event)
  {
    if (pressed) {
      event.setLeftClicked(true);
    }
  }
}
