package com.matt.forgehax.mods;

import com.matt.forgehax.events.LocalPlayerUpdateEvent;
import com.matt.forgehax.gui.ClickGui;
import com.matt.forgehax.util.mod.Category;
import com.matt.forgehax.util.mod.ToggleMod;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiIngameMenu;
import net.minecraft.client.gui.GuiOptions;
import net.minecraft.client.gui.GuiScreenOptionsSounds;
import net.minecraft.client.gui.GuiVideoSettings;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.input.Keyboard;

@RegisterMod
public class GuiMove extends ToggleMod
{
  public GuiMove()
  {
    super(Category.MISC, "GuiMove", false, "move with a gui open");
  }
  
  @SubscribeEvent
  public void LocalPlayerUpdate(LocalPlayerUpdateEvent event) {
    KeyBinding[] keys = { MCfield_71474_y.field_74351_w, MCfield_71474_y.field_74368_y, MCfield_71474_y.field_74370_x, MCfield_71474_y.field_74366_z, MCfield_71474_y.field_74314_A, MCfield_71474_y.field_151444_V };
    






    if (((MCfield_71462_r instanceof GuiOptions)) || ((MCfield_71462_r instanceof GuiVideoSettings)) || ((MCfield_71462_r instanceof GuiScreenOptionsSounds)) || ((MCfield_71462_r instanceof GuiContainer)) || ((MCfield_71462_r instanceof GuiIngameMenu)) || ((MCfield_71462_r instanceof ClickGui)))
    {




      for (KeyBinding bind : keys) {
        KeyBinding.func_74510_a(bind.func_151463_i(), Keyboard.isKeyDown(bind.func_151463_i()));
      }
    } else if (MCfield_71462_r == null) {
      for (KeyBinding bind : keys) {
        if (!Keyboard.isKeyDown(bind.func_151463_i())) {
          KeyBinding.func_74510_a(bind.func_151463_i(), false);
        }
      }
    }
  }
}
