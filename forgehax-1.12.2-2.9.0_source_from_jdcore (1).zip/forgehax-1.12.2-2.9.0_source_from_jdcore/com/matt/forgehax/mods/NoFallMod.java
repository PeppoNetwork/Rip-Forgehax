package com.matt.forgehax.mods;

import com.matt.forgehax.Helper;
import com.matt.forgehax.asm.events.PacketEvent.Outgoing.Pre;
import com.matt.forgehax.util.PacketHelper;
import com.matt.forgehax.util.mod.ToggleMod;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.client.CPacketPlayer.PositionRotation;
import net.minecraft.network.play.client.CPacketPlayer.Rotation;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@RegisterMod
public class NoFallMod extends ToggleMod
{
  public NoFallMod()
  {
    super(com.matt.forgehax.util.mod.Category.PLAYER, "NoFall", false, "Prevents fall damage from being taken");
  }
  
  private float lastFallDistance = 0.0F;
  
  @SubscribeEvent
  public void onPacketSend(PacketEvent.Outgoing.Pre event) {
    if (((event.getPacket() instanceof CPacketPlayer)) && 
      (!(event.getPacket() instanceof CPacketPlayer.Rotation)) && 
      (!PacketHelper.isIgnored(event.getPacket()))) {
      CPacketPlayer packetPlayer = (CPacketPlayer)event.getPacket();
      if ((((Boolean)com.matt.forgehax.asm.reflection.FastReflection.Fields.CPacketPlayer_onGround.get(packetPlayer)).booleanValue()) && (lastFallDistance >= 4.0F))
      {





        CPacketPlayer packet = new CPacketPlayer.PositionRotation(((CPacketPlayer)event.getPacket()).func_186997_a(0.0D), 1337.0D + ((CPacketPlayer)event.getPacket()).func_186996_b(0.0D), ((CPacketPlayer)event.getPacket()).func_187000_c(0.0D), ((CPacketPlayer)event.getPacket()).func_186999_a(0.0F), ((CPacketPlayer)event.getPacket()).func_186998_b(0.0F), true);
        






        CPacketPlayer reposition = new CPacketPlayer.PositionRotation(((CPacketPlayer)event.getPacket()).func_186997_a(0.0D), ((CPacketPlayer)event.getPacket()).func_186996_b(0.0D), ((CPacketPlayer)event.getPacket()).func_187000_c(0.0D), ((CPacketPlayer)event.getPacket()).func_186999_a(0.0F), ((CPacketPlayer)event.getPacket()).func_186998_b(0.0F), true);
        
        PacketHelper.ignore(packet);
        PacketHelper.ignore(reposition);
        Helper.getNetworkManager().func_179290_a(packet);
        Helper.getNetworkManager().func_179290_a(reposition);
        lastFallDistance = 0.0F;
      } else {
        lastFallDistance = getLocalPlayerfield_70143_R;
      }
    }
  }
}
