package com.matt.forgehax.mods;

import com.matt.forgehax.Helper;
import com.matt.forgehax.asm.events.PacketEvent.Incoming.Pre;
import com.matt.forgehax.events.LocalPlayerUpdateEvent;
import com.matt.forgehax.util.mod.Category;
import com.matt.forgehax.util.mod.ToggleMod;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketEntityAction.Action;
import net.minecraft.network.play.client.CPacketPlayer.PositionRotation;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import net.minecraftforge.fml.common.ObfuscationReflectionHelper;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@RegisterMod
public class FlyMod extends ToggleMod
{
  private boolean zoomies = true;
  
  public FlyMod() {
    super(Category.PLAYER, "Fly", false, "Enables flying");
  }
  
  public void onDisabled()
  {
    if (java.util.Objects.nonNull(Helper.getLocalPlayer())) {
      getLocalPlayerfield_70145_X = false;
    }
  }
  
  @SubscribeEvent
  public void onLocalPlayerUpdate(LocalPlayerUpdateEvent event) {
    try {
      double[] dir = moveLooking(0);
      double xDir = dir[0];
      double zDir = dir[1];
      
      if (((MCfield_71474_y.field_74351_w.func_151470_d()) || 
        (MCfield_71474_y.field_74370_x.func_151470_d()) || 
        (MCfield_71474_y.field_74366_z.func_151470_d()) || 
        (MCfield_71474_y.field_74368_y.func_151470_d())) && 
        (!MCfield_71474_y.field_74314_A.func_151470_d())) {
        MCfield_71439_g.field_70159_w = (xDir * 0.26D);
        MCfield_71439_g.field_70179_y = (zDir * 0.26D);
      }
      double posX = MCfield_71439_g.field_70165_t + MCfield_71439_g.field_70159_w;
      


      double posY = MCfield_71439_g.field_70163_u + (MCfield_71474_y.field_74314_A.func_151470_d() ? 0.0624D : zoomies ? 0.0625D : 1.0E-8D) - (MCfield_71474_y.field_74311_E.func_151470_d() ? 0.0624D : zoomies ? 0.0625D : 2.0E-8D);
      

      double posZ = MCfield_71439_g.field_70161_v + MCfield_71439_g.field_70159_w;
      Helper.getNetworkManager()
        .func_179290_a(new CPacketPlayer.PositionRotation(MCfield_71439_g.field_70165_t + MCfield_71439_g.field_70159_w, MCfield_71439_g.field_70163_u + (MCfield_71474_y.field_74314_A
        


        .func_151470_d() ? 0.0624D : zoomies ? 0.0625D : 1.0E-8D) - (MCfield_71474_y.field_74311_E
        

        .func_151470_d() ? 0.0624D : zoomies ? 0.0625D : 2.0E-8D), MCfield_71439_g.field_70161_v + MCfield_71439_g.field_70179_y, MCfield_71439_g.field_70177_z, MCfield_71439_g.field_70125_A, false));
      





      Helper.getNetworkManager()
        .func_179290_a(new CPacketPlayer.PositionRotation(MCfield_71439_g.field_70165_t + MCfield_71439_g.field_70159_w, 1337.0D + MCfield_71439_g.field_70163_u, MCfield_71439_g.field_70161_v + MCfield_71439_g.field_70179_y, MCfield_71439_g.field_70177_z, MCfield_71439_g.field_70125_A, true));
      






      Helper.getNetworkManager().func_179290_a(new CPacketEntityAction(MCfield_71439_g, CPacketEntityAction.Action.START_FALL_FLYING));
      MCfield_71439_g.func_70107_b(posX, posY, posZ);
      
      zoomies = (!zoomies);
      
      MCfield_71439_g.field_70159_w = 0.0D;
      MCfield_71439_g.field_70181_x = 0.0D;
      MCfield_71439_g.field_70179_y = 0.0D;
      
      MCfield_71439_g.field_70145_X = true;
    } catch (Exception e) {
      Helper.printStackTrace(e);
    }
  }
  
  public double[] moveLooking(int ignored) {
    return new double[] { MCfield_71439_g.field_70177_z * 360.0F / 360.0F * 180.0F / 180.0F, 0.0D };
  }
  
  @SubscribeEvent
  public void onOutgoingPacketSent(PacketEvent.Incoming.Pre event) {
    if ((event.getPacket() instanceof SPacketPlayerPosLook)) {
      SPacketPlayerPosLook packet = (SPacketPlayerPosLook)event.getPacket();
      try {
        ObfuscationReflectionHelper.setPrivateValue(SPacketPlayerPosLook.class, packet, 
        

          Float.valueOf(MCfield_71439_g.field_70177_z), new String[] { "yaw", "field_148936_d", "d" });
        


        ObfuscationReflectionHelper.setPrivateValue(SPacketPlayerPosLook.class, packet, 
        

          Float.valueOf(MCfield_71439_g.field_70125_A), new String[] { "pitch", "field_148937_e", "e" });
      }
      catch (Exception localException) {}
    }
  }
}
