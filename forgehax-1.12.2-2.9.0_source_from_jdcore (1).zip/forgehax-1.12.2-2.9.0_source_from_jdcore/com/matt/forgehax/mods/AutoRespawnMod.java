package com.matt.forgehax.mods;

import com.matt.forgehax.Helper;
import com.matt.forgehax.events.LocalPlayerUpdateEvent;
import com.matt.forgehax.util.command.Command;
import com.matt.forgehax.util.command.CommandBuilders;
import com.matt.forgehax.util.command.Setting;
import com.matt.forgehax.util.command.SettingBuilder;
import com.matt.forgehax.util.mod.ToggleMod;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import java.text.SimpleDateFormat;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.ClientTickEvent;

@RegisterMod
public class AutoRespawnMod extends ToggleMod
{
  public AutoRespawnMod()
  {
    super(com.matt.forgehax.util.mod.Category.PLAYER, "AutoRespawn", false, "Auto respawn on death");
  }
  





  private final Setting<Integer> delay = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("delay")).description("wait ticks before respawning"))
    .min(Integer.valueOf(0))
    .defaultTo(Integer.valueOf(50))
    .build();
  
  private boolean isDead = false;
  private int deadTicks = 0;
  
  @SubscribeEvent
  public void onClientTick(TickEvent.ClientTickEvent ev) {
    if (isDead) {
      deadTicks += 1;
      if (deadTicks > delay.getAsInteger()) {
        deadTicks = 0;
        isDead = false;
        Helper.getLocalPlayer().func_71004_bE();
      }
    }
  }
  
  @SubscribeEvent
  public void onLocalPlayerUpdate(LocalPlayerUpdateEvent event) {
    if (Helper.getLocalPlayer().func_110143_aJ() <= 0.0F) {
      if (!isDead) {
        Helper.printInform("Died at %.1f, %.1f, %.1f on %s", new Object[] {
          Double.valueOf(getLocalPlayerfield_70165_t), 
          Double.valueOf(getLocalPlayerfield_70163_u), 
          Double.valueOf(getLocalPlayerfield_70161_v), new SimpleDateFormat("HH:mm:ss")
          .format(new java.util.Date()) });
      }
      
      isDead = true;
    }
  }
}
