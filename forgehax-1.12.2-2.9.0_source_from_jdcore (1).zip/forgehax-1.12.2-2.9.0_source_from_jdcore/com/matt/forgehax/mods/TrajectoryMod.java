package com.matt.forgehax.mods;

import com.matt.forgehax.Helper;
import com.matt.forgehax.events.RenderEvent;
import com.matt.forgehax.util.mod.ToggleMod;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import com.matt.forgehax.util.projectile.Projectile;
import com.matt.forgehax.util.projectile.SimulationResult;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.lwjgl.opengl.GL11;

@RegisterMod
public class TrajectoryMod extends ToggleMod
{
  public TrajectoryMod()
  {
    super(com.matt.forgehax.util.mod.Category.RENDER, "Trajectory", false, "Draws projectile trajectory");
  }
  
  @SubscribeEvent
  public void onRender(RenderEvent event)
  {
    Projectile projectile = Projectile.getProjectileByItemStack(Helper.getLocalPlayer().func_184614_ca());
    if (!projectile.isNull())
    {
      SimulationResult result = projectile.getSimulatedTrajectoryFromEntity(
        Helper.getLocalPlayer(), 
        com.matt.forgehax.mods.managers.PositionRotationManager.getState().getRenderServerViewAngles(), projectile
        .getForce(
        Helper.getLocalPlayer().func_184614_ca().func_77988_m() - 
        Helper.getLocalPlayer().func_184605_cv()), 0);
      
      if (result == null) {
        return;
      }
      
      if (result.getPathTraveled().size() > 1) {
        event.setTranslation(Helper.getLocalPlayer().func_174791_d());
        
        GlStateManager.func_179126_j();
        GlStateManager.func_187441_d(2.0F);
        
        GL11.glEnable(2848);
        event.getBuffer().func_181668_a(1, net.minecraft.client.renderer.vertex.DefaultVertexFormats.field_181706_f);
        
        Iterator<Vec3d> it = result.getPathTraveled().iterator();
        Vec3d previous = (Vec3d)it.next();
        while (it.hasNext()) {
          Vec3d next = (Vec3d)it.next();
          event
            .getBuffer()
            .func_181662_b(field_72450_a, field_72448_b, field_72449_c)
            .func_181669_b(255, 255, 255, 255)
            .func_181675_d();
          event.getBuffer().func_181662_b(field_72450_a, field_72448_b, field_72449_c).func_181669_b(255, 255, 255, 255).func_181675_d();
          previous = next;
        }
        
        event.getTessellator().func_78381_a();
        GL11.glDisable(2848);
        
        GlStateManager.func_187441_d(1.0F);
        GlStateManager.func_179097_i();
        
        event.resetTranslation();
      }
    }
  }
}
