package com.matt.forgehax.mods;

import com.matt.forgehax.asm.events.PacketEvent.Outgoing.Pre;
import com.matt.forgehax.asm.reflection.FastReflection.Fields;
import com.matt.forgehax.util.mod.ToggleMod;
import net.minecraft.client.Minecraft;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketEntityAction.Action;
import net.minecraft.network.play.client.CPacketPlayer;

@com.matt.forgehax.util.mod.loader.RegisterMod
public class AntiHunger extends ToggleMod
{
  public AntiHunger()
  {
    super(com.matt.forgehax.util.mod.Category.PLAYER, "AntiHunger", false, "Don't use hunger for travelling");
  }
  
  @net.minecraftforge.fml.common.eventhandler.SubscribeEvent
  public void onPacketSending(PacketEvent.Outgoing.Pre event)
  {
    if ((event.getPacket() instanceof CPacketPlayer)) {
      CPacketPlayer packet = (CPacketPlayer)event.getPacket();
      if ((MCfield_71439_g.field_70143_R <= 0.0F) && (!MCfield_71442_b.func_181040_m())) {
        FastReflection.Fields.CPacketPlayer_onGround.set(packet, Boolean.valueOf(false));
      } else {
        FastReflection.Fields.CPacketPlayer_onGround.set(packet, Boolean.valueOf(true));
      }
    }
    
    if ((event.getPacket() instanceof CPacketEntityAction)) {
      CPacketEntityAction packet = (CPacketEntityAction)event.getPacket();
      if ((packet.func_180764_b() == CPacketEntityAction.Action.START_SPRINTING) || 
        (packet.func_180764_b() == CPacketEntityAction.Action.STOP_SPRINTING)) {
        event.setCanceled(true);
      }
    }
  }
}
