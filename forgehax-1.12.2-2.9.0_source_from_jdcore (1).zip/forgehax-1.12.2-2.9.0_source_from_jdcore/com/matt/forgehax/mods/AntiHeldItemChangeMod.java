package com.matt.forgehax.mods;

import com.matt.forgehax.Helper;
import com.matt.forgehax.asm.events.PacketEvent.Incoming.Pre;
import com.matt.forgehax.asm.reflection.FastReflection.Methods;
import com.matt.forgehax.asm.utils.fasttype.FastMethod;
import com.matt.forgehax.util.mod.ToggleMod;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.play.client.CPacketHeldItemChange;
import net.minecraft.network.play.server.SPacketSetSlot;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@RegisterMod
public class AntiHeldItemChangeMod extends ToggleMod
{
  public AntiHeldItemChangeMod()
  {
    super(com.matt.forgehax.util.mod.Category.PLAYER, "AntiHeldItemChange", false, "prevents the server from changing selected hotbar slot");
  }
  



  @SubscribeEvent
  public void onPacketReceived(PacketEvent.Incoming.Pre event)
  {
    if (((event.getPacket() instanceof SPacketSetSlot)) && (Helper.getLocalPlayer() != null)) {
      int currentSlot = getLocalPlayerfield_71071_by.field_70461_c;
      
      if (((SPacketSetSlot)event.getPacket()).func_149173_d() != currentSlot)
      {
        Helper.getNetworkManager().func_179290_a(new CPacketHeldItemChange(currentSlot));
        
        FastReflection.Methods.KeyBinding_unPress.invoke(MCfield_71474_y.field_74313_G, new Object[0]);
        

        event.setCanceled(true);
      }
    }
  }
}
