package com.matt.forgehax.mods;

import com.matt.forgehax.events.RenderEvent;
import com.matt.forgehax.util.color.Color;
import com.matt.forgehax.util.color.Colors;
import com.matt.forgehax.util.mod.Category;
import com.matt.forgehax.util.mod.ToggleMod;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import com.matt.forgehax.util.tesselation.GeometryTessellator;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@RegisterMod
public class ChunkBorder extends ToggleMod
{
  public ChunkBorder()
  {
    super(Category.RENDER, "ChunkBorder", false, "Shows a border at the border around the chunk you are in.");
  }
  



  @SubscribeEvent
  public void onRender(RenderEvent event)
  {
    event.getBuffer().func_181668_a(1, DefaultVertexFormats.field_181706_f);
    
    BlockPos from = new BlockPos(MCfield_71439_g.field_70176_ah * 16, 0, MCfield_71439_g.field_70164_aj * 16);
    BlockPos to = new BlockPos(from.func_177958_n() + 15, 256, from.func_177952_p() + 15);
    
    int color = Colors.YELLOW.toBuffer();
    GeometryTessellator.drawCuboid(event.getBuffer(), from, to, 63, color);
    
    event.getTessellator().func_78381_a();
  }
}
