package com.matt.forgehax.mods;

import com.matt.forgehax.util.mod.ToggleMod;
import net.minecraftforge.client.event.EntityViewRenderEvent.FogColors;
import net.minecraftforge.client.event.EntityViewRenderEvent.FogDensity;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@com.matt.forgehax.util.mod.loader.RegisterMod
public class AntiFogMod extends ToggleMod
{
  public AntiFogMod()
  {
    super(com.matt.forgehax.util.mod.Category.WORLD, "AntiFog", false, "Removes fog");
  }
  
  @SubscribeEvent
  public void onFogDensity(EntityViewRenderEvent.FogDensity event) {
    event.setDensity(0.0F);
    event.setCanceled(true);
  }
  
  @SubscribeEvent
  public void onFogColor(EntityViewRenderEvent.FogColors event) {
    event.setRed(55.0F);
    event.setGreen(55.0F);
    event.setBlue(55.0F);
  }
}
