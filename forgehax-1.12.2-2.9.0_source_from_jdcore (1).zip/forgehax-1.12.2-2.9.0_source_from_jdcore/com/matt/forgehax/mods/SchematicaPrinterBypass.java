package com.matt.forgehax.mods;

import com.matt.forgehax.Helper;
import com.matt.forgehax.asm.events.SchematicaPlaceBlockEvent;
import com.matt.forgehax.util.Utils;
import com.matt.forgehax.util.math.Angle;
import com.matt.forgehax.util.mod.Category;
import com.matt.forgehax.util.mod.ToggleMod;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.play.client.CPacketPlayer.Rotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@RegisterMod
public class SchematicaPrinterBypass
  extends ToggleMod
{
  public SchematicaPrinterBypass()
  {
    super(Category.MISC, "PrinterBypass", false, "Set silent angles for schematica printer");
  }
  
  @SubscribeEvent
  public void onPrinterBlockPlace(SchematicaPlaceBlockEvent event) {
    BlockPos lookpos = event.getPos().func_177972_a(event.getSide());
    Vec3d newvec = new Vec3d(lookpos.func_177958_n() + 0.5D, lookpos.func_177956_o() + 0.5D, lookpos.func_177952_p() + 0.5D);
    
    Angle lookAngle = Utils.getLookAtAngles(newvec);
    Helper.getNetworkManager()
      .func_179290_a(new CPacketPlayer.Rotation(lookAngle
      
      .getYaw(), lookAngle.getPitch(), getLocalPlayerfield_70122_E));
  }
}
