package com.matt.forgehax.mods;

import com.matt.forgehax.Helper;
import com.matt.forgehax.asm.events.PacketEvent.Incoming.Pre;
import com.matt.forgehax.events.WorldChangeEvent;
import com.matt.forgehax.util.command.Command;
import com.matt.forgehax.util.command.CommandBuilders;
import com.matt.forgehax.util.command.Setting;
import com.matt.forgehax.util.command.SettingBuilder;
import com.matt.forgehax.util.mod.ToggleMod;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.network.play.server.SPacketChangeGameState;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.storage.WorldInfo;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.ClientTickEvent;

@RegisterMod
public class NoWeather extends ToggleMod
{
  private boolean isRaining = false;
  private float rainStrength = 0.0F;
  private float previousRainStrength = 0.0F;
  
  public NoWeather() {
    super(com.matt.forgehax.util.mod.Category.WORLD, "NoWeather", false, "Disables weather");
  }
  





  private final Setting<Boolean> showStatus = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("hudstatus")).description("show info about suppressed weather"))
    .defaultTo(Boolean.valueOf(true))
    .build();
  
  private void saveState(World world) {
    if (world != null) {
      setState(world.func_72912_H().func_76059_o(), field_73004_o, field_73003_n);
    } else {
      setState(false, 1.0F, 1.0F);
    }
  }
  
  private void setState(boolean raining, float rainStrength, float previousRainStrength) {
    isRaining = raining;
    setState(rainStrength, previousRainStrength);
  }
  
  private void setState(float rainStrength, float previousRainStrength) {
    this.rainStrength = rainStrength;
    this.previousRainStrength = previousRainStrength;
  }
  
  private void disableRain() {
    if (Helper.getWorld() != null) {
      Helper.getWorld().func_72912_H().func_76084_b(false);
      Helper.getWorld().func_72894_k(0.0F);
    }
  }
  
  public void resetState() {
    if (Helper.getWorld() != null) {
      Helper.getWorld().func_72912_H().func_76084_b(isRaining);
      getWorldfield_73004_o = rainStrength;
      getWorldfield_73003_n = previousRainStrength;
    }
  }
  
  public void onEnabled()
  {
    saveState(Helper.getWorld());
  }
  
  public void onDisabled()
  {
    resetState();
  }
  
  @SubscribeEvent
  public void onWorldChange(WorldChangeEvent event) {
    saveState(event.getWorld());
  }
  
  @SubscribeEvent
  public void onWorldTick(TickEvent.ClientTickEvent event) {
    disableRain();
  }
  
  @SubscribeEvent
  public void onPacketIncoming(PacketEvent.Incoming.Pre event) {
    if ((event.getPacket() instanceof SPacketChangeGameState)) {
      int state = ((SPacketChangeGameState)event.getPacket()).func_149138_c();
      float strength = ((SPacketChangeGameState)event.getPacket()).func_149137_d();
      boolean isRainState = false;
      switch (state) {
      case 1: 
        isRainState = false;
        setState(false, 0.0F, 0.0F);
        break;
      case 2: 
        isRainState = true;
        setState(true, 1.0F, 1.0F);
        break;
      case 7: 
        isRainState = true;
      }
      
      if (isRainState) {
        disableRain();
        event.setCanceled(true);
      }
    }
  }
  
  public String getDisplayText()
  {
    if ((isRaining) && 
      (showStatus.getAsBoolean()) && (Helper.getWorld() != null) && (Helper.getLocalPlayer() != null)) {
      Biome biome = Helper.getWorld().func_180494_b(Helper.getLocalPlayer().func_180425_c());
      boolean canRain = biome.func_76738_d();
      boolean canSnow = biome.func_76746_c();
      
      String status;
      String status;
      if (Helper.getWorld().func_72911_I()) {
        status = "[Thunder]"; } else { String status;
        if (canSnow) {
          status = "[Snowing]"; } else { String status;
          if (!canRain) {
            status = "[Cloudy]";
          } else
            status = "[Raining]";
        }
      }
      return super.getDisplayText() + status;
    }
    return super.getDisplayText();
  }
}
