package com.matt.forgehax.mods;

import com.matt.forgehax.asm.reflection.FastReflection.Fields;
import com.matt.forgehax.events.RenderEvent;
import com.matt.forgehax.util.mod.ToggleMod;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.item.ItemStack;
import net.minecraftforge.client.event.EntityViewRenderEvent.FogDensity;
import net.minecraftforge.client.event.RenderBlockOverlayEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent.ElementType;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@com.matt.forgehax.util.mod.loader.RegisterMod
public class AntiOverlayMod extends ToggleMod
{
  public AntiOverlayMod()
  {
    super(com.matt.forgehax.util.mod.Category.PLAYER, "AntiOverlay", false, "Removes screen overlays");
  }
  


  @SubscribeEvent
  public void onFogRender(EntityViewRenderEvent.FogDensity event)
  {
    if ((event.getState().func_185904_a().equals(net.minecraft.block.material.Material.field_151586_h)) || 
      (event.getState().func_185904_a().equals(net.minecraft.block.material.Material.field_151587_i))) {
      event.setDensity(0.0F);
      event.setCanceled(true);
    }
  }
  


  @SubscribeEvent
  public void onRenderBlockOverlay(RenderBlockOverlayEvent event)
  {
    event.setCanceled(true);
  }
  
  @SubscribeEvent
  public void onRenderGameOverlay(RenderGameOverlayEvent event) {
    if ((event.getType().equals(RenderGameOverlayEvent.ElementType.HELMET)) || 
      (event.getType().equals(RenderGameOverlayEvent.ElementType.PORTAL))) {
      event.setCanceled(true);
    }
  }
  
  @SubscribeEvent
  public void onRender(RenderEvent event) {
    ItemStack item = (ItemStack)FastReflection.Fields.EntityRenderer_itemActivationItem.get(MCfield_71460_t);
    
    if ((item != null) && (item.func_77973_b() == net.minecraft.init.Items.field_190929_cY)) {
      FastReflection.Fields.EntityRenderer_itemActivationItem.set(MCfield_71460_t, null);
    }
  }
}
