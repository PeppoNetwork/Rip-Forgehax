package com.matt.forgehax.mods;

import com.matt.forgehax.Helper;
import com.matt.forgehax.util.command.Command;
import com.matt.forgehax.util.command.CommandBuilders;
import com.matt.forgehax.util.command.Setting;
import com.matt.forgehax.util.command.SettingBuilder;
import com.matt.forgehax.util.entity.EntityUtils;
import com.matt.forgehax.util.mod.ToggleMod;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.PlayerControllerMP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.init.Items;
import net.minecraft.inventory.ClickType;
import net.minecraft.inventory.Container;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.RayTraceResult.Type;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.ClientTickEvent;

@com.matt.forgehax.util.mod.loader.RegisterMod
public class AutoBucketFallMod extends ToggleMod
{
  public AutoBucketFallMod()
  {
    super(com.matt.forgehax.util.mod.Category.PLAYER, "AutoBucket", false, "Automatically place bucket to reset fall damage");
  }
  





  public final Setting<Double> preHeight = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("PreHeight")).description("how far below to check before preparing"))
    .defaultTo(Double.valueOf(10.0D))
    .build();
  




  public final Setting<Double> settingFallHeight = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("height")).description("minimum fall distance to work"))
    .defaultTo(Double.valueOf(15.0D))
    .build();
  
  private ItemStack WATER_BUCKET = new ItemStack(Items.field_151131_as);
  
  @SubscribeEvent
  public void onClientTick(TickEvent.ClientTickEvent event) {
    if ((Helper.getLocalPlayer() == null) || 
      (getLocalPlayerfield_70143_R < settingFallHeight.getAsDouble()) || 
      (!getLocalPlayerfield_71071_by.func_70431_c(WATER_BUCKET)) || 
      (EntityUtils.isInWater(Helper.getLocalPlayer())) || 
      (EntityUtils.isAboveWater(Helper.getLocalPlayer()))) {
      return;
    }
    
    Vec3d playerPos = Helper.getLocalPlayer().func_174791_d();
    Vec3d rayTraceBucket = new Vec3d(field_72450_a, field_72448_b - 5.0D, field_72449_c);
    


    Vec3d rayTracePre = new Vec3d(field_72450_a, field_72448_b - preHeight.getAsDouble(), field_72449_c);
    

    RayTraceResult result = MCfield_71441_e.func_72901_a(playerPos, rayTraceBucket, true);
    RayTraceResult resultPre = MCfield_71441_e.func_72901_a(playerPos, rayTracePre, true);
    
    if ((resultPre != null) && 
      (field_72313_a.equals(RayTraceResult.Type.BLOCK)) && 
      (!(Helper.getWorld().func_180495_p(resultPre.func_178782_a()).func_177230_c() instanceof BlockLiquid)))
    {
      getLocalPlayerfield_70127_C = 90.0F;
      getLocalPlayerfield_70125_A = 90.0F;
      
      int bucketSlot = findBucketHotbar();
      if (bucketSlot == -1) {
        bucketSlot = findBucketInv();
      }
      if (bucketSlot > 8) {
        swap(bucketSlot, 
        
          getLocalPlayerfield_71071_by.field_70461_c);
      } else {
        MCfield_71439_g.field_71071_by.field_70461_c = bucketSlot;
      }
    }
    
    if ((result != null) && 
      (field_72313_a.equals(RayTraceResult.Type.BLOCK)) && 
      (!(Helper.getWorld().func_180495_p(result.func_178782_a()).func_177230_c() instanceof BlockLiquid)))
    {
      Helper.getNetworkManager().func_179290_a(new net.minecraft.network.play.client.CPacketPlayer.Rotation(
      
        getLocalPlayerfield_70177_z, 90.0F, 
        
        getLocalPlayerfield_70122_E));
      getLocalPlayerfield_70127_C = 90.0F;
      getLocalPlayerfield_70125_A = 90.0F;
      

      MCfield_71442_b.func_187101_a(Helper.getLocalPlayer(), Helper.getWorld(), net.minecraft.util.EnumHand.MAIN_HAND);
    }
  }
  
  private int findBucketInv() {
    return getLocalPlayerfield_71071_by.func_184429_b(WATER_BUCKET);
  }
  
  private int findBucketHotbar() {
    for (int i = 0; i < 9; i++)
    {
      if (getLocalPlayerfield_71071_by.func_70301_a(i).func_77973_b() == Items.field_151131_as) {
        return i;
      }
    }
    return -1;
  }
  
  private void swap(int slot, int hotbarNum) {
    MCfield_71442_b.func_187098_a(
      getLocalPlayerfield_71069_bz.field_75152_c, slot, hotbarNum, ClickType.SWAP, 
      


      Helper.getLocalPlayer());
  }
}
