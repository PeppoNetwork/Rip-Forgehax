package com.matt.forgehax.mods;

import com.matt.forgehax.Helper;
import com.matt.forgehax.events.RenderEvent;
import com.matt.forgehax.util.color.Color;
import com.matt.forgehax.util.color.Colors;
import com.matt.forgehax.util.mod.Category;
import com.matt.forgehax.util.mod.ToggleMod;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import com.matt.forgehax.util.tesselation.GeometryTessellator;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityItemFrame;
import net.minecraft.entity.item.EntityMinecartChest;
import net.minecraft.item.ItemShulkerBox;
import net.minecraft.item.ItemStack;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityChest;
import net.minecraft.tileentity.TileEntityDispenser;
import net.minecraft.tileentity.TileEntityEnderChest;
import net.minecraft.tileentity.TileEntityFurnace;
import net.minecraft.tileentity.TileEntityHopper;
import net.minecraft.tileentity.TileEntityShulkerBox;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@RegisterMod
public class StorageESPMod
  extends ToggleMod
{
  public StorageESPMod()
  {
    super(Category.RENDER, "StorageESP", false, "Shows storage");
  }
  
  private int getTileEntityColor(TileEntity tileEntity) {
    if (((tileEntity instanceof TileEntityChest)) || ((tileEntity instanceof TileEntityDispenser)) || ((tileEntity instanceof TileEntityShulkerBox)))
    {

      return Colors.ORANGE.toBuffer(); }
    if ((tileEntity instanceof TileEntityEnderChest))
      return Colors.PURPLE.toBuffer();
    if ((tileEntity instanceof TileEntityFurnace))
      return Colors.GRAY.toBuffer();
    if ((tileEntity instanceof TileEntityHopper)) {
      return Colors.DARK_RED.toBuffer();
    }
    return -1;
  }
  
  private int getEntityColor(Entity entity)
  {
    if ((entity instanceof EntityMinecartChest))
      return Colors.ORANGE.toBuffer();
    if (((entity instanceof EntityItemFrame)) && 
      ((((EntityItemFrame)entity).func_82335_i().func_77973_b() instanceof ItemShulkerBox))) {
      return Colors.YELLOW.toBuffer();
    }
    return -1;
  }
  
  @SubscribeEvent
  public void onRender(RenderEvent event)
  {
    event.getBuffer().func_181668_a(1, DefaultVertexFormats.field_181706_f);
    
    for (TileEntity tileEntity : getWorldfield_147482_g) {
      BlockPos pos = tileEntity.func_174877_v();
      
      int color = getTileEntityColor(tileEntity);
      if (color != -1) {
        GeometryTessellator.drawCuboid(event.getBuffer(), pos, 63, color);
      }
    }
    
    for (Entity entity : getWorldfield_72996_f) {
      BlockPos pos = entity.func_180425_c();
      int color = getEntityColor(entity);
      if (color != -1) {
        GeometryTessellator.drawCuboid(
          event.getBuffer(), (entity instanceof EntityItemFrame) ? pos
          .func_177982_a(0, -1, 0) : pos, 63, color);
      }
    }
    


    event.getTessellator().func_78381_a();
  }
}
