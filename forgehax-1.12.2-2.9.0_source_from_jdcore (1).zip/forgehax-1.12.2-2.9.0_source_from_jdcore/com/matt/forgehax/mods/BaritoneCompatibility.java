package com.matt.forgehax.mods;

import com.matt.forgehax.Helper;
import com.matt.forgehax.events.ForgeHaxEvent;
import com.matt.forgehax.events.LocalPlayerUpdateEvent;
import com.matt.forgehax.util.command.Command;
import com.matt.forgehax.util.command.CommandBuilders;
import com.matt.forgehax.util.command.Setting;
import com.matt.forgehax.util.command.SettingBuilder;
import com.matt.forgehax.util.mod.Category;
import com.matt.forgehax.util.mod.ToggleMod;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.event.world.WorldEvent.Unload;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;


@RegisterMod
public class BaritoneCompatibility
  extends ToggleMod
{
  private final Setting<String> on_string = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("on-string")).description("Message to enable baritone"))
    .defaultTo("#mine diamond_ore")
    .build();
  





  private final Setting<String> off_string = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("off-string")).description("Message to disable baritone"))
    .defaultTo("#stop")
    .build();
  
  public BaritoneCompatibility() {
    super(Category.MISC, "BaritoneCompatibility", false, "the lazy compatibility mod");
  }
  
  private boolean off = false;
  private boolean once = false;
  
  private void turnOn() {
    off = false;
    Helper.getLocalPlayer().func_71165_d((String)on_string.get());
  }
  
  private void turnOff() {
    off = true;
    Helper.getLocalPlayer().func_71165_d((String)off_string.get());
  }
  
  protected void onDisabled()
  {
    off = (this.once = 0);
  }
  
  @SubscribeEvent
  public void onWorldUnload(WorldEvent.Unload event) {
    onDisabled();
  }
  
  @SubscribeEvent
  public void onTick(LocalPlayerUpdateEvent event) {
    if (!once) {
      once = true;
      BlockPos pos = Helper.getLocalPlayer().func_180425_c();
      if ((pos.func_177958_n() != 0) && (pos.func_177952_p() != 0)) {
        turnOn();
      }
    }
  }
  
  @SubscribeEvent
  public void onEvent(ForgeHaxEvent event) {
    if (Helper.getLocalPlayer() == null) {
      return;
    }
    
    switch (1.$SwitchMap$com$matt$forgehax$events$ForgeHaxEvent$Type[event.getType().ordinal()]) {
    case 1: 
    case 2: 
      if (!off) {
        turnOff();
      }
      
      break;
    case 3: 
      turnOn();
    }
  }
}
