package com.matt.forgehax.mods;

import com.matt.forgehax.Helper;
import com.matt.forgehax.util.mod.ToggleMod;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.RayTraceResult.Type;
import net.minecraftforge.client.event.MouseEvent;
import org.lwjgl.input.Mouse;

@RegisterMod
public class ManualDeleteMod extends ToggleMod
{
  public ManualDeleteMod()
  {
    super(com.matt.forgehax.util.mod.Category.WORLD, "ManualEntityDelete", false, "Manually delete entities with middle click");
  }
  
  @net.minecraftforge.fml.common.eventhandler.SubscribeEvent
  public void onInput(MouseEvent event)
  {
    if ((Helper.getWorld() == null) || (Helper.getLocalPlayer() == null)) {
      return;
    }
    
    if ((event.getButton() == 2) && (Mouse.getEventButtonState())) {
      RayTraceResult aim = MCfield_71476_x;
      if (aim == null) {
        return;
      }
      if ((field_72313_a == RayTraceResult.Type.ENTITY) && 
        (field_72308_g != null)) {
        MCfield_71441_e.func_72900_e(field_72308_g);
      }
    }
  }
}
