package com.matt.forgehax.mods;

import com.matt.forgehax.Helper;
import com.matt.forgehax.asm.events.PacketEvent.Incoming.Pre;
import com.matt.forgehax.asm.events.PacketEvent.Outgoing.Pre;
import com.matt.forgehax.util.FileManager;
import com.matt.forgehax.util.mod.Category;
import com.matt.forgehax.util.mod.ToggleMod;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import net.minecraft.network.Packet;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.client.CPacketCustomPayload;
import net.minecraft.network.play.server.SPacketCustomPayload;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@RegisterMod
public class CustomPayloadLogger
  extends ToggleMod
{
  private static final Path CLIENT_PAYLOAD_LOG = Helper.getFileManager().getMkBaseResolve(new String[] { "logs/payload/client2server_payload.log" });
  
  private static final Path SERVER_PAYLOAD_LOG = Helper.getFileManager().getMkBaseResolve(new String[] { "logs/payload/server2client_payload.log" });
  
  public CustomPayloadLogger() {
    super(Category.MISC, "PayloadLogger", false, "Logs custom payloads");
  }
  
  private void log(Packet packet) {
    if ((packet instanceof SPacketCustomPayload)) {
      SPacketCustomPayload payloadPacket = (SPacketCustomPayload)packet;
      
      String input = String.format("%s=%s\n", new Object[] {payloadPacket
      
        .func_149169_c(), payloadPacket.func_180735_b().toString() });
      try {
        Files.write(SERVER_PAYLOAD_LOG, input
        
          .getBytes(), new OpenOption[] { StandardOpenOption.CREATE, StandardOpenOption.APPEND });

      }
      catch (Exception localException) {}
    }
    else if ((packet instanceof CPacketCustomPayload)) {
      CPacketCustomPayload payloadPacket = (CPacketCustomPayload)packet;
      
      String input = String.format("%s=%s\n", new Object[] {payloadPacket
      
        .func_149559_c(), payloadPacket.func_180760_b().toString() });
      try {
        Files.write(CLIENT_PAYLOAD_LOG, input
        
          .getBytes(), new OpenOption[] { StandardOpenOption.CREATE, StandardOpenOption.APPEND });
      }
      catch (Exception localException1) {}
    }
  }
  

  @SubscribeEvent
  public void onOutgoingCustomPayload(PacketEvent.Outgoing.Pre event)
  {
    log(event.getPacket());
  }
  
  @SubscribeEvent
  public void onIncomingCustomPayload(PacketEvent.Incoming.Pre event) {
    log(event.getPacket());
  }
}
