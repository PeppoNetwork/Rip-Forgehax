package com.matt.forgehax.mods;

import com.matt.forgehax.Helper;
import com.matt.forgehax.asm.events.AddCollisionBoxToListEvent;
import com.matt.forgehax.util.command.Command;
import com.matt.forgehax.util.command.CommandBuilders;
import com.matt.forgehax.util.command.Setting;
import com.matt.forgehax.util.command.SettingBuilder;
import com.matt.forgehax.util.mod.ToggleMod;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@RegisterMod
public class SafeWalkMod extends ToggleMod
{
  public SafeWalkMod()
  {
    super(com.matt.forgehax.util.mod.Category.PLAYER, "SafeWalk", false, "Prevents you from falling off blocks");
  }
  





  private final Setting<Boolean> collisions = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("collisions")).description("Give air collision boxes"))
    .defaultTo(Boolean.valueOf(false))
    .build();
  




  private final Setting<Integer> min_height = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("min-height")).description("Minimum height above ground for collisions"))
    .defaultTo(Integer.valueOf(15))
    .build();
  
  @SubscribeEvent
  public void onAddCollisionBox(AddCollisionBoxToListEvent event) {
    if (!((Boolean)collisions.get()).booleanValue()) {
      return;
    }
    
    if ((Helper.getLocalPlayer() != null) && (
      (com.matt.forgehax.util.entity.EntityUtils.isDrivenByPlayer(event.getEntity())) || 
      (event.getEntity() == Helper.getLocalPlayer())))
    {
      AxisAlignedBB axisalignedbb = new AxisAlignedBB(event.getPos()).func_186664_h(0.3D);
      if ((event.getEntityBox().func_72326_a(axisalignedbb)) && 
        (isAbovePlayer(event.getPos())) && 
        (!hasCollisionBox(event.getPos())) && 
        (!isAboveBlock(event.getPos(), ((Integer)min_height.get()).intValue())))
      {
        event.getCollidingBoxes().add(axisalignedbb);
      }
    }
  }
  
  private boolean isAbovePlayer(BlockPos pos)
  {
    return pos.func_177956_o() >= getLocalPlayerfield_70163_u;
  }
  
  private boolean isAboveBlock(BlockPos pos, int minHeight)
  {
    for (int i = 0; i < minHeight; i++) {
      if (hasCollisionBox(pos.func_177979_c(i))) {
        return true;
      }
    }
    return false;
  }
  
  private boolean hasCollisionBox(BlockPos pos) {
    return MCfield_71441_e.func_180495_p(pos).func_185890_d(MCfield_71441_e, pos) != null;
  }
  
  public void onEnabled()
  {
    com.matt.forgehax.asm.ForgeHaxHooks.isSafeWalkActivated = true;
  }
  
  public void onDisabled()
  {
    com.matt.forgehax.asm.ForgeHaxHooks.isSafeWalkActivated = false;
  }
}
