package com.matt.forgehax.mods;

import com.matt.forgehax.Helper;
import com.matt.forgehax.util.command.Command;
import com.matt.forgehax.util.command.CommandBuilders;
import com.matt.forgehax.util.command.Setting;
import com.matt.forgehax.util.command.SettingBuilder;
import com.matt.forgehax.util.mod.Category;
import com.matt.forgehax.util.mod.ToggleMod;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.util.Session;
import net.minecraft.util.text.ITextComponent;
import net.minecraftforge.client.event.ClientChatReceivedEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@RegisterMod
public class AutoReply extends ToggleMod
{
  public final Setting<String> reply = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("reply")).description("Text to reply with"))
    .defaultTo("fuck off newfag")
    .build();
  





  public final Setting<String> mode = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("mode")).description("Reply or chat"))
    .defaultTo("REPLY")
    .build();
  





  public final Setting<String> search = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("search")).description("Text to search for in message"))
    .defaultTo("whispers: ")
    .build();
  
  public AutoReply() {
    super(Category.MISC, "AutoReply", false, "Automatically talk in chat if finds a strings");
  }
  
  @SubscribeEvent
  public void onClientChat(ClientChatReceivedEvent event) {
    String message = event.getMessage().func_150260_c();
    if ((message.matches((String)search.get())) && (!message.startsWith(MC.func_110432_I().func_111285_a()))) { String append;
      String append;
      switch (((String)mode.get()).toUpperCase()) {
      case "REPLY": 
        append = "/r ";
        break;
      case "CHAT": 
      default: 
        append = "";
      }
      
      Helper.getLocalPlayer().func_71165_d(append + (String)reply.get());
    }
  }
}
