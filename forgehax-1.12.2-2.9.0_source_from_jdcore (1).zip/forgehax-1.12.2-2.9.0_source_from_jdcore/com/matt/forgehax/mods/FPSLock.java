package com.matt.forgehax.mods;

import com.matt.forgehax.util.command.Command;
import com.matt.forgehax.util.command.CommandBuilders;
import com.matt.forgehax.util.command.Setting;
import com.matt.forgehax.util.command.SettingBuilder;
import com.matt.forgehax.util.mod.Category;
import com.matt.forgehax.util.mod.ToggleMod;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.settings.GameSettings;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.ClientTickEvent;
import org.lwjgl.opengl.Display;

@RegisterMod
public class FPSLock extends ToggleMod
{
  private final Setting<Integer> defaultFps = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("default-fps")).description("default FPS to revert to"))
    .defaultTo(Integer.valueOf(MCfield_71474_y.field_74350_i))
    .min(Integer.valueOf(1))
    .build();
  





  private final Setting<Integer> fps = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("fps")).description("FPS to use when the world is loaded. Set to 0 to disable."))
    .min(Integer.valueOf(0))
    .defaultTo(Integer.valueOf(0))
    .build();
  




  private final Setting<Integer> menu_fps = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("menu-fps")).description("FPS when the GUI is opened. Set to 0 to disable."))
    .min(Integer.valueOf(0))
    .defaultTo(Integer.valueOf(60))
    .build();
  





  private final Setting<Integer> no_focus_fps = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("no-focus-fps")).description("FPS when the game window doesn't have focus. Set to 0 to disable."))
    .min(Integer.valueOf(0))
    .defaultTo(Integer.valueOf(3))
    .build();
  
  public FPSLock() {
    super(Category.MISC, "FPSLock", false, "Lock the fps to a lower-than-allowed value, and restore when disabled");
  }
  



  private int getFps()
  {
    if ((((Integer)no_focus_fps.get()).intValue() > 0) && (!Display.isActive()))
      return ((Integer)no_focus_fps.get()).intValue();
    if (MCfield_71462_r != null) {
      return ((Integer)menu_fps.get()).intValue() > 0 ? ((Integer)menu_fps.get()).intValue() : ((Integer)defaultFps.get()).intValue();
    }
    return ((Integer)fps.get()).intValue() > 0 ? ((Integer)fps.get()).intValue() : ((Integer)defaultFps.get()).intValue();
  }
  

  protected void onDisabled()
  {
    MCfield_71474_y.field_74350_i = ((Integer)defaultFps.get()).intValue();
  }
  
  @SubscribeEvent
  void onTick(TickEvent.ClientTickEvent event) {
    switch (1.$SwitchMap$net$minecraftforge$fml$common$gameevent$TickEvent$Phase[phase.ordinal()]) {
    case 1: 
      MCfield_71474_y.field_74350_i = getFps();
      break;
    }
  }
}
