package com.matt.forgehax.mods;

import com.matt.forgehax.asm.ForgeHaxHooks;
import com.matt.forgehax.asm.utils.MultiBoolean;
import com.matt.forgehax.util.mod.ToggleMod;

@com.matt.forgehax.util.mod.loader.RegisterMod
public class NoCaveCulling extends ToggleMod
{
  public NoCaveCulling()
  {
    super(com.matt.forgehax.util.mod.Category.RENDER, "NoCaveCulling", false, "Disables mojangs dumb cave culling shit");
  }
  
  public void onEnabled()
  {
    ForgeHaxHooks.SHOULD_DISABLE_CAVE_CULLING.enable("NoCaveCulling");
  }
  
  public void onDisabled()
  {
    ForgeHaxHooks.SHOULD_DISABLE_CAVE_CULLING.disable("NoCaveCulling");
  }
}
