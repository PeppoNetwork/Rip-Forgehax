package com.matt.forgehax.mods;

import com.matt.forgehax.Helper;
import com.matt.forgehax.asm.events.AddCollisionBoxToListEvent;
import com.matt.forgehax.events.LocalPlayerUpdateEvent;
import com.matt.forgehax.util.command.Command;
import com.matt.forgehax.util.command.CommandBuilders;
import com.matt.forgehax.util.command.Setting;
import com.matt.forgehax.util.command.SettingBuilder;
import com.matt.forgehax.util.mod.ToggleMod;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@RegisterMod
public class AntiFireMod extends ToggleMod
{
  public AntiFireMod()
  {
    super(com.matt.forgehax.util.mod.Category.PLAYER, "AntiFire", false, "Removes fire");
  }
  





  private final Setting<Boolean> collisions = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("collisions")).description("Give fire collision boxes"))
    .defaultTo(Boolean.valueOf(false))
    .build();
  
  @SubscribeEvent
  public void onAddCollisionBox(AddCollisionBoxToListEvent event) {
    if (!((Boolean)collisions.get()).booleanValue()) {
      return;
    }
    
    if (Helper.getLocalPlayer() != null) {
      AxisAlignedBB bb = new AxisAlignedBB(event.getPos()).func_72321_a(0.0D, 0.1D, 0.0D);
      if ((event.getBlock() == net.minecraft.init.Blocks.field_150480_ab) && (isAbovePlayer(event.getPos())) && 
        (event.getEntityBox().func_72326_a(bb))) {
        event.getCollidingBoxes().add(bb);
      }
    }
  }
  
  private boolean isAbovePlayer(BlockPos pos) {
    return pos.func_177956_o() >= getLocalPlayerfield_70163_u;
  }
  
  @SubscribeEvent
  public void onUpdate(LocalPlayerUpdateEvent event) {
    event.getEntityLiving().func_70066_B();
  }
}
