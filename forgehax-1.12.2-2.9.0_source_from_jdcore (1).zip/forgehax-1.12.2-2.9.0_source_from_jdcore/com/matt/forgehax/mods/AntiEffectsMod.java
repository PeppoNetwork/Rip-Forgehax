package com.matt.forgehax.mods;

import com.matt.forgehax.asm.reflection.FastReflection.Methods;
import com.matt.forgehax.asm.utils.fasttype.FastMethod;
import com.matt.forgehax.util.command.Command;
import com.matt.forgehax.util.command.CommandBuilders;
import com.matt.forgehax.util.command.Setting;
import com.matt.forgehax.util.command.SettingBuilder;
import com.matt.forgehax.util.mod.Category;
import com.matt.forgehax.util.mod.ToggleMod;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.MobEffects;
import net.minecraftforge.event.entity.living.LivingEvent.LivingUpdateEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@RegisterMod
public class AntiEffectsMod extends ToggleMod
{
  public final Setting<Boolean> no_particles = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("no_particles")).description("Stops the particle effect from rendering on other entities"))
    .defaultTo(Boolean.valueOf(true))
    .build();
  
  public AntiEffectsMod() {
    super(Category.RENDER, "AntiPotionEffects", false, "Removes potion effects");
  }
  
  @SubscribeEvent
  public void onLivingUpdate(LivingEvent.LivingUpdateEvent event) {
    EntityLivingBase living = event.getEntityLiving();
    if (living.equals(MCfield_71439_g)) {
      living.func_82142_c(false);
      living.func_184589_d(MobEffects.field_76431_k);
      living.func_184589_d(MobEffects.field_76441_p);
      living.func_184589_d(MobEffects.field_76440_q);
      
      FastReflection.Methods.EntityLivingBase_resetPotionEffectMetadata.invoke(living, new Object[0]);
    } else if (((Boolean)no_particles.get()).booleanValue()) {
      living.func_82142_c(false);
      FastReflection.Methods.EntityLivingBase_resetPotionEffectMetadata.invoke(living, new Object[0]);
    }
  }
}
