package com.matt.forgehax.mods.managers;

import com.google.common.collect.Lists;
import com.matt.forgehax.Helper;
import com.matt.forgehax.asm.events.LocalPlayerUpdateMovementEvent.Post;
import com.matt.forgehax.asm.events.LocalPlayerUpdateMovementEvent.Pre;
import com.matt.forgehax.asm.events.PacketEvent.Incoming.Pre;
import com.matt.forgehax.util.Utils;
import com.matt.forgehax.util.command.Command;
import com.matt.forgehax.util.command.CommandBuilders;
import com.matt.forgehax.util.command.Setting;
import com.matt.forgehax.util.command.SettingBuilder;
import com.matt.forgehax.util.math.Angle;
import com.matt.forgehax.util.math.AngleHelper;
import com.matt.forgehax.util.mod.ServiceMod;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import com.matt.forgehax.util.task.SimpleManagerContainer;
import com.matt.forgehax.util.task.TaskChain;
import com.matt.forgehax.util.task.TaskChain.Builder;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.function.Consumer;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import net.minecraft.network.play.server.SPacketPlayerPosLook.EnumFlags;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.event.world.WorldEvent.Load;
import net.minecraftforge.event.world.WorldEvent.Unload;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;




@RegisterMod
public class PositionRotationManager
  extends ServiceMod
{
  private final Setting<Boolean> enabled = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("enabled")).description("Enables the mod"))
    .defaultTo(Boolean.valueOf(true))
    .build();
  
  private static final SimpleManagerContainer<MovementUpdateListener> MANAGER = new SimpleManagerContainer();
  
  private static final SimpleWrapperImpl STATE = new SimpleWrapperImpl(null);
  
  public static SimpleManagerContainer<MovementUpdateListener> getManager() {
    return MANAGER;
  }
  
  public static ReadableRotationState getState() {
    return STATE;
  }
  
  public PositionRotationManager() {
    super("PositionRotationManager");
  }
  





  public final Setting<Double> smooth = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("smooth")).description("Angle smoothing for bypassing anti-cheats. Set to 0 to disable"))
    .defaultTo(Double.valueOf(45.0D))
    .min(Double.valueOf(0.0D))
    .max(Double.valueOf(180.0D))
    .build();
  
  private final RotationState gState = new RotationState(null);
  private TaskChain<Consumer<ReadableRotationState>> futureTasks = TaskChain.empty();
  
  private static Angle getPlayerAngles(EntityPlayer player) {
    return Angle.degrees(field_70125_A, field_70177_z);
  }
  
  private static void setPlayerAngles(EntityPlayerSP player, Angle angles) {
    Angle original = getPlayerAngles(player);
    Angle diff = angles.normalize().sub(original.normalize()).normalize();
    field_70125_A = Utils.clamp(original.getPitch() + diff.getPitch(), -90.0F, 90.0F);
    field_70177_z = (original.getYaw() + diff.getYaw());
  }
  
  private static void setPlayerPosition(EntityPlayerSP player, Vec3d position) {
    field_70165_t = field_72450_a;
    field_70163_u = field_72448_b;
    field_70161_v = field_72449_c;
  }
  
  private float clampAngle(float from, float to, float clamp) {
    return AngleHelper.normalizeInDegrees(from + 
      Utils.clamp(AngleHelper.normalizeInDegrees(to - from), -clamp, clamp));
  }
  
  private Angle clampAngle(Angle from, Angle to, float clamp) {
    return Angle.degrees(
      clampAngle(from.getPitch(), to.getPitch(), clamp), 
      clampAngle(from.getYaw(), to.getYaw(), clamp));
  }
  
  private float getRotationCount(Angle from, Angle to, float clamp) {
    Angle diff = to.sub(from).normalize();
    float rp = diff.getPitch() / clamp;
    float ry = diff.getYaw() / clamp;
    return Math.max(Math.abs(rp), Math.abs(ry));
  }
  
  @SubscribeEvent
  public void onWorldLoad(WorldEvent.Load event) {
    gState.setInitialized(false);
  }
  
  @SubscribeEvent
  public void onWorldUnload(WorldEvent.Unload event) {
    gState.setInitialized(false);
  }
  
  @SubscribeEvent
  public void onMovementUpdatePre(LocalPlayerUpdateMovementEvent.Pre event) {
    if (!((Boolean)enabled.get()).booleanValue()) { return;
    }
    
    Angle va = getPlayerAngles(event.getLocalPlayer());
    
    if (!gState.isInitialized()) {
      gState.setServerAngles(va);
      gState.setClientAngles(va);
      gState.setInitialized(true);
    }
    
    RotationState gs = new RotationState(null);
    gs.setServerAngles(gState.getServerAngles());
    gs.setClientAngles(va);
    

    boolean changed = false;
    

    boolean clientOnly = false;
    
    PositionRotationManager.RotationState.Local ls = null;
    
    for (MovementUpdateListener listener : getManager().functions()) {
      ls = new PositionRotationManager.RotationState.Local(gs, null);
      listener.onLocalPlayerMovementUpdate(ls);
      
      boolean clientCng = ls.isClientAnglesChanged();
      boolean serverCng = ls.isServerAnglesChanged();
      
      if (ls.isCanceled())
      {
        event.setCanceled(true);
        

        RotationState rs = new RotationState(gs, null);
        rs.setServerAngles(gState.getServerAngles());
        synchronized (STATE) {
          STATE.setCurrentState(rs);
        }
        return; }
      if ((clientCng) || (serverCng)) {
        if ((!clientOnly) || (!clientCng))
        {

          if (clientOnly)
          {
            Angle cva = gs.getClientAngles();
            gs.copyOf(ls);
            gs.setClientAngles(cva);
            gs.setListener(listener);
            break; }
          if ((clientCng) && (!serverCng))
          {
            changed = true;
            clientOnly = true;
            gs.setClientAngles(ls.getClientAngles());
          } else {
            changed = true;
            gs.copyOf(ls);
            gs.setListener(listener);
            break;
          }
        } } else if (ls.isHalted())
      {
        changed = true;
        gs.copyOf(ls);
        gs.setListener(listener);
        break;
      }
    }
    
    if ((gs.getListener() == null) && (gState.getListener() == null)) {
      gs.setServerAngles(gs.getClientAngles());
    } else if ((gs.getListener() == null) && (gState.getListener() != null)) {
      getManager().finish(gState.getListener());
      gs.setServerAngles(gs.getClientAngles());
    } else if (gState.getListener() != gs.getListener()) {
      getManager().begin(gs.getListener());
    }
    
    if (((Double)smooth.get()).doubleValue() > 0.0D)
    {
      Angle start = gState.getServerAngles();
      
      Angle dest = gs.getServerAngles();
      
      gs.setServerAngles(clampAngle(start, dest, smooth.getAsFloat()));
      
      if (getRotationCount(start, dest, smooth.getAsFloat()) <= 1.0F) {
        futureTasks = (ls != null ? ls.getFutureTasks() : TaskChain.empty());
      } else {
        futureTasks = TaskChain.empty();
      }
    }
    else {
      futureTasks = (ls != null ? ls.getFutureTasks() : TaskChain.empty());
    }
    
    gState.copyOf(gs);
    

    setPlayerAngles(event.getLocalPlayer(), gState.getServerAngles().inDegrees().normalize());
  }
  
  @SubscribeEvent
  public void onMovementUpdatePost(LocalPlayerUpdateMovementEvent.Post event) {
    if (!((Boolean)enabled.get()).booleanValue()) { return;
    }
    
    if (gState.isSilent()) {
      setPlayerAngles(event.getLocalPlayer(), gState.getClientAngles().inDegrees().normalize());
    }
    

    while (futureTasks.hasNext()) {
      ((Consumer)futureTasks.next()).accept(gState);
    }
    
    futureTasks = TaskChain.empty();
    

    STATE.setCurrentState(gState);
  }
  
  @SubscribeEvent(priority=EventPriority.HIGHEST)
  public void onPacketReceived(PacketEvent.Incoming.Pre event) {
    if (!((Boolean)enabled.get()).booleanValue()) { return;
    }
    if ((event.getPacket() instanceof SPacketPlayerPosLook))
    {
      SPacketPlayerPosLook packet = (SPacketPlayerPosLook)event.getPacket();
      
      float pitch = packet.func_148930_g();
      float yaw = packet.func_148931_f();
      
      Angle va = gState.getClientAngles();
      
      if (packet.func_179834_f().contains(SPacketPlayerPosLook.EnumFlags.X_ROT)) {
        pitch += va.getPitch();
      }
      if (packet.func_179834_f().contains(SPacketPlayerPosLook.EnumFlags.Y_ROT)) {
        yaw += va.getYaw();
      }
      gState.setServerAngles(pitch, yaw);
      gState.setInitialized(true);
    }
  }
  





  public static abstract interface MovementUpdateListener
  {
    public abstract void onLocalPlayerMovementUpdate(PositionRotationManager.RotationState.Local paramLocal);
  }
  




  public static abstract interface ReadableRotationState
  {
    public EntityPlayerSP getLocalPlayer()
    {
      return Helper.getLocalPlayer();
    }
    






    public abstract Angle getClientAngles();
    





    public abstract Angle getServerAngles();
    





    public Angle getRenderClientViewAngles()
    {
      return isActive() ? getClientAngles() : 
        Angle.degrees(getLocalPlayerfield_70125_A, getLocalPlayerfield_70177_z);
    }
    





    public Angle getRenderServerViewAngles()
    {
      return isActive() ? getServerAngles() : 
        Angle.degrees(getLocalPlayerfield_70125_A, getLocalPlayerfield_70177_z);
    }
    





    public abstract boolean isSilent();
    




    public boolean isActive()
    {
      return getListener() != null;
    }
    


    public abstract PositionRotationManager.MovementUpdateListener getListener();
  }
  


  public static class RotationState
    implements PositionRotationManager.ReadableRotationState
  {
    private boolean initialized = false;
    
    private Angle serverViewAngles = Angle.ZERO;
    private Angle clientViewAngles = Angle.ZERO;
    
    private PositionRotationManager.MovementUpdateListener listener = null;
    
    private RotationState() {}
    
    private RotationState(RotationState other)
    {
      copyOf(other);
    }
    
    private void copyOf(RotationState other) {
      serverViewAngles = serverViewAngles;
      clientViewAngles = clientViewAngles;
      listener = listener;
    }
    
    private boolean isInitialized() {
      return initialized;
    }
    
    private void setInitialized(boolean initialized) {
      this.initialized = initialized;
    }
    
    public Angle getServerAngles() {
      return serverViewAngles;
    }
    
    public void setServerAngles(Angle va) {
      Objects.requireNonNull(va);
      serverViewAngles = va.normalize();
    }
    
    public void setServerAngles(float pitch, float yaw) {
      setServerAngles(Angle.degrees(pitch, yaw));
    }
    
    public Angle getClientAngles() {
      return clientViewAngles;
    }
    
    public void setClientAngles(Angle va) {
      Objects.requireNonNull(va);
      clientViewAngles = va.normalize();
    }
    
    public void setClientAngles(float pitch, float yaw) {
      setClientAngles(Angle.degrees(pitch, yaw));
    }
    
    public void setViewAngles(Angle va, boolean silent) {
      setServerAngles(va);
      if (!silent) {
        setClientAngles(va);
      }
    }
    
    public void setViewAngles(float pitch, float yaw, boolean silent) {
      setServerAngles(pitch, yaw);
      if (!silent) {
        setClientAngles(pitch, yaw);
      }
    }
    
    public void setViewAngles(Angle va) {
      setViewAngles(va, false);
    }
    
    public void setViewAngles(float pitch, float yaw) {
      setViewAngles(pitch, yaw, false);
    }
    
    public void setViewAnglesSilent(Angle va) {
      setViewAngles(va, true);
    }
    
    public void setViewAnglesSilent(float pitch, float yaw) {
      setViewAngles(pitch, yaw, true);
    }
    
    public boolean isSilent() {
      return !Objects.equals(clientViewAngles, serverViewAngles);
    }
    
    public PositionRotationManager.MovementUpdateListener getListener() {
      return listener;
    }
    
    private void setListener(PositionRotationManager.MovementUpdateListener listener) {
      this.listener = listener;
    }
    
    protected TaskChain<Consumer<PositionRotationManager.ReadableRotationState>> getFutureTasks() {
      return TaskChain.empty();
    }
    


    public static class Local
      extends PositionRotationManager.RotationState
    {
      private final List<Consumer<PositionRotationManager.ReadableRotationState>> later = Lists.newArrayList();
      
      private boolean serverAnglesChanged = false;
      private boolean clientAnglesChanged = false;
      private boolean halted = false;
      private boolean canceled = false;
      private boolean clientSided = false;
      
      private Local(PositionRotationManager.RotationState other) {
        super(null);
      }
      
      public void setServerAngles(Angle va)
      {
        super.setServerAngles(va);
        serverAnglesChanged = true;
      }
      
      public void setClientAngles(Angle va)
      {
        super.setClientAngles(va);
        clientAnglesChanged = true;
      }
      
      protected TaskChain<Consumer<PositionRotationManager.ReadableRotationState>> getFutureTasks()
      {
        return TaskChain.builder().addAll(later).build();
      }
      
      public void invokeLater(Consumer<PositionRotationManager.ReadableRotationState> task) {
        later.add(task);
      }
      
      public boolean isHalted() {
        return halted;
      }
      
      public void setHalted(boolean halted) {
        this.halted = halted;
      }
      
      public boolean isCanceled() {
        return canceled;
      }
      
      public void setCanceled(boolean canceled) {
        this.canceled = canceled;
      }
      
      public boolean isClientSided() {
        return clientSided;
      }
      
      public void setClientSided(boolean clientSided) {
        this.clientSided = clientSided;
      }
      
      public boolean isServerAnglesChanged() {
        return serverAnglesChanged;
      }
      
      public boolean isClientAnglesChanged() {
        return clientAnglesChanged;
      }
    }
  }
  
  private static class SimpleWrapperImpl implements PositionRotationManager.ReadableRotationState
  {
    private PositionRotationManager.ReadableRotationState state = new PositionRotationManager.ReadableRotationState()
    {
      public Angle getClientAngles()
      {
        return Angle.ZERO;
      }
      
      public Angle getServerAngles()
      {
        return Angle.ZERO;
      }
      
      public boolean isSilent()
      {
        return false;
      }
      


      public PositionRotationManager.MovementUpdateListener getListener() { return null; }
    };
    
    private SimpleWrapperImpl() {}
    
    private void setCurrentState(PositionRotationManager.ReadableRotationState state) { Objects.requireNonNull(state);
      this.state = state;
    }
    
    public synchronized Angle getClientAngles()
    {
      return state.getClientAngles();
    }
    
    public synchronized Angle getServerAngles()
    {
      return state.getServerAngles();
    }
    
    public synchronized boolean isSilent()
    {
      return state.isSilent();
    }
    
    public synchronized PositionRotationManager.MovementUpdateListener getListener()
    {
      return state.getListener();
    }
  }
}
