package com.matt.forgehax.mods;

import com.matt.forgehax.events.RenderEvent;
import com.matt.forgehax.util.color.Color;
import com.matt.forgehax.util.color.Colors;
import com.matt.forgehax.util.command.Command;
import com.matt.forgehax.util.command.CommandBuilders;
import com.matt.forgehax.util.command.Setting;
import com.matt.forgehax.util.command.SettingBuilder;
import com.matt.forgehax.util.mod.Category;
import com.matt.forgehax.util.mod.ToggleMod;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import com.matt.forgehax.util.tesselation.GeometryTessellator;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@RegisterMod
public class RegionBorder
  extends ToggleMod
{
  private final Setting<Integer> chunkDistance = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("chunk-distance")).description("how many chunks in front of the region the border should be drawn. I you don't want it just set it to 0 so it is like the normal region border."))
    .defaultTo(Integer.valueOf(5))
    .build();
  


  private final Setting<Boolean> drawRegionBorder = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("draw-region-border")).description("whether you even want to draw the actual region border."))
    .defaultTo(Boolean.valueOf(true))
    .build();
  
  public RegionBorder()
  {
    super(Category.RENDER, "RegionBorder", false, "Shows a border in front of the edge of the region you are in.");
  }
  



  @SubscribeEvent
  public void onRender(RenderEvent event)
  {
    event.getBuffer().func_181668_a(1, DefaultVertexFormats.field_181706_f);
    
    BlockPos from = new BlockPos((int)MCfield_71439_g.field_70165_t / 512 * 512, 0, (int)MCfield_71439_g.field_70161_v / 512 * 512);
    BlockPos to = from.func_177982_a(511, 256, 511);
    
    int color = Colors.ORANGE.toBuffer();
    if (drawRegionBorder.getAsBoolean()) {
      GeometryTessellator.drawCuboid(event.getBuffer(), from, to, 63, color);
    }
    
    int chunkDistanceSetting = chunkDistance.getAsInteger() * 16;
    from = from.func_177982_a(chunkDistanceSetting, 0, chunkDistanceSetting);
    to = to.func_177982_a(-chunkDistanceSetting, 0, -chunkDistanceSetting);
    
    color = Colors.YELLOW.toBuffer();
    GeometryTessellator.drawCuboid(event.getBuffer(), from, to, 63, color);
    
    event.getTessellator().func_78381_a();
  }
}
