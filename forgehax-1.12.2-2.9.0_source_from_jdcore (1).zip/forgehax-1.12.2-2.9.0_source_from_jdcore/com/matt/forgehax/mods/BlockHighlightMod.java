package com.matt.forgehax.mods;

import com.matt.forgehax.asm.events.DrawBlockBoundingBoxEvent.Post;
import com.matt.forgehax.asm.events.DrawBlockBoundingBoxEvent.Pre;
import com.matt.forgehax.util.command.Command;
import com.matt.forgehax.util.command.CommandBuilders;
import com.matt.forgehax.util.command.Setting;
import com.matt.forgehax.util.command.SettingBuilder;
import com.matt.forgehax.util.mod.Category;
import com.matt.forgehax.util.mod.ToggleMod;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@RegisterMod
public class BlockHighlightMod
  extends ToggleMod
{
  private final Setting<Integer> alpha = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("alpha")).description("alpha"))
    .min(Integer.valueOf(0))
    .max(Integer.valueOf(255))
    .defaultTo(Integer.valueOf(255))
    .build();
  




  private final Setting<Integer> red = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("red")).description("red"))
    .min(Integer.valueOf(0))
    .max(Integer.valueOf(255))
    .defaultTo(Integer.valueOf(0))
    .build();
  




  private final Setting<Integer> green = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("green")).description("green"))
    .min(Integer.valueOf(0))
    .max(Integer.valueOf(255))
    .defaultTo(Integer.valueOf(0))
    .build();
  




  private final Setting<Integer> blue = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("blue")).description("blue"))
    .min(Integer.valueOf(0))
    .max(Integer.valueOf(255))
    .defaultTo(Integer.valueOf(0))
    .build();
  





  private final Setting<Float> width = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("width")).description("line width"))
    .min(Float.valueOf(0.0F))
    .defaultTo(Float.valueOf(5.0F))
    .build();
  
  public BlockHighlightMod() {
    super(Category.RENDER, "BlockHighlight", false, "Make selected block bounding box more visible");
  }
  
  private float toFloat(int colorVal)
  {
    return colorVal / 255.0F;
  }
  
  @SubscribeEvent
  public void onRenderBoxPre(DrawBlockBoundingBoxEvent.Pre event) {
    GlStateManager.func_179097_i();
    GlStateManager.func_187441_d(((Float)width.get()).floatValue());
    alpha = toFloat(((Integer)alpha.get()).intValue());
    red = toFloat(((Integer)red.get()).intValue());
    green = toFloat(((Integer)green.get()).intValue());
    blue = toFloat(((Integer)blue.get()).intValue());
  }
  
  @SubscribeEvent
  public void onRenderBoxPost(DrawBlockBoundingBoxEvent.Post event) {}
}
