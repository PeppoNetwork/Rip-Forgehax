package com.matt.forgehax.mods;

import com.matt.forgehax.Helper;
import com.matt.forgehax.asm.events.PacketEvent.Incoming.Pre;
import com.matt.forgehax.asm.reflection.FastReflection.Fields;
import com.matt.forgehax.util.command.Command;
import com.matt.forgehax.util.command.CommandBuilders;
import com.matt.forgehax.util.command.Setting;
import com.matt.forgehax.util.command.SettingBuilder;
import com.matt.forgehax.util.mod.ToggleMod;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.GuiConnecting;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.login.server.SPacketLoginSuccess;
import net.minecraft.network.play.client.CPacketChatMessage;
import net.minecraft.util.Session;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import org.apache.logging.log4j.Logger;

@RegisterMod
public class InstantMessage extends ToggleMod
{
  private final Setting<String> message = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("message")).description("Message to send"))
    .defaultTo("Never fear on {SRVNAME}, {NAME} is here!")
    .build();
  
  public InstantMessage() {
    super(com.matt.forgehax.util.mod.Category.MISC, "InstantMessage", false, "Send message as soon as you join");
  }
  
  @SubscribeEvent
  public void onPacketIn(PacketEvent.Incoming.Pre event) {
    if ((event.getPacket() instanceof SPacketLoginSuccess))
    {
      if ((MCfield_71462_r instanceof GuiConnecting))
      {
        ServerData serverData = MC.func_147104_D();
        String serverName = serverData != null ? field_78847_a : "Unknown";
        String serverIP = serverData != null ? field_78845_b : "";
        
        ((NetworkManager)FastReflection.Fields.GuiConnecting_networkManager.get(MCfield_71462_r))
          .func_179290_a(new CPacketChatMessage(
          

          ((String)message.get())
          .replace("{SRVNAME}", serverName)
          .replace("{IP}", serverIP)
          .replace("{NAME}", MC.func_110432_I().func_111285_a())));
      } else {
        Helper.getLog().warn("Did not send message as current screen is not GuiConnecting");
      }
    }
  }
}
