package com.matt.forgehax.mods;

import com.matt.forgehax.util.mod.Category;
import com.matt.forgehax.util.mod.ToggleMod;


public class AutoElytra
  extends ToggleMod
{
  public AutoElytra()
  {
    super(Category.PLAYER, "AutoElytra", false, "Automatically deploy elytra");
  }
}
