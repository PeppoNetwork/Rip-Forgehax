package com.matt.forgehax.mods;

import com.matt.forgehax.Helper;
import com.matt.forgehax.events.LocalPlayerUpdateEvent;
import com.matt.forgehax.util.color.Colors;
import com.matt.forgehax.util.command.Command;
import com.matt.forgehax.util.command.CommandBuilders;
import com.matt.forgehax.util.command.Setting;
import com.matt.forgehax.util.command.SettingBuilder;
import com.matt.forgehax.util.math.AlignHelper.Align;
import com.matt.forgehax.util.mod.HudMod;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.world.WorldProvider;
import net.minecraftforge.client.event.RenderGameOverlayEvent.Text;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@com.matt.forgehax.util.mod.loader.RegisterMod
public class CoordsHud extends HudMod
{
  public CoordsHud()
  {
    super(com.matt.forgehax.util.mod.Category.RENDER, "CoordsHUD", false, "Display world coords");
  }
  





  private final Setting<Boolean> translate = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("translate")).description("show corresponding Nether or Overworld coords"))
    .defaultTo(Boolean.valueOf(true))
    .build();
  





  private final Setting<Boolean> multiline = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("multiline")).description("show translated coords above"))
    .defaultTo(Boolean.valueOf(true))
    .build();
  double thisX;
  
  protected AlignHelper.Align getDefaultAlignment() { return AlignHelper.Align.BOTTOMRIGHT; }
  
  protected int getDefaultOffsetX() { return 1; }
  
  protected int getDefaultOffsetY() { return 1; }
  
  protected double getDefaultScale() { return 1.0D; }
  

  double thisY;
  double thisZ;
  double otherX;
  double otherZ;
  @SubscribeEvent
  public void onLocalPlayerUpdate(LocalPlayerUpdateEvent ev)
  {
    if (Helper.getWorld() == null) { return;
    }
    EntityPlayerSP player = Helper.getLocalPlayer();
    thisX = field_70165_t;
    thisY = field_70163_u;
    thisZ = field_70161_v;
    
    double thisFactor = getWorldfield_73011_w.getMovementFactor();
    double otherFactor = thisFactor != 1.0D ? 1.0D : 8.0D;
    double travelFactor = thisFactor / otherFactor;
    otherX = (thisX * travelFactor);
    otherZ = (thisZ * travelFactor);
  }
  
  @SubscribeEvent
  public void onRenderOverlay(RenderGameOverlayEvent.Text event) {
    List<String> text = new ArrayList();
    
    if ((!((Boolean)translate.get()).booleanValue()) || ((((Boolean)translate.get()).booleanValue()) && (((Boolean)multiline.get()).booleanValue()))) {
      text.add(String.format("%01.1f, %01.0f, %01.1f", new Object[] { Double.valueOf(thisX), Double.valueOf(thisY), Double.valueOf(thisZ) }));
    }
    if (((Boolean)translate.get()).booleanValue()) {
      if (((Boolean)multiline.get()).booleanValue()) {
        text.add(String.format("(%01.1f, %01.1f)", new Object[] { Double.valueOf(otherX), Double.valueOf(otherZ) }));
      } else {
        text.add(String.format("%01.1f, %01.0f, %01.1f (%01.1f, %01.1f)", new Object[] {
          Double.valueOf(thisX), Double.valueOf(thisY), Double.valueOf(thisZ), Double.valueOf(otherX), Double.valueOf(otherZ) }));
      }
    }
    
    com.matt.forgehax.util.draw.SurfaceHelper.drawTextAlign(text, getPosX(0), getPosY(0), Colors.WHITE
      .toBuffer(), ((Double)scale.get()).doubleValue(), true, ((AlignHelper.Align)alignment.get()).ordinal());
  }
}
