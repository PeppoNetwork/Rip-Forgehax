package com.matt.forgehax.mods.services;

import com.google.common.collect.EvictingQueue;
import com.google.common.collect.Lists;
import com.matt.forgehax.asm.events.PacketEvent.Incoming.Pre;
import com.matt.forgehax.util.mod.ServiceMod;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import java.util.Collections;
import java.util.List;
import java.util.Queue;
import net.minecraft.network.play.server.SPacketTimeUpdate;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.event.world.WorldEvent.Load;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;












@RegisterMod
public class TickRateService
  extends ServiceMod
{
  public static final double MAX_TICKRATE = 20.0D;
  public static final double MIN_TICKRATE = 0.0D;
  public static final int MAXIMUM_SAMPLE_SIZE = 100;
  private static final TickRateService INSTANCE = new TickRateService();
  private static final TickRateData TICK_DATA = new TickRateData(100, null);
  
  public static TickRateService getInstance() {
    return INSTANCE;
  }
  
  public static TickRateData getTickData() {
    return TICK_DATA;
  }
  
  private long timeLastTimeUpdate = -1L;
  
  public long getLastTimeDiff() {
    if (timeLastTimeUpdate != -1L) {
      return System.currentTimeMillis() - timeLastTimeUpdate;
    }
    return 0L;
  }
  
  public TickRateService()
  {
    super("TickManager", "Records the average tick rate");
  }
  
  @SubscribeEvent
  public void onWorldLoad(WorldEvent.Load event) {
    timeLastTimeUpdate = -1L;
    TICK_DATA.onWorldLoaded();
  }
  
  @SubscribeEvent
  public void onPacketPreceived(PacketEvent.Incoming.Pre event) {
    if ((event.getPacket() instanceof SPacketTimeUpdate)) {
      long currentTimeMillis = System.currentTimeMillis();
      if (timeLastTimeUpdate != -1L) {
        TICK_DATA.onTimePacketIncoming(currentTimeMillis - timeLastTimeUpdate);
      }
      timeLastTimeUpdate = currentTimeMillis;
      INSTANCEtimeLastTimeUpdate = timeLastTimeUpdate;
    }
  }
  
  public static class TickRateData
  {
    private final CalculationData EMPTY_DATA = new CalculationData();
    
    private final Queue<Double> rates;
    private final List<CalculationData> data = Lists.newArrayList();
    
    private TickRateData(int maxSampleSize) {
      rates = EvictingQueue.create(maxSampleSize);
      for (int i = 0; i < maxSampleSize; i++) {
        data.add(new CalculationData());
      }
    }
    
    private void resetData() {
      for (CalculationData d : data) {
        d.reset();
      }
    }
    
    private void recalculate() {
      resetData();
      int size = 0;
      double total = 0.0D;
      List<Double> in = Lists.newArrayList(rates);
      Collections.reverse(in);
      for (Double rate : in) {
        size++;
        total += rate.doubleValue();
        CalculationData d = (CalculationData)data.get(size - 1);
        if (d != null) {
          average = MathHelper.func_151237_a(total / size, 0.0D, 20.0D);
        }
      }
    }
    
    public CalculationData getPoint(int point)
    {
      CalculationData d = (CalculationData)data.get(Math.max(Math.min(getSampleSize() - 1, point - 1), 0));
      return d != null ? d : EMPTY_DATA;
    }
    
    public CalculationData getPoint() {
      return getPoint(getSampleSize() - 1);
    }
    
    public int getSampleSize() {
      return rates.size();
    }
    
    private void onTimePacketIncoming(long difference) {
      double timeElapsed = difference / 1000.0D;
      rates.offer(Double.valueOf(MathHelper.func_151237_a(20.0D / timeElapsed, 0.0D, 20.0D)));
      
      recalculate();
    }
    
    private void onWorldLoaded() {
      rates.clear();
      resetData();
    }
    
    public class CalculationData { public CalculationData() {}
      
      private double average = 0.0D;
      
      public double getAverage() {
        return average;
      }
      
      public void reset() {
        average = 0.0D;
      }
    }
  }
}
