package com.matt.forgehax.mods.services;

import com.matt.forgehax.asm.reflection.FastReflection.Fields;
import com.matt.forgehax.asm.utils.fasttype.FastField;
import com.matt.forgehax.util.mod.ServiceMod;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import net.minecraft.entity.monster.EntityPigZombie;
import net.minecraftforge.event.entity.living.LivingEvent.LivingUpdateEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@RegisterMod
public class PigmenAngerCooldownService
  extends ServiceMod
{
  public PigmenAngerCooldownService()
  {
    super("PigmenAngerCooldownService");
  }
  
  @SubscribeEvent
  public void onUpdate(LivingEvent.LivingUpdateEvent event) {
    if ((event.getEntityLiving() instanceof EntityPigZombie))
    {
      EntityPigZombie pigZombie = (EntityPigZombie)event.getEntityLiving();
      if (pigZombie.func_184734_db()) {
        FastReflection.Fields.EntityPigZombie_angerLevel.set(pigZombie, Integer.valueOf(400));
      } else if (pigZombie.func_175457_ck()) {
        FastReflection.Fields.EntityPigZombie_angerLevel.set(pigZombie, 
          Integer.valueOf(((Integer)FastReflection.Fields.EntityPigZombie_angerLevel.get(pigZombie)).intValue() - 1));
      }
    }
  }
}
