package com.matt.forgehax.mods.services;

import com.matt.forgehax.ForgeHax;
import com.matt.forgehax.Helper;
import com.matt.forgehax.events.LocalPlayerUpdateEvent;
import com.matt.forgehax.util.FileManager;
import com.matt.forgehax.util.mod.ServiceMod;
import com.matt.forgehax.util.mod.loader.ModManager;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.util.Objects;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;



@RegisterMod
public class FirstTimeRunningService
  extends ServiceMod
{
  private static final Path STARTUP_ONCE = FileManager.getInstance().getBaseResolve(new String[] { "config/.once" });
  
  private static final String getOnceFileVersion() {
    if (Files.exists(STARTUP_ONCE, new LinkOption[0])) {
      try {
        return new String(Files.readAllBytes(STARTUP_ONCE));
      }
      catch (Throwable localThrowable) {}
    }
    return "";
  }
  
  public FirstTimeRunningService() {
    super("FirstTimeRunningService");
  }
  
  @SubscribeEvent
  public void onLocalPlayerUpdate(LocalPlayerUpdateEvent event) {
    if (!Objects.equals(ForgeHax.MOD_VERSION, getOnceFileVersion())) {
      Helper.printMessageNaked(ForgeHax.getWelcomeMessage());
      try {
        Files.write(STARTUP_ONCE, ForgeHax.MOD_VERSION.getBytes(), new OpenOption[0]);
      }
      catch (IOException localIOException) {}
    }
    Helper.getModManager().unload(this);
  }
}
