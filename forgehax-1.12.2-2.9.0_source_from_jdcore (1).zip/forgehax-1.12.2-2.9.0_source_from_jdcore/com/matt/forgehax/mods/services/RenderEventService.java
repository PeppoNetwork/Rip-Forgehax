package com.matt.forgehax.mods.services;

import com.matt.forgehax.Helper;
import com.matt.forgehax.events.Render2DEvent;
import com.matt.forgehax.events.RenderEvent;
import com.matt.forgehax.util.entity.EntityUtils;
import com.matt.forgehax.util.mod.ServiceMod;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import com.matt.forgehax.util.tesselation.GeometryTessellator;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.client.event.RenderGameOverlayEvent.ElementType;
import net.minecraftforge.client.event.RenderGameOverlayEvent.Text;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.EventBus;
import net.minecraftforge.fml.common.eventhandler.EventPriority;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;



@RegisterMod
public class RenderEventService
  extends ServiceMod
{
  private static final GeometryTessellator TESSELLATOR = new GeometryTessellator();
  
  public RenderEventService() {
    super("RenderEventService");
  }
  
  @SubscribeEvent
  public void onRenderWorld(RenderWorldLastEvent event) {
    GlStateManager.func_179094_E();
    GlStateManager.func_179090_x();
    GlStateManager.func_179147_l();
    GlStateManager.func_179118_c();
    GlStateManager.func_179120_a(770, 771, 1, 0);
    GlStateManager.func_179103_j(7425);
    GlStateManager.func_179097_i();
    
    GlStateManager.func_187441_d(1.0F);
    
    Vec3d renderPos = EntityUtils.getInterpolatedPos(Helper.getRenderEntity(), event.getPartialTicks());
    
    RenderEvent e = new RenderEvent(TESSELLATOR, renderPos, event.getPartialTicks());
    e.resetTranslation();
    MinecraftForge.EVENT_BUS.post(e);
    
    GlStateManager.func_187441_d(1.0F);
    
    GlStateManager.func_179103_j(7424);
    GlStateManager.func_179084_k();
    GlStateManager.func_179141_d();
    GlStateManager.func_179098_w();
    GlStateManager.func_179126_j();
    GlStateManager.func_179089_o();
    GlStateManager.func_179121_F();
  }
  
  @SubscribeEvent(priority=EventPriority.LOW)
  public void onRenderGameOverlayEvent(RenderGameOverlayEvent.Text event) {
    if (event.getType().equals(RenderGameOverlayEvent.ElementType.TEXT)) {
      MinecraftForge.EVENT_BUS.post(new Render2DEvent(event.getPartialTicks()));
      GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
    }
  }
}
