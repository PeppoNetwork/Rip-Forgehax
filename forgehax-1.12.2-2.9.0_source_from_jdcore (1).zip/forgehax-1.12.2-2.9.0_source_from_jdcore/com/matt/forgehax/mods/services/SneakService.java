package com.matt.forgehax.mods.services;

import com.matt.forgehax.Helper;
import com.matt.forgehax.asm.events.PacketEvent.Outgoing.Pre;
import com.matt.forgehax.util.PacketHelper;
import com.matt.forgehax.util.mod.ServiceMod;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.network.play.client.CPacketEntityAction;
import net.minecraft.network.play.client.CPacketEntityAction.Action;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@RegisterMod
public class SneakService extends ServiceMod
{
  private static SneakService instance;
  
  public static SneakService getInstance()
  {
    return instance;
  }
  
  private boolean suppressing = false;
  private boolean sneakingClient = false;
  private boolean sneakingServer = false;
  
  public SneakService() {
    super("SneakService");
    instance = this;
  }
  
  public boolean isSuppressing() {
    return suppressing;
  }
  
  public void setSuppressing(boolean suppressing) {
    this.suppressing = suppressing;
  }
  
  public boolean isSneakingClient() {
    return sneakingClient;
  }
  
  public boolean isSneakingServer() {
    return sneakingServer;
  }
  
  @SubscribeEvent
  public void onPacketSend(PacketEvent.Outgoing.Pre event) {
    if ((event.getPacket() instanceof CPacketEntityAction)) {
      CPacketEntityAction packet = (CPacketEntityAction)event.getPacket();
      int id = ((Integer)com.matt.forgehax.asm.reflection.FastReflection.Fields.CPacketEntityAction_entityID.get(packet)).intValue();
      if ((Helper.getLocalPlayer().func_145782_y() == id) && 
        ((packet.func_180764_b() == CPacketEntityAction.Action.START_SNEAKING) || 
        (packet.func_180764_b() == CPacketEntityAction.Action.STOP_SNEAKING)) && 
        (!PacketHelper.isIgnored(packet))) {
        sneakingClient = (packet.func_180764_b() == CPacketEntityAction.Action.START_SNEAKING);
        if (isSuppressing()) {
          event.setCanceled(true);
        } else {
          sneakingServer = sneakingClient;
        }
      }
    }
  }
}
