package com.matt.forgehax.mods;

import com.matt.forgehax.Helper;
import com.matt.forgehax.asm.events.PacketEvent.Incoming.Pre;
import com.matt.forgehax.asm.events.PacketEvent.Outgoing.Pre;
import com.matt.forgehax.events.LocalPlayerUpdateEvent;
import com.matt.forgehax.util.Switch;
import com.matt.forgehax.util.Switch.Handle;
import com.matt.forgehax.util.command.Command;
import com.matt.forgehax.util.command.CommandBuilders;
import com.matt.forgehax.util.command.Setting;
import com.matt.forgehax.util.command.SettingBuilder;
import com.matt.forgehax.util.entity.LocalPlayerUtils;
import com.matt.forgehax.util.key.Bindings;
import com.matt.forgehax.util.key.KeyBindingHandler;
import com.matt.forgehax.util.math.Angle;
import com.matt.forgehax.util.mod.ToggleMod;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import com.mojang.authlib.GameProfile;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerCapabilities;
import net.minecraft.network.play.client.CPacketInput;
import net.minecraft.network.play.client.CPacketPlayer;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import net.minecraft.util.Session;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraftforge.client.event.RenderLivingEvent.Pre;
import net.minecraftforge.client.event.RenderLivingEvent.Specials.Pre;
import net.minecraftforge.event.world.WorldEvent.Load;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@RegisterMod
public class FreecamMod extends ToggleMod
{
  private final Setting<Double> speed = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("speed")).description("Movement speed"))
    .defaultTo(Double.valueOf(0.05D))
    .build();
  
  private final Switch.Handle flying = LocalPlayerUtils.getFlySwitch().createHandle(getModName());
  
  private Vec3d pos = Vec3d.field_186680_a;
  private Angle angle = Angle.ZERO;
  
  private boolean isRidingEntity;
  private Entity ridingEntity;
  private EntityOtherPlayerMP originalPlayer;
  
  public FreecamMod()
  {
    super(com.matt.forgehax.util.mod.Category.PLAYER, "Freecam", false, "Freecam mode");
  }
  
  public void onEnabled()
  {
    if ((Helper.getLocalPlayer() == null) || (Helper.getWorld() == null)) {
      return;
    }
    
    if ((this.isRidingEntity = Helper.getLocalPlayer().func_184218_aH())) {
      ridingEntity = Helper.getLocalPlayer().func_184187_bx();
      Helper.getLocalPlayer().func_184210_p();
    } else {
      pos = Helper.getLocalPlayer().func_174791_d();
    }
    
    angle = LocalPlayerUtils.getViewAngles();
    
    originalPlayer = new EntityOtherPlayerMP(Helper.getWorld(), MC.func_110432_I().func_148256_e());
    originalPlayer.func_82149_j(Helper.getLocalPlayer());
    originalPlayer.field_70759_as = getLocalPlayerfield_70759_as;
    originalPlayer.field_71071_by = getLocalPlayerfield_71071_by;
    originalPlayer.field_71069_bz = getLocalPlayerfield_71069_bz;
    Helper.getWorld().func_73027_a(-100, originalPlayer);
  }
  
  public void onDisabled()
  {
    flying.disable();
    
    if ((Helper.getLocalPlayer() == null) || (originalPlayer == null)) {
      return;
    }
    
    Helper.getLocalPlayer().func_70080_a(pos.field_72450_a, pos.field_72448_b, pos.field_72449_c, angle.getYaw(), angle.getPitch());
    Helper.getWorld().func_73028_b(-100);
    originalPlayer = null;
    
    getLocalPlayerfield_70145_X = false;
    Helper.getLocalPlayer().func_70016_h(0.0D, 0.0D, 0.0D);
    
    if (isRidingEntity) {
      Helper.getLocalPlayer().func_184205_a(ridingEntity, true);
      ridingEntity = null;
    }
  }
  
  @SubscribeEvent
  public void onLocalPlayerUpdate(LocalPlayerUpdateEvent event) {
    if (Helper.getLocalPlayer() == null) {
      return;
    }
    
    flying.enable();
    getLocalPlayerfield_71075_bZ.func_75092_a(speed.getAsFloat());
    getLocalPlayerfield_70145_X = true;
    getLocalPlayerfield_70122_E = false;
    getLocalPlayerfield_70143_R = 0.0F;
    
    if ((!Bindings.forward.isPressed()) && 
      (!Bindings.back.isPressed()) && 
      (!Bindings.left.isPressed()) && 
      (!Bindings.right.isPressed()) && 
      (!Bindings.jump.isPressed()) && 
      (!Bindings.sneak.isPressed())) {
      Helper.getLocalPlayer().func_70016_h(0.0D, 0.0D, 0.0D);
    }
  }
  
  @SubscribeEvent
  public void onPacketSend(PacketEvent.Outgoing.Pre event) {
    if (((event.getPacket() instanceof CPacketPlayer)) || ((event.getPacket() instanceof CPacketInput))) {
      event.setCanceled(true);
    }
  }
  
  @SubscribeEvent
  public void onPacketReceived(PacketEvent.Incoming.Pre event) {
    if ((originalPlayer == null) || (Helper.getLocalPlayer() == null)) {
      return;
    }
    
    if ((event.getPacket() instanceof SPacketPlayerPosLook)) {
      SPacketPlayerPosLook packet = (SPacketPlayerPosLook)event.getPacket();
      pos = new Vec3d(packet.func_148932_c(), packet.func_148928_d(), packet.func_148933_e());
      angle = Angle.degrees(packet.func_148930_g(), packet.func_148931_f());
      event.setCanceled(true);
    }
  }
  
  @SubscribeEvent
  public void onWorldLoad(WorldEvent.Load event) {
    if ((originalPlayer == null) || (Helper.getLocalPlayer() == null)) {
      return;
    }
    
    pos = Helper.getLocalPlayer().func_174791_d();
    angle = LocalPlayerUtils.getViewAngles();
  }
  
  @SubscribeEvent
  public void onEntityRender(RenderLivingEvent.Pre<?> event) {
    if ((originalPlayer != null) && 
      (Helper.getLocalPlayer() != null) && 
      (Helper.getLocalPlayer().equals(event.getEntity()))) {
      event.setCanceled(true);
    }
  }
  
  @SubscribeEvent
  public void onRenderTag(RenderLivingEvent.Specials.Pre event) {
    if ((originalPlayer != null) && 
      (Helper.getLocalPlayer() != null) && 
      (Helper.getLocalPlayer().equals(event.getEntity()))) {
      event.setCanceled(true);
    }
  }
  
  private static class DummyPlayer extends EntityOtherPlayerMP
  {
    public DummyPlayer(World worldIn, GameProfile gameProfileIn) {
      super(gameProfileIn);
    }
    
    public void func_70071_h_() {}
    
    public void func_70636_d() {}
  }
}
