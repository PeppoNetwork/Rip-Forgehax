package com.matt.forgehax.mods;

import com.matt.forgehax.asm.reflection.FastReflection.Fields;
import com.matt.forgehax.asm.utils.fasttype.FastField;
import com.matt.forgehax.events.LocalPlayerUpdateEvent;
import com.matt.forgehax.util.mod.Category;
import com.matt.forgehax.util.mod.ToggleMod;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@RegisterMod
public class FastPlaceMod
  extends ToggleMod
{
  public FastPlaceMod()
  {
    super(Category.PLAYER, "FastPlace", false, "Fast place");
  }
  
  @SubscribeEvent
  public void onUpdate(LocalPlayerUpdateEvent event) {
    FastReflection.Fields.Minecraft_rightClickDelayTimer.set(MC, Integer.valueOf(0));
  }
}
