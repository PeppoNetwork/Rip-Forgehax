package com.matt.forgehax.mods;

import com.matt.forgehax.Helper;
import com.matt.forgehax.asm.events.PacketEvent.Incoming.Pre;
import com.matt.forgehax.asm.reflection.FastReflection.Fields;
import com.matt.forgehax.asm.utils.fasttype.FastField;
import com.matt.forgehax.util.entity.LocalPlayerUtils;
import com.matt.forgehax.util.math.Angle;
import com.matt.forgehax.util.mod.Category;
import com.matt.forgehax.util.mod.ToggleMod;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import java.util.Arrays;
import java.util.Set;
import net.minecraft.network.play.server.SPacketPlayerPosLook;
import net.minecraft.network.play.server.SPacketPlayerPosLook.EnumFlags;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@RegisterMod
public class NoRotate extends ToggleMod
{
  public NoRotate()
  {
    super(Category.PLAYER, "NoRotate", false, "Prevent server from setting client viewangles");
  }
  
  @SubscribeEvent
  public void onPacketReceived(PacketEvent.Incoming.Pre event)
  {
    if ((event.getPacket() instanceof SPacketPlayerPosLook)) {
      SPacketPlayerPosLook packet = (SPacketPlayerPosLook)event.getPacket();
      if (Helper.getLocalPlayer() != null) {
        Angle angle = LocalPlayerUtils.getViewAngles();
        
        packet.func_179834_f().removeAll(Arrays.asList(new SPacketPlayerPosLook.EnumFlags[] { SPacketPlayerPosLook.EnumFlags.X_ROT, SPacketPlayerPosLook.EnumFlags.Y_ROT }));
        
        FastReflection.Fields.SPacketPlayer_yaw.set(packet, Float.valueOf(angle.getYaw()));
        FastReflection.Fields.SPacketPlayer_pitch.set(packet, Float.valueOf(angle.getPitch()));
      }
    }
  }
}
