package com.matt.forgehax.mods;

import com.matt.forgehax.Helper;
import com.matt.forgehax.events.RenderEvent;
import com.matt.forgehax.util.color.Color;
import com.matt.forgehax.util.color.Colors;
import com.matt.forgehax.util.mod.Category;
import com.matt.forgehax.util.mod.ToggleMod;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import com.matt.forgehax.util.tesselation.GeometryTessellator;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.tileentity.TileEntityMobSpawner;
import net.minecraft.util.math.BlockPos;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;


@RegisterMod
public class SpawnerEspMod
  extends ToggleMod
{
  public SpawnerEspMod()
  {
    super(Category.RENDER, "SpawnerESP", false, "Spawner esp");
  }
  
  @SubscribeEvent
  public void onRender(RenderEvent event) {
    event.getBuffer().func_181668_a(1, DefaultVertexFormats.field_181706_f);
    
    for (TileEntity tileEntity : getWorldfield_147482_g) {
      if ((tileEntity instanceof TileEntityMobSpawner)) {
        BlockPos pos = tileEntity.func_174877_v();
        GeometryTessellator.drawCuboid(event
          .getBuffer(), pos, 63, Colors.RED.toBuffer());
      }
    }
    
    event.getTessellator().func_78381_a();
  }
}
