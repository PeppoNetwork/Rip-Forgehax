package com.matt.forgehax.mods;

import com.matt.forgehax.events.LocalPlayerUpdateEvent;
import com.matt.forgehax.util.mod.ToggleMod;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@RegisterMod
public class FastBreak extends ToggleMod
{
  public FastBreak()
  {
    super(com.matt.forgehax.util.mod.Category.PLAYER, "FastBreak", false, "Fast break retard");
  }
  
  @SubscribeEvent
  public void onUpdate(LocalPlayerUpdateEvent event) {
    if (MCfield_71442_b != null) {
      com.matt.forgehax.asm.reflection.FastReflection.Fields.PlayerControllerMP_blockHitDelay.set(MCfield_71442_b, Integer.valueOf(0));
    }
  }
}
