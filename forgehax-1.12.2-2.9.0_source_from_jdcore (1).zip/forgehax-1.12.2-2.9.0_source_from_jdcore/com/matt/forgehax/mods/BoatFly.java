package com.matt.forgehax.mods;

import com.matt.forgehax.Helper;
import com.matt.forgehax.asm.events.RenderBoatEvent;
import com.matt.forgehax.events.LocalPlayerUpdateEvent;
import com.matt.forgehax.util.command.Command;
import com.matt.forgehax.util.command.CommandBuilders;
import com.matt.forgehax.util.command.Setting;
import com.matt.forgehax.util.command.SettingBuilder;
import com.matt.forgehax.util.entity.EntityUtils;
import com.matt.forgehax.util.mod.Category;
import com.matt.forgehax.util.mod.ToggleMod;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.item.EntityBoat;
import net.minecraft.util.MovementInput;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.ClientTickEvent;

@RegisterMod
public class BoatFly
  extends ToggleMod
{
  public final Setting<Double> speed = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("speed")).description("how fast to move"))
    .defaultTo(Double.valueOf(5.0D))
    .build();
  






  public final Setting<Double> speedY = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("FallSpeed")).description("how slowly to fall"))
    .defaultTo(Double.valueOf(0.033D))
    .build();
  





  public final Setting<Boolean> setYaw = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("SetYaw")).description("set the boat yaw"))
    .defaultTo(Boolean.valueOf(true))
    .build();
  




  public final Setting<Boolean> noClamp = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("NoClamp")).description("clamp view angles"))
    .defaultTo(Boolean.valueOf(true))
    .build();
  




  public final Setting<Boolean> noGravity = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("NoGravity")).description("disable boat gravity"))
    .defaultTo(Boolean.valueOf(true))
    .build();
  
  public BoatFly() {
    super(Category.MISC, "BoatFly", false, "Boathax");
  }
  
  @SubscribeEvent
  public void onLocalPlayerUpdate(LocalPlayerUpdateEvent event)
  {
    com.matt.forgehax.asm.ForgeHaxHooks.isNoBoatGravityActivated = Helper.getRidingEntity() instanceof EntityBoat;
  }
  

  public void onDisabled()
  {
    com.matt.forgehax.asm.ForgeHaxHooks.isNoBoatGravityActivated = false;
    com.matt.forgehax.asm.ForgeHaxHooks.isBoatSetYawActivated = false;
  }
  

  public void onLoad()
  {
    com.matt.forgehax.asm.ForgeHaxHooks.isNoClampingActivated = noClamp.getAsBoolean();
  }
  
  @SubscribeEvent
  public void onRenderBoat(RenderBoatEvent event) {
    if ((EntityUtils.isDrivenByPlayer(event.getBoat())) && (setYaw.getAsBoolean())) {
      float yaw = getLocalPlayerfield_70177_z;
      getBoatfield_70177_z = yaw;
      event.setYaw(yaw);
    }
  }
  
  @SubscribeEvent
  public void onClientTick(TickEvent.ClientTickEvent event)
  {
    if ((MCfield_71439_g != null) && (MCfield_71439_g.func_184187_bx() != null))
    {
      com.matt.forgehax.asm.ForgeHaxHooks.isNoClampingActivated = noClamp.getAsBoolean();
      com.matt.forgehax.asm.ForgeHaxHooks.isNoBoatGravityActivated = noGravity.getAsBoolean();
      com.matt.forgehax.asm.ForgeHaxHooks.isBoatSetYawActivated = setYaw.getAsBoolean();
      
      if (MCfield_71474_y.field_74314_A.func_151470_d())
      {
        MCfield_71439_g.func_184187_bx().field_70122_E = false;
        

        MCfield_71439_g.func_184187_bx().field_70181_x = (MCfield_71474_y.field_151444_V.func_151470_d() ? 5.0D : 1.5D);
      }
      else {
        MCfield_71439_g.func_184187_bx().field_70181_x = (MCfield_71474_y.field_151444_V.func_151470_d() ? -1.0D : -speedY.getAsDouble());
      }
      



      setMoveSpeedEntity(speed.getAsDouble());
    }
  }
  
  public static void setMoveSpeedEntity(double speed) {
    if ((MCfield_71439_g != null) && (MCfield_71439_g.func_184187_bx() != null)) {
      MovementInput movementInput = MCfield_71439_g.field_71158_b;
      double forward = field_192832_b;
      double strafe = field_78902_a;
      float yaw = MCfield_71439_g.field_70177_z;
      
      if ((forward == 0.0D) && (strafe == 0.0D)) {
        MCfield_71439_g.func_184187_bx().field_70159_w = 0.0D;
        MCfield_71439_g.func_184187_bx().field_70179_y = 0.0D;
      } else {
        if (forward != 0.0D) {
          if (strafe > 0.0D) {
            yaw += (forward > 0.0D ? -45 : 45);
          } else if (strafe < 0.0D) {
            yaw += (forward > 0.0D ? 45 : -45);
          }
          
          strafe = 0.0D;
          
          if (forward > 0.0D) {
            forward = 1.0D;
          } else if (forward < 0.0D) {
            forward = -1.0D;
          }
        }
        

        MCfield_71439_g.func_184187_bx().field_70159_w = (forward * speed * Math.cos(Math.toRadians(yaw + 90.0F)) + strafe * speed * Math.sin(Math.toRadians(yaw + 90.0F)));
        

        MCfield_71439_g.func_184187_bx().field_70179_y = (forward * speed * Math.sin(Math.toRadians(yaw + 90.0F)) - strafe * speed * Math.cos(Math.toRadians(yaw + 90.0F)));
      }
    }
  }
}
