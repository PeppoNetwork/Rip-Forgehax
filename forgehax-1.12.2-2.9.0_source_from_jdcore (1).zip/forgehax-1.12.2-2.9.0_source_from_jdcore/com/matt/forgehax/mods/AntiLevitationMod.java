package com.matt.forgehax.mods;

import com.matt.forgehax.Helper;
import com.matt.forgehax.events.LocalPlayerUpdateEvent;
import com.matt.forgehax.util.mod.Category;
import com.matt.forgehax.util.mod.ToggleMod;
import com.matt.forgehax.util.mod.loader.RegisterMod;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.potion.Potion;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;


@RegisterMod
public class AntiLevitationMod
  extends ToggleMod
{
  public AntiLevitationMod()
  {
    super(Category.PLAYER, "AntiLevitation", false, "No levitation");
  }
  
  @SubscribeEvent
  public void onUpdate(LocalPlayerUpdateEvent event) {
    if (Helper.getLocalPlayer().func_70644_a(Potion.func_180142_b("levitation"))) {
      Helper.getLocalPlayer().func_184596_c(Potion.func_180142_b("levitation"));
    }
  }
}
