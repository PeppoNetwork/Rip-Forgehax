package com.matt.forgehax.mods;

import com.matt.forgehax.Globals;
import com.matt.forgehax.asm.reflection.FastReflection.Fields;
import com.matt.forgehax.asm.utils.fasttype.FastField;
import com.matt.forgehax.util.command.Setting;
import com.matt.forgehax.util.command.SettingBuilder;
import com.matt.forgehax.util.mod.ToggleMod;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiDisconnected;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.multiplayer.GuiConnecting;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.util.text.ITextComponent;
import net.minecraftforge.client.event.GuiOpenEvent;
import net.minecraftforge.event.world.WorldEvent.Load;
import net.minecraftforge.event.world.WorldEvent.Unload;
import net.minecraftforge.fml.client.FMLClientHandler;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@com.matt.forgehax.util.mod.loader.RegisterMod
public class AutoReconnectMod extends ToggleMod
{
  private static ServerData lastConnectedServer;
  public static boolean hasAutoLogged = false;
  
  public void updateLastConnectedServer()
  {
    ServerData data = MC.func_147104_D();
    if (data != null) {
      lastConnectedServer = data;
    }
  }
  





  public final Setting<Double> delay = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("delay")).description("Delay between each reconnect attempt"))
    .defaultTo(Double.valueOf(5.0D))
    .build();
  
  public AutoReconnectMod() {
    super(com.matt.forgehax.util.mod.Category.MISC, "AutoReconnect", false, "Automatically reconnects to server");
  }
  
  @SubscribeEvent
  public void onGuiOpened(GuiOpenEvent event) {
    if ((!hasAutoLogged) && 
      ((event.getGui() instanceof GuiDisconnected)) && 
      (!(event.getGui() instanceof GuiDisconnectedOverride))) {
      updateLastConnectedServer();
      GuiDisconnected disconnected = (GuiDisconnected)event.getGui();
      event.setGui(new GuiDisconnectedOverride(
      
        (GuiScreen)FastReflection.Fields.GuiDisconnected_parentScreen.get(disconnected), "connect.failed", 
        
        (ITextComponent)FastReflection.Fields.GuiDisconnected_message.get(disconnected), 
        (String)FastReflection.Fields.GuiDisconnected_reason.get(disconnected), 
        ((Double)delay.get()).doubleValue()));
    }
  }
  

  @SubscribeEvent
  public void onWorldLoad(WorldEvent.Load event)
  {
    hasAutoLogged = false;
  }
  
  @SubscribeEvent
  public void onWorldUnload(WorldEvent.Unload event) {
    updateLastConnectedServer();
  }
  

  public static class GuiDisconnectedOverride
    extends GuiDisconnected
  {
    private GuiScreen parent;
    
    private ITextComponent message;
    private long reconnectTime;
    private GuiButton reconnectButton = null;
    




    public GuiDisconnectedOverride(GuiScreen screen, String reasonLocalizationKey, ITextComponent chatComp, String reason, double delay)
    {
      super(reasonLocalizationKey, chatComp);
      parent = screen;
      message = chatComp;
      reconnectTime = (System.currentTimeMillis() + (delay * 1000.0D));
      try
      {
        net.minecraftforge.fml.relauncher.ReflectionHelper.setPrivateValue(GuiDisconnected.class, this, reason, new String[] { "reason", "field_146306_a", "a" });


      }
      catch (Exception e)
      {


        com.matt.forgehax.Helper.printStackTrace(e);
      }
    }
    
    public long getTimeUntilReconnect()
    {
      return reconnectTime - System.currentTimeMillis();
    }
    
    public double getTimeUntilReconnectInSeconds() {
      return getTimeUntilReconnect() / 1000.0D;
    }
    
    public String getFormattedReconnectText() {
      return String.format("Reconnecting (%.1f)...", new Object[] { Double.valueOf(getTimeUntilReconnectInSeconds()) });
    }
    
    public ServerData getLastConnectedServerData() {
      return AutoReconnectMod.lastConnectedServer != null ? AutoReconnectMod.lastConnectedServer : Globals.MC.func_147104_D();
    }
    
    private void reconnect() {
      ServerData data = getLastConnectedServerData();
      if (data != null) {
        FMLClientHandler.instance().showGuiScreen(new GuiConnecting(parent, Globals.MC, data));
      }
    }
    
    public void func_73866_w_()
    {
      super.func_73866_w_();
      
      List<String> multilineMessage = field_146289_q.func_78271_c(message.func_150254_d(), field_146294_l - 50);
      int textHeight = multilineMessage.size() * field_146289_q.field_78288_b;
      
      if (getLastConnectedServerData() != null) {
        field_146292_n.add(this.reconnectButton = new GuiButton(field_146292_n
        

          .size(), field_146294_l / 2 - 100, field_146295_m / 2 + textHeight / 2 + field_146289_q.field_78288_b + 23, 
          

          getFormattedReconnectText()));
      }
    }
    
    protected void func_146284_a(GuiButton button) throws java.io.IOException
    {
      super.func_146284_a(button);
      if (button.equals(reconnectButton)) {
        reconnect();
      }
    }
    
    public void func_73876_c()
    {
      super.func_73876_c();
      if (reconnectButton != null) {
        reconnectButton.field_146126_j = getFormattedReconnectText();
      }
      if (System.currentTimeMillis() >= reconnectTime) {
        reconnect();
      }
    }
  }
}
