package com.matt.forgehax.mods;

import com.matt.forgehax.util.command.Setting;
import com.matt.forgehax.util.command.SettingBuilder;
import com.matt.forgehax.util.mod.ToggleMod;
import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.gameevent.TickEvent.ClientTickEvent;

@com.matt.forgehax.util.mod.loader.RegisterMod
public class FullBrightMod extends ToggleMod
{
  public FullBrightMod()
  {
    super(com.matt.forgehax.util.mod.Category.WORLD, "FullBright", false, "Makes everything render with maximum brightness");
  }
  





  private final Setting<Float> defaultGamma = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("gamma")).description("default gamma to revert to"))
    .defaultTo(Float.valueOf(MCfield_71474_y.field_74333_Y))
    .min(Float.valueOf(0.1F))
    .max(Float.valueOf(16.0F))
    .build();
  
  public void onEnabled()
  {
    MCfield_71474_y.field_74333_Y = 16.0F;
  }
  
  public void onDisabled()
  {
    MCfield_71474_y.field_74333_Y = ((Float)defaultGamma.get()).floatValue();
  }
  
  @net.minecraftforge.fml.common.eventhandler.SubscribeEvent
  public void onClientTick(TickEvent.ClientTickEvent event) {
    MCfield_71474_y.field_74333_Y = 16.0F;
  }
}
