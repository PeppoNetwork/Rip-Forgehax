package com.matt.forgehax.mods;

import com.matt.forgehax.asm.events.PacketEvent.Incoming.Pre;
import com.matt.forgehax.events.LocalPlayerUpdateEvent;
import com.matt.forgehax.util.command.Command;
import com.matt.forgehax.util.command.CommandBuilders;
import com.matt.forgehax.util.command.Setting;
import com.matt.forgehax.util.command.SettingBuilder;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.play.server.SPacketSpawnPlayer;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@com.matt.forgehax.util.mod.loader.RegisterMod
public class AutoLog extends com.matt.forgehax.util.mod.ToggleMod
{
  public AutoLog()
  {
    super(com.matt.forgehax.util.mod.Category.COMBAT, "AutoLog", false, "automatically disconnect");
  }
  





  public final Setting<Integer> threshold = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("threshold")).description("health to go down to to disconnect\""))
    .defaultTo(Integer.valueOf(0))
    .build();
  




  public final Setting<Boolean> noTotem = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("NoTotem")).description("disconnect if not holding a totem"))
    .defaultTo(Boolean.valueOf(false))
    .build();
  




  public final Setting<Boolean> disconnectOnNewPlayer = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("NewPlayer")).description("Disconnect if a player enters render distance"))
    .defaultTo(Boolean.valueOf(false))
    .build();
  
  @SubscribeEvent
  public void onLocalPlayerUpdate(LocalPlayerUpdateEvent event) {
    if (MCfield_71439_g != null) {
      int health = (int)(MCfield_71439_g.func_110143_aJ() + MCfield_71439_g.func_110139_bj());
      if ((health <= ((Integer)threshold.get()).intValue()) || (
        (noTotem.getAsBoolean()) && 
        (MCfield_71439_g.func_184592_cb().func_77973_b() != Items.field_190929_cY) && 
        (MCfield_71439_g.func_184614_ca().func_77973_b() != Items.field_190929_cY))) {
        AutoReconnectMod.hasAutoLogged = true;
        com.matt.forgehax.Helper.getNetworkManager()
          .func_150718_a(new net.minecraft.util.text.TextComponentString("Health too low (" + health + ")"));
        disable();
      }
    }
  }
  
  @SubscribeEvent
  public void onPacketRecieved(PacketEvent.Incoming.Pre event) {
    if (((event.getPacket() instanceof SPacketSpawnPlayer)) && 
      (disconnectOnNewPlayer.getAsBoolean())) {
      AutoReconnectMod.hasAutoLogged = true;
      java.util.UUID id = ((SPacketSpawnPlayer)event.getPacket()).func_179819_c();
      
      net.minecraft.client.network.NetworkPlayerInfo info = MC.func_147114_u().func_175102_a(id);
      String name = "(Failed) " + id.toString();
      
      com.matt.forgehax.Helper.getNetworkManager()
        .func_150718_a(new net.minecraft.util.text.TextComponentString(name + " entered render distance"));
      disable();
    }
  }
}
