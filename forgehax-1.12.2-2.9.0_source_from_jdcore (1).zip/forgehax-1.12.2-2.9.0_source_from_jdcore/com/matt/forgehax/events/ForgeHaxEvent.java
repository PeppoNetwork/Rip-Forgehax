package com.matt.forgehax.events;

import net.minecraftforge.fml.common.eventhandler.Event;

public class ForgeHaxEvent extends Event
{
  private final Type type;
  
  public static enum Type
  {
    EATING_SELECT_FOOD, 
    EATING_START, 
    EATING_STOP;
    

    private Type() {}
  }
  
  public ForgeHaxEvent(Type type)
  {
    this.type = type;
  }
  
  public Type getType() {
    return type;
  }
}
