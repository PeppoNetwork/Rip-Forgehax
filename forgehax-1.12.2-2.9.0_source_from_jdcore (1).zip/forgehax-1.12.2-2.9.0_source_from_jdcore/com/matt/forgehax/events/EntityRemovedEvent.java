package com.matt.forgehax.events;

import net.minecraftforge.event.entity.EntityEvent;

public class EntityRemovedEvent extends EntityEvent
{
  public EntityRemovedEvent(net.minecraft.entity.Entity entity)
  {
    super(entity);
  }
}
