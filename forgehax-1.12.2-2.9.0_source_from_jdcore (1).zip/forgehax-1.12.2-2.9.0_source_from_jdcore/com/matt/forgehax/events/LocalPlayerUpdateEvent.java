package com.matt.forgehax.events;

import net.minecraft.entity.EntityLivingBase;

public class LocalPlayerUpdateEvent extends net.minecraftforge.event.entity.living.LivingEvent
{
  public LocalPlayerUpdateEvent(EntityLivingBase e)
  {
    super(e);
  }
}
