package com.matt.forgehax.events;

import net.minecraftforge.event.entity.EntityEvent;

public class EntityAddedEvent extends EntityEvent
{
  public EntityAddedEvent(net.minecraft.entity.Entity entity)
  {
    super(entity);
  }
}
