package com.matt.forgehax.events;

import com.matt.forgehax.util.entity.PlayerInfo;
import javax.annotation.Nullable;

public class ChatMessageEvent extends net.minecraftforge.fml.common.eventhandler.Event
{
  private final PlayerInfo sender;
  private final String message;
  private final PlayerInfo receiver;
  
  public static ChatMessageEvent newPublicChat(PlayerInfo playerInfo, String message)
  {
    return new ChatMessageEvent(playerInfo, message, null);
  }
  
  public static ChatMessageEvent newPrivateChat(PlayerInfo sender, PlayerInfo receiver, String message)
  {
    return new ChatMessageEvent(sender, message, receiver);
  }
  






  public ChatMessageEvent(PlayerInfo sender, String message, PlayerInfo receiver)
  {
    this.sender = sender;
    this.message = com.google.common.base.Strings.nullToEmpty(message);
    this.receiver = receiver;
  }
  
  public PlayerInfo getSender() {
    return sender;
  }
  
  public String getMessage() {
    return message;
  }
  
  @Nullable
  public PlayerInfo getReceiver() {
    return receiver;
  }
  
  public boolean isWhispering() {
    return receiver != null;
  }
}
