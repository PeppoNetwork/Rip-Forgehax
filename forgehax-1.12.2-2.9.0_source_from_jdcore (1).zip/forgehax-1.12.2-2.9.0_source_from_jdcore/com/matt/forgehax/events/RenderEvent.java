package com.matt.forgehax.events;

import com.matt.forgehax.util.tesselation.GeometryTessellator;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.common.eventhandler.Event;


public class RenderEvent
  extends Event
{
  private final GeometryTessellator tessellator;
  private final Vec3d renderPos;
  private final double partialTicks;
  
  public RenderEvent(GeometryTessellator tessellator, Vec3d renderPos, double partialTicks)
  {
    this.tessellator = tessellator;
    this.renderPos = renderPos;
    this.partialTicks = partialTicks;
  }
  
  public GeometryTessellator getTessellator() {
    return tessellator;
  }
  
  public BufferBuilder getBuffer() {
    return tessellator.func_178180_c();
  }
  
  public Vec3d getRenderPos() {
    return renderPos;
  }
  
  public void setTranslation(Vec3d translation) {
    getBuffer().func_178969_c(-field_72450_a, -field_72448_b, -field_72449_c);
  }
  
  public void resetTranslation() {
    setTranslation(renderPos);
  }
  
  public double getPartialTicks() {
    return partialTicks;
  }
}
