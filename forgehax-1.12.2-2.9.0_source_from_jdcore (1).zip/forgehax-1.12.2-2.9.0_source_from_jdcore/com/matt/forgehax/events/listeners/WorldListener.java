package com.matt.forgehax.events.listeners;

import com.matt.forgehax.events.EntityAddedEvent;
import com.matt.forgehax.events.EntityRemovedEvent;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IWorldEventListener;
import net.minecraft.world.World;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.EventBus;







































public class WorldListener
  implements IWorldEventListener
{
  public WorldListener() {}
  
  public void func_184376_a(World worldIn, BlockPos pos, IBlockState oldState, IBlockState newState, int flags) {}
  
  public void func_174959_b(BlockPos pos) {}
  
  public void func_147585_a(int x1, int y1, int z1, int x2, int y2, int z2) {}
  
  public void func_184375_a(EntityPlayer player, SoundEvent soundIn, SoundCategory category, double x, double y, double z, float volume, float pitch) {}
  
  public void func_184377_a(SoundEvent soundIn, BlockPos pos) {}
  
  public void func_180442_a(int particleID, boolean ignoreRange, double xCoord, double yCoord, double zCoord, double xSpeed, double ySpeed, double zSpeed, int... parameters) {}
  
  public void func_190570_a(int p_190570_1_, boolean p_190570_2_, boolean p_190570_3_, double p_190570_4_, double p_190570_6_, double p_190570_8_, double p_190570_10_, double p_190570_12_, double p_190570_14_, int... p_190570_16_) {}
  
  public void func_72703_a(Entity entityIn)
  {
    MinecraftForge.EVENT_BUS.post(new EntityAddedEvent(entityIn));
  }
  
  public void func_72709_b(Entity entityIn)
  {
    MinecraftForge.EVENT_BUS.post(new EntityRemovedEvent(entityIn));
  }
  
  public void func_180440_a(int soundID, BlockPos pos, int data) {}
  
  public void func_180439_a(EntityPlayer player, int type, BlockPos blockPosIn, int data) {}
  
  public void func_180441_b(int breakerId, BlockPos pos, int progress) {}
}
