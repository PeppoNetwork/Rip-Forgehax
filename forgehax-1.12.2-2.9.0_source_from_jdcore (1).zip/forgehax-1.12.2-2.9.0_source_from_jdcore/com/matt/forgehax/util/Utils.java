package com.matt.forgehax.util;

import com.matt.forgehax.Globals;
import com.matt.forgehax.Helper;
import com.matt.forgehax.util.entity.EntityUtils;
import com.matt.forgehax.util.math.Angle;
import java.util.Collection;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import net.minecraft.entity.Entity;
import net.minecraft.inventory.ItemStackHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.util.NonNullList;
import net.minecraft.util.math.Vec3d;

public class Utils implements Globals
{
  public Utils() {}
  
  public static <E extends Enum<?>> String[] toArray(E[] o)
  {
    String[] output = new String[o.length];
    for (int i = 0; i < output.length; i++) {
      output[i] = o[i].name();
    }
    return output;
  }
  
  public static UUID stringToUUID(String uuid) {
    if (uuid.contains("-"))
    {
      return UUID.fromString(uuid);
    }
    
    Pattern pattern = Pattern.compile("(\\w{8})(\\w{4})(\\w{4})(\\w{4})(\\w{12})");
    Matcher matcher = pattern.matcher(uuid);
    return UUID.fromString(matcher.replaceAll("$1-$2-$3-$4-$5"));
  }
  
  public static double normalizeAngle(double angle)
  {
    while (angle <= -180.0D) {
      angle += 360.0D;
    }
    while (angle > 180.0D) {
      angle -= 360.0D;
    }
    return angle;
  }
  
  public static double clamp(double value, double min, double max) {
    return Math.max(min, Math.min(max, value));
  }
  
  public static float clamp(float value, float min, float max) {
    return Math.max(min, Math.min(max, value));
  }
  
  public static Angle getLookAtAngles(Vec3d start, Vec3d end) {
    return com.matt.forgehax.util.math.AngleHelper.getAngleFacingInDegrees(end.func_178788_d(start)).normalize();
  }
  
  public static Angle getLookAtAngles(Vec3d end) {
    return getLookAtAngles(EntityUtils.getEyePos(Helper.getLocalPlayer()), end);
  }
  
  public static Angle getLookAtAngles(Entity entity) {
    return getLookAtAngles(EntityUtils.getOBBCenter(entity));
  }
  
  public static double scale(double x, double from_min, double from_max, double to_min, double to_max)
  {
    return to_min + (to_max - to_min) * ((x - from_min) / (from_max - from_min));
  }
  
  public static <T> boolean isInRange(Collection<T> list, int index) {
    return (list != null) && (index >= 0) && (index < list.size());
  }
  
  public static <T> T defaultTo(T value, T defaultTo) {
    return value == null ? defaultTo : value;
  }
  
  public static java.util.List<ItemStack> getShulkerContents(ItemStack stack) {
    NonNullList<ItemStack> contents = NonNullList.func_191197_a(27, ItemStack.field_190927_a);
    NBTTagCompound compound = stack.func_77978_p();
    if ((compound != null) && (compound.func_150297_b("BlockEntityTag", 10))) {
      NBTTagCompound tags = compound.func_74775_l("BlockEntityTag");
      if (tags.func_150297_b("Items", 9))
      {
        ItemStackHelper.func_191283_b(tags, contents);
      }
    }
    return contents;
  }
}
