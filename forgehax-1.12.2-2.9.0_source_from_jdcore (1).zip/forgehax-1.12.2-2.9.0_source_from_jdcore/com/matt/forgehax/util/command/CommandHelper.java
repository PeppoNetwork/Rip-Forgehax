package com.matt.forgehax.util.command;

import com.matt.forgehax.util.command.exception.CommandExecuteException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.StringTokenizer;





public class CommandHelper
{
  private static final String[] EMPTY_STRING_ARRAY = new String[0];
  
  public static final String MOD_PROPERTY_SEPARATOR = ":";
  
  public CommandHelper() {}
  
  public static String[] forward(String[] args)
  {
    return args.length > 0 ? (String[])Arrays.copyOfRange(args, 1, args.length) : EMPTY_STRING_ARRAY;
  }
  
  public static String join(String[] args, String separator, int startIndex, int endIndex) {
    return joptsimple.internal.Strings.join(
      (String[])Arrays.copyOfRange(args, startIndex, endIndex), 
      com.google.common.base.Strings.nullToEmpty(separator));
  }
  
  public static String join(String[] args, String separator) {
    return join(args, separator, 0, args.length);
  }
  
  public static String toUniqueId(String parent, String child) {
    return makeParserFriendly(
      !joptsimple.internal.Strings.isNullOrEmpty(parent) ? parent + ":" + child : child);
  }
  
  public static String makeParserFriendly(String string) {
    return string.replaceAll(" ", "_");
  }
  
  public static void requireArguments(List<?> args, int requiredArguments) throws CommandExecuteException
  {
    if (args.size() < requiredArguments) {
      throw new CommandExecuteException("Missing argument(s)");
    }
  }
  






  public static String[] translate(String toProcess)
  {
    if ((toProcess == null) || (toProcess.length() == 0))
    {
      return new String[0];
    }
    

    int normal = 0;
    int inQuote = 1;
    int inDoubleQuote = 2;
    int state = 0;
    StringTokenizer tok = new StringTokenizer(toProcess, "\"' ", true);
    ArrayList<String> result = new ArrayList();
    StringBuilder current = new StringBuilder();
    boolean lastTokenHasBeenQuoted = false;
    
    while (tok.hasMoreTokens()) {
      String nextTok = tok.nextToken();
      switch (state) {
      case 1: 
        if ("'".equals(nextTok)) {
          lastTokenHasBeenQuoted = true;
          state = 0;
        } else {
          current.append(nextTok);
        }
        break;
      case 2: 
        if ("\"".equals(nextTok)) {
          lastTokenHasBeenQuoted = true;
          state = 0;
        } else {
          current.append(nextTok);
        }
        break;
      default: 
        if ("'".equals(nextTok)) {
          state = 1;
        } else if ("\"".equals(nextTok)) {
          state = 2;
        } else if (" ".equals(nextTok)) {
          if ((lastTokenHasBeenQuoted) || (current.length() != 0)) {
            result.add(current.toString());
            current.setLength(0);
          }
        } else {
          current.append(nextTok);
        }
        lastTokenHasBeenQuoted = false;
      }
      
    }
    if ((lastTokenHasBeenQuoted) || (current.length() != 0)) {
      result.add(current.toString());
    }
    if ((state == 1) || (state == 2)) {
      throw new RuntimeException("unbalanced quotes in " + toProcess);
    }
    return (String[])result.toArray(new String[result.size()]);
  }
}
