package com.matt.forgehax.util.command;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.matt.forgehax.Globals;
import com.matt.forgehax.util.SafeConverter;
import com.matt.forgehax.util.command.exception.MissingEntryException;
import com.matt.forgehax.util.console.ConsoleWriter;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import javax.annotation.Nullable;
import joptsimple.OptionSet;
import org.apache.logging.log4j.Logger;

public class ExecuteData implements Globals, ConsoleWriter
{
  private final Command command;
  private final OptionSet options;
  
  public static enum State
  {
    NONE, 
    SUCCESS, 
    FAILED;
    

    private State() {}
  }
  

  private final List arguments = Lists.newArrayList();
  @Nullable
  private Map<String, Object> data = null;
  

  private State state = State.FAILED;
  
  private boolean stopped = false;
  
  public ExecuteData(Command command, OptionSet options, Object[] extraArguments) {
    this.command = command;
    this.options = options;
    arguments.addAll(Arrays.asList(extraArguments));
    arguments.addAll(options.nonOptionArguments());
  }
  
  public State state() {
    return state;
  }
  
  private void setState(State state, State... conditions) {
    for (State s : conditions) {
      if (this.state.equals(s)) {
        return;
      }
    }
    this.state = state;
  }
  
  public void markSuccess(State... conditions) {
    setState(State.SUCCESS, conditions);
  }
  
  public void markFailed(State... conditions) {
    setState(State.FAILED, conditions);
  }
  
  public void unmark() {
    state = State.NONE;
  }
  
  public Command command() {
    return command;
  }
  
  public OptionSet options() {
    return options;
  }
  
  public List<?> arguments() {
    return arguments;
  }
  
  public <T> T getArgument(int index) {
    try {
      return arguments.get(index);
    } catch (Throwable t) {}
    return null;
  }
  
  public String getArgumentAsString(int index)
  {
    return SafeConverter.toString(getArgument(index));
  }
  
  public int getArgumentCount() {
    return arguments.size();
  }
  
  public Object getOption(String name, Object defaultValue) {
    try {
      return getOptions(name).get(0);
    } catch (Throwable t) {}
    return defaultValue;
  }
  
  public Object getOption(String name)
  {
    return getOption(name, null);
  }
  
  public String getOptionAsString(String name) {
    return String.valueOf(getOption(name));
  }
  
  public List<?> getOptions(String name) {
    if (options.has(name)) {
      try {
        return options.valuesOf(name);
      }
      catch (Throwable localThrowable) {}
    }
    return Collections.emptyList();
  }
  
  public boolean hasOption(String name) {
    return options.has(name);
  }
  
  public <T> void set(String name, T element) {
    if (data == null) {
      data = Maps.newHashMap();
    }
    if (element == null) {
      data.remove(name);
    } else {
      data.put(name, element);
    }
  }
  
  public boolean has(String name) {
    return (data != null) && (data.get(name) != null);
  }
  
  public <T> T get(String name, T defaultValue)
  {
    try {
      java.util.Objects.requireNonNull(data);
      return data.getOrDefault(name, defaultValue);
    } catch (Throwable t) {
      LOGGER.warn(String.format("Cannot find entry named \"%s\"", new Object[] { name })); }
    return defaultValue;
  }
  
  public <T> T get(String name)
  {
    return get(name, null);
  }
  
  public void requiresEntry(String name) throws MissingEntryException {
    if (get(name) == null) {
      markFailed(new State[0]);
      throw new MissingEntryException(String.format("Missing data entry \"%s\"", new Object[] { name }));
    }
  }
  
  public void requiredArguments(int numberRequired) {
    if (arguments.size() < numberRequired) {
      markFailed(new State[0]);
      throw new com.matt.forgehax.util.command.exception.CommandExecuteException("Missing argument(s)");
    }
  }
  
  public boolean isStopped() {
    return stopped;
  }
  
  public void startProcessing() {
    stopped = false;
  }
  
  public void stopProcessing() {
    stopped = true;
  }
}
