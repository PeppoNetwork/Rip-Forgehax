package com.matt.forgehax.util.command;

public enum CallbackType
{
  SUCCESS,  FAILURE,  KEY_PRESSED,  KEY_DOWN,  CHANGE;
  
  private CallbackType() {}
}
