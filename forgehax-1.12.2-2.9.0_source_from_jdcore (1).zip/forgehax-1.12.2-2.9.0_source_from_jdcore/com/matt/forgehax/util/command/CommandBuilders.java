package com.matt.forgehax.util.command;

import com.matt.forgehax.util.serialization.ISerializableJson;




public class CommandBuilders
{
  private static final CommandBuilders INSTANCE = new CommandBuilders();
  private final Command parent;
  
  public static CommandBuilders getInstance() { return INSTANCE; }
  
  public static CommandBuilders newInstance(Command parent)
  {
    return new CommandBuilders(parent);
  }
  

  public CommandBuilders(Command parent)
  {
    this.parent = parent;
  }
  
  public CommandBuilders() {
    this(null);
  }
  
  public CommandBuilder newCommandBuilder() {
    return (CommandBuilder)new CommandBuilder().parent(parent);
  }
  
  public StubBuilder newStubBuilder() {
    return (StubBuilder)new StubBuilder().parent(parent);
  }
  
  public <T> SettingBuilder<T> newSettingBuilder() {
    return (SettingBuilder)new SettingBuilder().parent(parent);
  }
  
  public <T extends Enum<T>> SettingEnumBuilder<T> newSettingEnumBuilder() {
    return (SettingEnumBuilder)new SettingEnumBuilder().parent(parent);
  }
  
  public <T extends ISerializableJson> OptionsBuilder<T> newOptionsBuilder() {
    return (OptionsBuilder)new OptionsBuilder().parent(parent);
  }
}
