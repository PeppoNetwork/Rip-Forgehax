package com.matt.forgehax.util.command;

import com.matt.forgehax.Globals;
import com.matt.forgehax.util.command.callbacks.OnChangeCallback;
import com.matt.forgehax.util.typeconverter.TypeConverter;
import com.matt.forgehax.util.typeconverter.TypeConverterRegistry;
import java.util.Collection;
import java.util.Comparator;
import java.util.function.Consumer;

public class SettingBuilder<E> extends BaseCommandBuilder<SettingBuilder<E>, Setting<E>> implements Globals
{
  public SettingBuilder() {}
  
  public SettingBuilder<E> changed(Consumer<OnChangeCallback<E>> consumer)
  {
    getCallbacks(CallbackType.CHANGE).add(consumer);
    return this;
  }
  
  public SettingBuilder<E> defaultTo(E defaultValue) {
    return ((SettingBuilder)insert("Setting.defaultValue", defaultValue)).type(defaultValue.getClass());
  }
  
  public SettingBuilder<E> converter(TypeConverter<E> converter) {
    return ((SettingBuilder)insert("Setting.converter", converter)).comparator(converter.comparator());
  }
  
  public SettingBuilder<E> comparator(Comparator<E> comparator) {
    return (SettingBuilder)insert("Setting.comparator", comparator);
  }
  
  public SettingBuilder<E> min(E minValue) {
    return (SettingBuilder)insert("Setting.minvalue", minValue);
  }
  
  public SettingBuilder<E> max(E maxValue) {
    return (SettingBuilder)insert("Setting.maxvalue", maxValue);
  }
  
  public SettingBuilder<E> type(Class<?> clazz) {
    if (has("Setting.converter")) {
      return this;
    }
    return converter(TypeConverterRegistry.get(clazz));
  }
  
  public SettingBuilder<E> customProcessor() {
    return (SettingBuilder)insert("Setting.defaultProcessor", Boolean.valueOf(false));
  }
  
  public Setting<E> build()
  {
    return new Setting(has("Command.requiredArgs") ? data : requiredArgs1data);
  }
}
