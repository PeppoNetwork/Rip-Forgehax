package com.matt.forgehax.util.command;

import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import com.matt.forgehax.util.command.exception.CommandBuildException;
import com.matt.forgehax.util.console.ConsoleIO;
import com.matt.forgehax.util.serialization.ISerializableJson;
import java.io.IOException;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.function.Supplier;




public class Options<E extends ISerializableJson>
  extends Command
  implements Collection<E>, ISerializableJson
{
  public static final String SUPPLIER = "Options.supplier";
  public static final String FACTORY = "Options.factory";
  public static final String DEFAULTS = "Options.defaults";
  private final Collection<E> contents;
  private final Function<String, E> factory;
  private final Collection<E> defaults;
  
  protected Options(Map<String, Object> data)
    throws CommandBuildException
  {
    super(data);
    try {
      Supplier<Collection<E>> supplier = (Supplier)data.get("Options.supplier");
      Objects.requireNonNull(supplier, "Missing supplier");
      
      contents = ((Collection)supplier.get());
      factory = ((Function)data.get("Options.factory"));
      
      Supplier<Collection<E>> defaults = (Supplier)data.get("Options.defaults");
      if (defaults != null) {
        this.defaults = ((Collection)supplier.get());
        this.defaults.addAll((Collection)defaults.get());
        contents.addAll((Collection)defaults.get());
      } else {
        this.defaults = Collections.emptyList();
      }
    }
    catch (Throwable t) {
      throw new CommandBuildException("Failed to build options", t);
    }
  }
  
  protected boolean preprocessor(String[] args)
  {
    if (args.length > 0) {
      String opt = args[0];
      if (opt.matches("-r|--reset")) {
        contents.clear();
        contents.addAll(defaults);
        ConsoleIO.write(getName() + " reset");
        return false;
      }
    }
    return true;
  }
  
  public Collection<E> contents() {
    return contents;
  }
  
  public E get(Object o) {
    for (E element : this) {
      if (Objects.equals(element, o)) {
        return element;
      }
    }
    return null;
  }
  
  public int size()
  {
    return contents.size();
  }
  
  public boolean isEmpty()
  {
    return contents.isEmpty();
  }
  
  public boolean contains(Object o)
  {
    return contents.contains(o);
  }
  
  public Iterator<E> iterator()
  {
    return contents.iterator();
  }
  
  public Object[] toArray()
  {
    return contents.toArray();
  }
  
  public <T> T[] toArray(T[] a)
  {
    return contents.toArray(a);
  }
  
  public boolean add(E e)
  {
    return contents.add(e);
  }
  
  public boolean remove(Object o)
  {
    return contents.remove(o);
  }
  
  public boolean containsAll(Collection<?> c)
  {
    return contents.containsAll(c);
  }
  
  public boolean addAll(Collection<? extends E> c)
  {
    return contents.addAll(c);
  }
  
  public boolean removeAll(Collection<?> c)
  {
    return contents.removeAll(c);
  }
  
  public boolean retainAll(Collection<?> c)
  {
    return contents.retainAll(c);
  }
  
  public void clear()
  {
    contents.clear();
  }
  
  public void serialize(JsonWriter writer) throws IOException
  {
    writer.beginObject();
    
    writer.name("data");
    writer.beginObject();
    for (E element : contents) {
      writer.name(element.toString());
      element.serialize(writer);
    }
    writer.endObject();
    
    writer.endObject();
  }
  
  public void deserialize(JsonReader reader) throws IOException
  {
    reader.beginObject();
    
    reader.nextName();
    reader.beginObject();
    clear();
    while (reader.hasNext()) {
      String name = reader.nextName();
      E element = (ISerializableJson)factory.apply(name);
      if (element != null) {
        element.deserialize(reader);
        add(element);
      }
    }
    reader.endObject();
    
    reader.endObject();
  }
  
  public String toString()
  {
    return getAbsoluteName();
  }
}
