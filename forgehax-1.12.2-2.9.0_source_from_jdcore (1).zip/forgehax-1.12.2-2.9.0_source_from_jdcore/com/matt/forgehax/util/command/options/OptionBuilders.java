package com.matt.forgehax.util.command.options;

import java.util.Arrays;
import joptsimple.OptionParser;

public class OptionBuilders
{
  public OptionBuilders() {}
  
  public static void rgba(OptionParser parser)
  {
    parser.acceptsAll(Arrays.asList(new String[] { "red", "r" }), "red").withRequiredArg();
    parser.acceptsAll(Arrays.asList(new String[] { "green", "g" }), "green").withRequiredArg();
    parser.acceptsAll(Arrays.asList(new String[] { "blue", "b" }), "blue").withRequiredArg();
    parser.acceptsAll(Arrays.asList(new String[] { "alpha", "a" }), "alpha").withRequiredArg();
  }
  
  public static void meta(OptionParser parser) {
    parser.acceptsAll(Arrays.asList(new String[] { "meta", "m" }), "blocks metadata id").withRequiredArg();
  }
  
  public static void id(OptionParser parser) {
    parser.acceptsAll(Arrays.asList(new String[] { "id", "i" }), "searches for block by id instead of name");
  }
  
  public static void regex(OptionParser parser) {
    parser.acceptsAll(
      Arrays.asList(new String[] { "regex", "e" }), "searches for blocks by using the argument as a regex expression");
  }
  


  public static void bounds(OptionParser parser)
  {
    parser.accepts("bounds", "Will only draw blocks from within the min-max bounds given").withRequiredArg();
  }
}
