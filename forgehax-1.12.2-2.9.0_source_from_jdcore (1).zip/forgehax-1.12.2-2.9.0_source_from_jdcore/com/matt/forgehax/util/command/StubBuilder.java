package com.matt.forgehax.util.command;

import com.matt.forgehax.util.command.callbacks.CallbackData;
import java.util.Collection;
import java.util.function.Consumer;

public class StubBuilder extends BaseCommandBuilder<StubBuilder, CommandStub>
{
  public StubBuilder() {}
  
  public StubBuilder kpressed(Consumer<CallbackData> consumer)
  {
    getCallbacks(CallbackType.KEY_PRESSED).add(consumer);
    return this;
  }
  
  public StubBuilder kdown(Consumer<CallbackData> consumer) {
    getCallbacks(CallbackType.KEY_DOWN).add(consumer);
    return this;
  }
  
  public StubBuilder bind(int keyCode) {
    return (StubBuilder)insert("Command.keybind", Integer.valueOf(keyCode));
  }
  
  public StubBuilder bind() {
    return bind(0);
  }
  
  public StubBuilder nobind() {
    return bind(-1);
  }
  
  public StubBuilder bindOptions(boolean b) {
    return (StubBuilder)insert("Command.keybind_options", Boolean.valueOf(b));
  }
  
  public CommandStub build()
  {
    return new CommandStub(data);
  }
}
