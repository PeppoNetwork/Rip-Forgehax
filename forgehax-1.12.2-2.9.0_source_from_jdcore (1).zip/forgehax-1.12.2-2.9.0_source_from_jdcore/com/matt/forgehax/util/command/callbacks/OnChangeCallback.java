package com.matt.forgehax.util.command.callbacks;

import com.matt.forgehax.util.command.Command;


public class OnChangeCallback<E>
  extends CancelableCallbackData
{
  private final E from;
  private final E to;
  
  public OnChangeCallback(Command command, E from, E to)
  {
    super(command);
    this.from = from;
    this.to = to;
  }
  
  public E getFrom() {
    return from;
  }
  
  public E getTo() {
    return to;
  }
}
