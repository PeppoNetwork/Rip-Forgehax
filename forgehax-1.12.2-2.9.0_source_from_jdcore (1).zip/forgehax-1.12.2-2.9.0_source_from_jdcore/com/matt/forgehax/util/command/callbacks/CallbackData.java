package com.matt.forgehax.util.command.callbacks;

import com.matt.forgehax.util.command.Command;
import com.matt.forgehax.util.console.ConsoleWriter;


public class CallbackData
  implements ConsoleWriter
{
  private final Command command;
  
  public CallbackData(Command command)
  {
    this.command = command;
  }
  
  public <T extends Command> T command() {
    return command;
  }
}
