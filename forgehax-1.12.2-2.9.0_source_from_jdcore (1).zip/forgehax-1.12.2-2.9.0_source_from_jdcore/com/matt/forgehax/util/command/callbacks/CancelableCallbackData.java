package com.matt.forgehax.util.command.callbacks;

import com.matt.forgehax.util.command.Command;



public class CancelableCallbackData
  extends CallbackData
{
  private boolean canceled = false;
  
  public CancelableCallbackData(Command command) {
    super(command);
  }
  
  public boolean isCanceled() {
    return canceled;
  }
  
  public void setCanceled(boolean canceled) {
    this.canceled = canceled;
  }
  
  public void cancel() {
    setCanceled(true);
  }
}
