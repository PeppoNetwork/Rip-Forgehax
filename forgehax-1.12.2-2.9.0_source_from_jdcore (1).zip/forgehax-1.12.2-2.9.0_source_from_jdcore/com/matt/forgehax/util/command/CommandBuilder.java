package com.matt.forgehax.util.command;

public class CommandBuilder
  extends BaseCommandBuilder<CommandBuilder, Command>
{
  public CommandBuilder() {}
  
  public Command build()
  {
    return new Command(data);
  }
}
