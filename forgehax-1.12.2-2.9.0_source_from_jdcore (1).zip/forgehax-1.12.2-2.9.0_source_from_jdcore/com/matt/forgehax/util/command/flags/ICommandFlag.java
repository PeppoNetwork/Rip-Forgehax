package com.matt.forgehax.util.command.flags;

public abstract interface ICommandFlag {}
