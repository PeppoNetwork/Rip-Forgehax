package com.matt.forgehax.util.command;

import com.matt.forgehax.util.serialization.ISerializableJson;
import java.util.Collection;
import java.util.function.Function;
import java.util.function.Supplier;

public class OptionsBuilder<E extends ISerializableJson>
  extends BaseCommandBuilder<OptionsBuilder<E>, Options<E>>
{
  public OptionsBuilder() {}
  
  public OptionsBuilder<E> supplier(Supplier<Collection<E>> supplier)
  {
    return (OptionsBuilder)insert("Options.supplier", supplier);
  }
  
  public OptionsBuilder<E> factory(Function<String, E> factory) {
    return (OptionsBuilder)insert("Options.factory", factory);
  }
  
  public OptionsBuilder<E> defaults(Supplier<Collection<E>> defaults) {
    return (OptionsBuilder)insert("Options.defaults", defaults);
  }
  
  public Options<E> build()
  {
    return new Options(data);
  }
}
