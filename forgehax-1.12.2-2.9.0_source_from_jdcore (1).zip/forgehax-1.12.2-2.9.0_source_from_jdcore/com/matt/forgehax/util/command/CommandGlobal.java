package com.matt.forgehax.util.command;

import com.matt.forgehax.util.command.exception.CommandExecuteException;
import javax.annotation.Nonnull;




public class CommandGlobal
  extends CommandStub
{
  private static final CommandGlobal INSTANCE = new CommandGlobal();
  
  public static CommandGlobal getInstance() {
    return INSTANCE;
  }
  
  private CommandGlobal() {
    super(
    


      ((StubBuilder)((StubBuilder)CommandBuilders.getInstance().newStubBuilder().name("")).helpOption(false))
      .getData());
  }
  
  public boolean isGlobal()
  {
    return true;
  }
  
  public String getName()
  {
    return "";
  }
  
  public String getAbsoluteName()
  {
    return "";
  }
  
  public void run(@Nonnull String[] args) throws CommandExecuteException, NullPointerException
  {
    if (!processChildren(args)) {
      if (args.length > 0) {
        throw new CommandExecuteException(String.format("Unknown command \"%s\"", new Object[] { args[0] }));
      }
      throw new CommandExecuteException("Missing argument(s)");
    }
  }
}
