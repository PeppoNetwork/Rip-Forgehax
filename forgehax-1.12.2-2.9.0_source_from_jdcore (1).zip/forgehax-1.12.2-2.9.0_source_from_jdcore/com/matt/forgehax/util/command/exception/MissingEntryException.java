package com.matt.forgehax.util.command.exception;


public class MissingEntryException
  extends CommandExecuteException
{
  public MissingEntryException(String message)
  {
    super(message);
  }
}
