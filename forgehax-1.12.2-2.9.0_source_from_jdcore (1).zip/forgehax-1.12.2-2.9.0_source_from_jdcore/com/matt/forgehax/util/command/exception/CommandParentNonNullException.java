package com.matt.forgehax.util.command.exception;


public class CommandParentNonNullException
  extends RuntimeException
{
  public CommandParentNonNullException(String msg)
  {
    super(msg);
  }
}
