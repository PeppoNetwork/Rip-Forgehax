package com.matt.forgehax.util.command.exception;


public class CommandBuildException
  extends RuntimeException
{
  public CommandBuildException(String message, Throwable cause)
  {
    super(message, cause);
  }
}
