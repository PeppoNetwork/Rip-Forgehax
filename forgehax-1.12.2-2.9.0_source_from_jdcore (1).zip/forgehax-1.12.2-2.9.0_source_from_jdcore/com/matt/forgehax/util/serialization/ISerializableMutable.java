package com.matt.forgehax.util.serialization;

import com.google.gson.stream.JsonWriter;
import java.io.IOException;

public abstract interface ISerializableMutable<E>
{
  public abstract void serialize(E paramE, JsonWriter paramJsonWriter) throws IOException;
  
  public abstract void deserialize(E paramE, com.google.gson.stream.JsonReader paramJsonReader) throws IOException;
  
  public String heading()
  {
    return toString();
  }
}
