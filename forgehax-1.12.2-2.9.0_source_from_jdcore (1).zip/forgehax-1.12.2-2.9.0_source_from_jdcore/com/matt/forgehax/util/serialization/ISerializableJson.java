package com.matt.forgehax.util.serialization;

import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;


















public abstract interface ISerializableJson
{
  public abstract void serialize(JsonWriter paramJsonWriter)
    throws IOException;
  
  public abstract void deserialize(JsonReader paramJsonReader)
    throws IOException;
  
  public String getUniqueHeader()
  {
    return toString();
  }
}
