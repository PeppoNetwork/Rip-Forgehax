package com.matt.forgehax.util.serialization;

public abstract interface ISerializer
{
  public abstract void serialize();
  
  public abstract void deserialize();
}
