package com.matt.forgehax.util.serialization;

import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import javax.annotation.Nullable;

public abstract interface ISerializableImmutable<E>
{
  public abstract void serialize(JsonWriter paramJsonWriter, @Nullable E paramE)
    throws IOException;
  
  @Nullable
  public abstract E deserialize(JsonReader paramJsonReader)
    throws IOException;
}
