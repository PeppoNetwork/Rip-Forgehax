package com.matt.forgehax.util.serialization;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonParser;




public abstract interface GsonConstant
{
  public static final Gson GSON = new Gson();
  public static final Gson GSON_PRETTY = new GsonBuilder().setPrettyPrinting().create();
  public static final JsonParser PARSER = new JsonParser();
}
