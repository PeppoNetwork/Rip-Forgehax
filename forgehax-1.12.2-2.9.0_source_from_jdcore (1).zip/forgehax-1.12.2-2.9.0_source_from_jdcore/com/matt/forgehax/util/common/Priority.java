package com.matt.forgehax.util.common;

import java.lang.annotation.Annotation;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

@Retention(RetentionPolicy.RUNTIME)
public @interface Priority
{
  PriorityEnum value() default PriorityEnum.DEFAULT;
}
