package com.matt.forgehax.util.common;

public enum PriorityEnum
{
  HIGHEST,  HIGH,  DEFAULT,  LOW,  LOWEST;
  
  private PriorityEnum() {}
}
