package com.matt.forgehax.util.entity;

import java.util.List;
import java.util.Map;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;

public class EnchantmentUtils
{
  public EnchantmentUtils() {}
  
  public static List<EntityEnchantment> getEnchantments(NBTTagList tags)
  {
    if (tags == null) {
      return null;
    }
    List<EntityEnchantment> list = com.google.common.collect.Lists.newArrayList();
    for (int i = 0; i < tags.func_74745_c(); i++) {
      list.add(new EntityEnchantment(tags
      
        .func_150305_b(i).func_74765_d("id"), tags.func_150305_b(i).func_74765_d("lvl")));
    }
    return list;
  }
  
  public static List<EntityEnchantment> getEnchantmentsSorted(NBTTagList tags) {
    List<EntityEnchantment> list = getEnchantments(tags);
    if (list != null) {
      java.util.Collections.sort(list, new EnchantSort());
    }
    return list;
  }
  
  public static class EnchantSort implements java.util.Comparator<EnchantmentUtils.EntityEnchantment>
  {
    public EnchantSort() {}
    
    public int compare(EnchantmentUtils.EntityEnchantment o1, EnchantmentUtils.EntityEnchantment o2)
    {
      int deltaEch1 = o1.getEnchantment().func_77325_b() - o1.getEnchantment().func_77319_d();
      int deltaEch2 = o2.getEnchantment().func_77325_b() - o2.getEnchantment().func_77319_d();
      if (deltaEch1 == deltaEch2)
        return 0;
      if (deltaEch1 < deltaEch2) {
        return 1;
      }
      return -1;
    }
  }
  

  public static class EntityEnchantment
  {
    private static final Map<Integer, String> SHORT_ENCHANT_NAMES = ;
    private final Enchantment enchantment;
    
    static { SHORT_ENCHANT_NAMES.put(Integer.valueOf(0), "p");
      SHORT_ENCHANT_NAMES.put(Integer.valueOf(1), "fp");
      SHORT_ENCHANT_NAMES.put(Integer.valueOf(2), "ff");
      SHORT_ENCHANT_NAMES.put(Integer.valueOf(3), "bp");
      SHORT_ENCHANT_NAMES.put(Integer.valueOf(4), "pp");
      SHORT_ENCHANT_NAMES.put(Integer.valueOf(5), "r");
      SHORT_ENCHANT_NAMES.put(Integer.valueOf(6), "aa");
      SHORT_ENCHANT_NAMES.put(Integer.valueOf(7), "th");
      SHORT_ENCHANT_NAMES.put(Integer.valueOf(8), "ds");
      SHORT_ENCHANT_NAMES.put(Integer.valueOf(9), "fw");
      SHORT_ENCHANT_NAMES.put(Integer.valueOf(16), "sh");
      SHORT_ENCHANT_NAMES.put(Integer.valueOf(17), "sm");
      SHORT_ENCHANT_NAMES.put(Integer.valueOf(18), "boa");
      SHORT_ENCHANT_NAMES.put(Integer.valueOf(19), "kb");
      SHORT_ENCHANT_NAMES.put(Integer.valueOf(20), "fa");
      SHORT_ENCHANT_NAMES.put(Integer.valueOf(21), "l");
      SHORT_ENCHANT_NAMES.put(Integer.valueOf(32), "eff");
      SHORT_ENCHANT_NAMES.put(Integer.valueOf(33), "st");
      SHORT_ENCHANT_NAMES.put(Integer.valueOf(34), "ub");
      SHORT_ENCHANT_NAMES.put(Integer.valueOf(35), "for");
      SHORT_ENCHANT_NAMES.put(Integer.valueOf(48), "pow");
      SHORT_ENCHANT_NAMES.put(Integer.valueOf(49), "pun");
      SHORT_ENCHANT_NAMES.put(Integer.valueOf(50), "fl");
      SHORT_ENCHANT_NAMES.put(Integer.valueOf(51), "inf");
      SHORT_ENCHANT_NAMES.put(Integer.valueOf(61), "los");
      SHORT_ENCHANT_NAMES.put(Integer.valueOf(62), "lur");
      SHORT_ENCHANT_NAMES.put(Integer.valueOf(70), "mend");
    }
    

    private final int level;
    public EntityEnchantment(int id, int level)
    {
      this(Enchantment.func_185262_c(id), level);
    }
    
    public EntityEnchantment(Enchantment enchantment, int level) {
      this.enchantment = enchantment;
      this.level = level;
    }
    
    public Enchantment getEnchantment() {
      return enchantment;
    }
    
    public int getLevel() {
      return level;
    }
    
    public String getShortName() {
      int id = Enchantment.func_185258_b(enchantment);
      if (SHORT_ENCHANT_NAMES.containsKey(Integer.valueOf(id))) {
        if (enchantment.func_77325_b() <= 1) {
          return (String)SHORT_ENCHANT_NAMES.get(Integer.valueOf(id));
        }
        return (String)SHORT_ENCHANT_NAMES.get(Integer.valueOf(id)) + level;
      }
      
      return toString();
    }
    
    public String toString()
    {
      return enchantment.func_77316_c(level);
    }
  }
}
