package com.matt.forgehax.util.entity.mobtypes;

import com.matt.forgehax.util.common.PriorityEnum;
import net.minecraft.entity.Entity;
import net.minecraft.entity.passive.EntityWolf;

public class WolfMob
  extends MobType
{
  public WolfMob() {}
  
  protected PriorityEnum getPriority()
  {
    return PriorityEnum.LOW;
  }
  
  protected MobTypeEnum getMobTypeUnchecked(Entity entity)
  {
    EntityWolf wolf = (EntityWolf)entity;
    return wolf.func_70919_bu() ? MobTypeEnum.HOSTILE : MobTypeEnum.NEUTRAL;
  }
  
  public boolean isMobType(Entity entity)
  {
    return entity instanceof EntityWolf;
  }
}
