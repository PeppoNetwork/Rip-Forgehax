package com.matt.forgehax.util.entity.mobtypes;

import com.matt.forgehax.util.common.PriorityEnum;
import net.minecraft.entity.Entity;
import net.minecraft.entity.monster.EntityPigZombie;

public class PigZombieMob
  extends MobType
{
  public PigZombieMob() {}
  
  protected PriorityEnum getPriority()
  {
    return PriorityEnum.LOW;
  }
  
  public boolean isMobType(Entity entity)
  {
    return entity instanceof EntityPigZombie;
  }
  
  protected MobTypeEnum getMobTypeUnchecked(Entity entity)
  {
    EntityPigZombie zombie = (EntityPigZombie)entity;
    return (zombie.func_184734_db()) || (zombie.func_175457_ck()) ? MobTypeEnum.HOSTILE : MobTypeEnum.NEUTRAL;
  }
}
