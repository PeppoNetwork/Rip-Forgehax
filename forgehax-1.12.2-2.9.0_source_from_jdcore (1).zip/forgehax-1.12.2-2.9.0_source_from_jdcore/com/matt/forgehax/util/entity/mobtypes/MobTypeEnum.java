package com.matt.forgehax.util.entity.mobtypes;






public enum MobTypeEnum
{
  PLAYER, 
  



  HOSTILE, 
  



  NEUTRAL, 
  



  FRIENDLY, 
  



  INVALID;
  
  private MobTypeEnum() {}
  
  public boolean isValid() { return ordinal() > 0; }
}
