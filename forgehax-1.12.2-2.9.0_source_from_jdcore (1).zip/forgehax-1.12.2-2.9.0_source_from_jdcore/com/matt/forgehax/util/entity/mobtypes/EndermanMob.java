package com.matt.forgehax.util.entity.mobtypes;

import com.matt.forgehax.util.common.PriorityEnum;
import net.minecraft.entity.Entity;
import net.minecraft.entity.monster.EntityEnderman;

public class EndermanMob
  extends MobType
{
  public EndermanMob() {}
  
  protected PriorityEnum getPriority()
  {
    return PriorityEnum.LOW;
  }
  
  public boolean isMobType(Entity entity)
  {
    return entity instanceof EntityEnderman;
  }
  
  protected MobTypeEnum getMobTypeUnchecked(Entity entity)
  {
    EntityEnderman enderman = (EntityEnderman)entity;
    return enderman.func_70823_r() ? MobTypeEnum.HOSTILE : MobTypeEnum.NEUTRAL;
  }
}
