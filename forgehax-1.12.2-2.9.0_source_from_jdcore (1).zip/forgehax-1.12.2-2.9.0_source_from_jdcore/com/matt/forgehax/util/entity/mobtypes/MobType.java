package com.matt.forgehax.util.entity.mobtypes;

import com.matt.forgehax.util.common.PriorityEnum;
import net.minecraft.entity.Entity;

public abstract class MobType implements Comparable<MobType>
{
  public MobType() {}
  
  protected PriorityEnum getPriority()
  {
    return PriorityEnum.LOWEST;
  }
  
  public boolean isNeutralMob(Entity entity) {
    return false;
  }
  
  public abstract boolean isMobType(Entity paramEntity);
  
  protected abstract MobTypeEnum getMobTypeUnchecked(Entity paramEntity);
  
  public MobTypeEnum getMobType(Entity entity) {
    try {
      return getMobTypeUnchecked(entity);
    } catch (Throwable t) {}
    return MobTypeEnum.HOSTILE;
  }
  

  public int compareTo(MobType o)
  {
    return getPriority().compareTo(o.getPriority());
  }
}
