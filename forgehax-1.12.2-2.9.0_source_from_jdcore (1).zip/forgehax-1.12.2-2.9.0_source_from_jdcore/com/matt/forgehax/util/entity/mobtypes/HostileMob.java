package com.matt.forgehax.util.entity.mobtypes;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EnumCreatureType;

public class HostileMob
  extends MobType
{
  public HostileMob() {}
  
  public boolean isMobType(Entity entity)
  {
    return entity.isCreatureType(EnumCreatureType.MONSTER, false);
  }
  
  protected MobTypeEnum getMobTypeUnchecked(Entity entity)
  {
    return MobTypeEnum.HOSTILE;
  }
}
