package com.matt.forgehax.util.entity;

import com.matt.forgehax.Globals;
import com.matt.forgehax.Helper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;

public class PlayerUtils
  implements Globals
{
  public PlayerUtils() {}
  
  @Deprecated
  public static boolean isLocalPlayer(Entity player)
  {
    EntityPlayer localPlayer = Helper.getLocalPlayer();
    return (localPlayer != null) && (localPlayer.equals(player));
  }
  
  @Deprecated
  public static boolean isFriend(EntityPlayer player) {
    return false;
  }
}
