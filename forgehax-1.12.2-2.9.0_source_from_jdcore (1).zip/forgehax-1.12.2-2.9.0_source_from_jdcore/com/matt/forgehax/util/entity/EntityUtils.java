package com.matt.forgehax.util.entity;

import com.matt.forgehax.Globals;
import com.matt.forgehax.Helper;
import com.matt.forgehax.util.color.Color;
import com.matt.forgehax.util.color.Colors;
import com.matt.forgehax.util.entity.mobtypes.MobType;
import com.matt.forgehax.util.entity.mobtypes.MobTypeEnum;
import com.matt.forgehax.util.entity.mobtypes.MobTypeRegistry;
import java.util.List;
import net.minecraft.block.BlockLiquid;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.entity.monster.EntityEnderman;
import net.minecraft.entity.monster.EntityPigZombie;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.passive.EntityWolf;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

public class EntityUtils implements Globals
{
  public EntityUtils() {}
  
  public static MobTypeEnum getRelationship(Entity entity)
  {
    if ((entity instanceof net.minecraft.client.entity.AbstractClientPlayer)) {
      return MobTypeEnum.PLAYER;
    }
    
    for (MobType type : MobTypeRegistry.getSortedSpecialMobTypes()) {
      if (type.isMobType(entity)) {
        return type.getMobType(entity);
      }
    }
    
    if (MobTypeRegistry.HOSTILE.isMobType(entity))
      return MobTypeEnum.HOSTILE;
    if (MobTypeRegistry.FRIENDLY.isMobType(entity)) {
      return MobTypeEnum.FRIENDLY;
    }
    return MobTypeEnum.HOSTILE;
  }
  


  public static boolean isBatsDisabled = false;
  





  public static boolean isMobAggressive(Entity entity)
  {
    if ((entity instanceof EntityPigZombie))
    {
      if ((((EntityPigZombie)entity).func_184734_db()) || (((EntityPigZombie)entity).func_175457_ck())) {
        if (!((EntityPigZombie)entity).func_175457_ck())
        {
          com.matt.forgehax.asm.reflection.FastReflection.Fields.EntityPigZombie_angerLevel.set(entity, Integer.valueOf(400));
        }
        return true;
      }
    } else { if ((entity instanceof EntityWolf))
        return (((EntityWolf)entity).func_70919_bu()) && (!MCfield_71439_g.equals(((EntityWolf)entity).func_70902_q()));
      if ((entity instanceof EntityEnderman))
        return ((EntityEnderman)entity).func_70823_r();
    }
    return false;
  }
  


  public static boolean isLiving(Entity entity)
  {
    return entity instanceof EntityLivingBase;
  }
  


  public static boolean isPlayer(Entity entity)
  {
    return entity instanceof EntityPlayer;
  }
  
  public static boolean isLocalPlayer(Entity entity) {
    return java.util.Objects.equals(Helper.getLocalPlayer(), entity);
  }
  
  public static boolean isFakeLocalPlayer(Entity entity) {
    return (entity != null) && (entity.func_145782_y() == -100);
  }
  
  public static boolean isValidEntity(Entity entity) {
    Entity riding = Helper.getLocalPlayer().func_184187_bx();
    return (field_70173_aa > 1) && 
      (!isFakeLocalPlayer(entity)) && ((riding == null) || 
      (!riding.equals(entity)));
  }
  
  public static boolean isAlive(Entity entity) {
    return (isLiving(entity)) && (!field_70128_L) && (((EntityLivingBase)entity).func_110143_aJ() > 0.0F);
  }
  


  public static boolean isNeutralMob(Entity entity)
  {
    return ((entity instanceof EntityPigZombie)) || ((entity instanceof EntityWolf)) || ((entity instanceof EntityEnderman));
  }
  




  public static boolean isFriendlyMob(Entity entity)
  {
    return ((entity.isCreatureType(EnumCreatureType.CREATURE, false)) && 
      (!isNeutralMob(entity))) || 
      ((entity.isCreatureType(EnumCreatureType.AMBIENT, false)) && (!isBatsDisabled)) || ((entity instanceof EntityVillager)) || ((entity instanceof net.minecraft.entity.monster.EntityIronGolem)) || (
      

      (isNeutralMob(entity)) && (!isMobAggressive(entity)));
  }
  


  public static boolean isHostileMob(Entity entity)
  {
    return ((entity.isCreatureType(EnumCreatureType.MONSTER, false)) && 
      (!isNeutralMob(entity))) || 
      (isMobAggressive(entity));
  }
  


  public static Vec3d getInterpolatedAmount(Entity entity, double x, double y, double z)
  {
    return new Vec3d((field_70165_t - field_70142_S) * x, (field_70163_u - field_70137_T) * y, (field_70161_v - field_70136_U) * z);
  }
  


  public static Vec3d getInterpolatedAmount(Entity entity, Vec3d vec)
  {
    return getInterpolatedAmount(entity, field_72450_a, field_72448_b, field_72449_c);
  }
  
  public static Vec3d getInterpolatedAmount(Entity entity, double ticks) {
    return getInterpolatedAmount(entity, ticks, ticks, ticks);
  }
  


  public static Vec3d getInterpolatedPos(Entity entity, double ticks)
  {
    return 
      new Vec3d(field_70142_S, field_70137_T, field_70136_U).func_178787_e(getInterpolatedAmount(entity, ticks));
  }
  


  public static Vec3d getInterpolatedEyePos(Entity entity, double ticks)
  {
    return getInterpolatedPos(entity, ticks).func_72441_c(0.0D, entity.func_70047_e(), 0.0D);
  }
  


  public static Vec3d getEyePos(Entity entity)
  {
    return new Vec3d(field_70165_t, field_70163_u + entity.func_70047_e(), field_70161_v);
  }
  


  public static Vec3d getOBBCenter(Entity entity)
  {
    AxisAlignedBB obb = entity.func_174813_aQ();
    return new Vec3d((field_72336_d + field_72340_a) / 2.0D, (field_72337_e + field_72338_b) / 2.0D, (field_72334_f + field_72339_c) / 2.0D);
  }
  




  public static RayTraceResult traceEntity(World world, Vec3d start, Vec3d end, List<Entity> filter)
  {
    RayTraceResult result = null;
    double hitDistance = -1.0D;
    
    for (Entity ent : field_72996_f)
    {
      if (!filter.contains(ent))
      {


        double distance = start.func_72438_d(ent.func_174791_d());
        RayTraceResult trace = ent.func_174813_aQ().func_72327_a(start, end);
        
        if ((trace != null) && ((hitDistance == -1.0D) || (distance < hitDistance))) {
          hitDistance = distance;
          result = trace;
          field_72308_g = ent;
        }
      }
    }
    return result;
  }
  


  public static int getDrawColor(EntityLivingBase living)
  {
    if (isPlayer(living)) {
      if (PlayerUtils.isFriend((EntityPlayer)living)) {
        return Colors.GREEN.toBuffer();
      }
      return Colors.RED.toBuffer();
    }
    if (isHostileMob(living))
      return Colors.ORANGE.toBuffer();
    if (isFriendlyMob(living)) {
      return Colors.GREEN.toBuffer();
    }
    return Colors.WHITE.toBuffer();
  }
  
  public static boolean isDrivenByPlayer(Entity entityIn)
  {
    return (Helper.getLocalPlayer() != null) && (entityIn != null) && (entityIn == Helper.getRidingEntity());
  }
  
  public static boolean isAboveWater(Entity entity) {
    return isAboveWater(entity, false);
  }
  
  public static boolean isAboveWater(Entity entity, boolean packet) {
    if (entity == null) {
      return false;
    }
    




    double y = field_70163_u - (isPlayer(entity) ? 0.2D : packet ? 0.03D : 0.5D);
    



    for (int x = MathHelper.func_76128_c(field_70165_t); x < MathHelper.func_76143_f(field_70165_t); x++) {
      for (int z = MathHelper.func_76128_c(field_70161_v); z < MathHelper.func_76143_f(field_70161_v); z++) {
        BlockPos pos = new BlockPos(x, MathHelper.func_76128_c(y), z);
        
        if ((Helper.getWorld().func_180495_p(pos).func_177230_c() instanceof BlockLiquid)) {
          return true;
        }
      }
    }
    
    return false;
  }
  
  public static boolean isInWater(Entity entity) {
    if (entity == null) {
      return false;
    }
    
    double y = field_70163_u + 0.01D;
    
    for (int x = MathHelper.func_76128_c(field_70165_t); x < MathHelper.func_76143_f(field_70165_t); x++) {
      for (int z = MathHelper.func_76128_c(field_70161_v); z < MathHelper.func_76143_f(field_70161_v); z++) {
        BlockPos pos = new BlockPos(x, (int)y, z);
        
        if ((Helper.getWorld().func_180495_p(pos).func_177230_c() instanceof BlockLiquid)) {
          return true;
        }
      }
    }
    
    return false;
  }
}
