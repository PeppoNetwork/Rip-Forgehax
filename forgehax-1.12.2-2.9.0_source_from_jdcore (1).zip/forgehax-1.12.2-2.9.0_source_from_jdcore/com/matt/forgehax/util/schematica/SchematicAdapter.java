package com.matt.forgehax.util.schematica;

import com.github.lunatrius.schematica.api.ISchematic;
import com.github.lunatrius.schematica.client.world.SchematicWorld;
import net.minecraft.util.math.BlockPos;

public final class SchematicAdapter implements Schematic
{
  private final SchematicWorld schematic;
  
  public SchematicAdapter(SchematicWorld schematicWorld)
  {
    schematic = schematicWorld;
  }
  

  public net.minecraft.block.state.IBlockState desiredState(BlockPos pos)
  {
    return schematic.getSchematic().getBlockState(pos);
  }
  
  public int widthX()
  {
    return schematic.getSchematic().getWidth();
  }
  
  public int heightY()
  {
    return schematic.getSchematic().getHeight();
  }
  
  public int lengthZ()
  {
    return schematic.getSchematic().getLength();
  }
}
