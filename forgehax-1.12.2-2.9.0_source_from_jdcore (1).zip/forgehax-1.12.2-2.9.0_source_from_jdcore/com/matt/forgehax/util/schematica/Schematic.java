package com.matt.forgehax.util.schematica;

import net.minecraft.util.math.BlockPos;

public abstract interface Schematic
{
  public net.minecraft.block.state.IBlockState desiredState(int x, int y, int z)
  {
    return desiredState(new BlockPos(x, y, z));
  }
  
  public abstract net.minecraft.block.state.IBlockState desiredState(BlockPos paramBlockPos);
  
  public boolean inSchematic(BlockPos pos) {
    return inSchematic(pos.func_177958_n(), pos.func_177956_o(), pos.func_177952_p());
  }
  
  public boolean inSchematic(int x, int y, int z) {
    return (x >= 0) && (x < widthX()) && (y >= 0) && (y < heightY()) && (z >= 0) && (z < lengthZ());
  }
  
  public abstract int widthX();
  
  public abstract int heightY();
  
  public abstract int lengthZ();
}
