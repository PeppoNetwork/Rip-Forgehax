package com.matt.forgehax.util.blocks.exceptions;

public class BadBlockEntryFormatException
  extends Exception
{
  public BadBlockEntryFormatException() {}
}
