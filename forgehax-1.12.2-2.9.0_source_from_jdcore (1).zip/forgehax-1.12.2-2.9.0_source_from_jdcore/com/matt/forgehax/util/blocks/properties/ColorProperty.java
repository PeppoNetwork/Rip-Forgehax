package com.matt.forgehax.util.blocks.properties;

import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import com.matt.forgehax.util.color.Color;
import com.matt.forgehax.util.color.Colors;
import java.io.IOException;
import net.minecraft.util.math.MathHelper;



public class ColorProperty
  implements IBlockProperty
{
  private static final String HEADING = "color";
  private static final int DEFAULT_COLOR_BUFFER = Colors.WHITE.toBuffer();
  private static final int[] DEFAULT_COLOR_ARRAY = Color.of(DEFAULT_COLOR_BUFFER).toIntegerArray();
  
  private int r;
  private int g;
  private int b;
  private int a;
  private int buffer;
  
  public ColorProperty()
  {
    set(DEFAULT_COLOR_BUFFER);
  }
  
  public int getRed() {
    return r;
  }
  
  public int getGreen() {
    return g;
  }
  
  public int getBlue() {
    return b;
  }
  
  public int getAlpha() {
    return a;
  }
  
  public int[] getAsArray() {
    return new int[] { r, g, b, a };
  }
  
  public int getAsBuffer() {
    return buffer;
  }
  
  public void set(int r, int g, int b, int a) {
    this.r = MathHelper.func_76125_a(r, 0, 255);
    this.g = MathHelper.func_76125_a(g, 0, 255);
    this.b = MathHelper.func_76125_a(b, 0, 255);
    this.a = MathHelper.func_76125_a(a, 0, 255);
    buffer = Color.of(r, g, b, a).toBuffer();
  }
  
  public void set(int buffer) {
    int[] rgba = Color.of(buffer).toIntegerArray();
    set(rgba[0], rgba[1], rgba[2], rgba[3]);
  }
  
  public void serialize(JsonWriter writer) throws IOException
  {
    writer.value(buffer);
  }
  
  public void deserialize(JsonReader reader) throws IOException
  {
    set(reader.nextInt());
  }
  
  public boolean isNecessary()
  {
    return buffer != DEFAULT_COLOR_BUFFER;
  }
  
  public String helpText()
  {
    return String.format("(%d, %d, %d, %d)", new Object[] { Integer.valueOf(r), Integer.valueOf(g), Integer.valueOf(b), Integer.valueOf(a) });
  }
  
  public IBlockProperty newImmutableInstance()
  {
    return new ImmutableColor(null);
  }
  
  public String toString()
  {
    return "color";
  }
  
  private static class ImmutableColor extends ColorProperty {
    private ImmutableColor() {}
    
    public int getRed() {
      return ColorProperty.DEFAULT_COLOR_ARRAY[0];
    }
    
    public int getGreen()
    {
      return ColorProperty.DEFAULT_COLOR_ARRAY[1];
    }
    
    public int getBlue()
    {
      return ColorProperty.DEFAULT_COLOR_ARRAY[2];
    }
    
    public int getAlpha()
    {
      return ColorProperty.DEFAULT_COLOR_ARRAY[3];
    }
    
    public int getAsBuffer()
    {
      return ColorProperty.DEFAULT_COLOR_BUFFER;
    }
    
    public int[] getAsArray()
    {
      return ColorProperty.DEFAULT_COLOR_ARRAY;
    }
    
    public void set(int buffer) {}
    
    public void set(int r, int g, int b, int a) {}
  }
}
