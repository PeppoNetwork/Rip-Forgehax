package com.matt.forgehax.util.blocks.properties;

import com.google.common.collect.Sets;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import javax.annotation.Nullable;

public class BoundProperty
  implements IBlockProperty
{
  private static final String HEADING = "bounds";
  
  public BoundProperty() {}
  
  private final Collection<Bound> bounds = Sets.newHashSet();
  
  public boolean add(int minY, int maxY) {
    return bounds.add(new Bound(minY, maxY));
  }
  
  public boolean remove(int minY, int maxY) {
    Bound bound = get(minY, maxY);
    return (bound != null) && (bounds.remove(bound));
  }
  
  @Nullable
  public Bound get(int minY, int maxY) {
    for (Bound bound : bounds) {
      if ((bound.getMin() == minY) && (bound.getMax() == maxY)) {
        return bound;
      }
    }
    return null;
  }
  
  public Collection<Bound> getAll() {
    return Collections.unmodifiableCollection(bounds);
  }
  
  public boolean isWithinBoundaries(int posY) {
    if (bounds.isEmpty()) {
      return true;
    }
    for (Bound bound : bounds) {
      if (bound.isWithinBound(posY)) {
        return true;
      }
    }
    return false;
  }
  
  public void serialize(JsonWriter writer)
    throws IOException
  {
    writer.beginArray();
    for (Bound bound : bounds) {
      writer.beginArray();
      writer.value(bound.getMin());
      writer.value(bound.getMax());
      writer.endArray();
    }
    writer.endArray();
  }
  
  public void deserialize(JsonReader reader) throws IOException
  {
    reader.beginArray();
    while (reader.hasNext()) {
      reader.beginArray();
      add(reader.nextInt(), reader.nextInt());
      reader.endArray();
    }
    reader.endArray();
  }
  
  public boolean isNecessary()
  {
    return !bounds.isEmpty();
  }
  
  public String helpText()
  {
    StringBuilder builder = new StringBuilder("{");
    Iterator<Bound> it = bounds.iterator();
    while (it.hasNext()) {
      Bound bound = (Bound)it.next();
      builder.append('[');
      builder.append(bound.getMin());
      builder.append(',');
      builder.append(bound.getMax());
      builder.append(']');
      if (it.hasNext()) {
        builder.append(", ");
      }
    }
    builder.append('}');
    return builder.toString();
  }
  
  public IBlockProperty newImmutableInstance()
  {
    return new ImmutableBoundProperty(null);
  }
  
  public String toString()
  {
    return "bounds";
  }
  
  public static class Bound
  {
    private final int min;
    private final int max;
    
    public Bound(int min, int max) throws IllegalArgumentException {
      if (min > max) {
        throw new IllegalArgumentException("min cannot be greater than max");
      }
      this.min = min;
      this.max = max;
    }
    
    public int getMin() {
      return min;
    }
    
    public int getMax() {
      return max;
    }
    
    public boolean isWithinBound(int y) {
      return (y >= min) && (y <= max);
    }
    
    public boolean equals(Object obj)
    {
      return ((obj instanceof Bound)) && (max == max) && (min == min);
    }
  }
  
  private static class ImmutableBoundProperty extends BoundProperty {
    private ImmutableBoundProperty() {}
    
    public boolean add(int minY, int maxY) {
      return false;
    }
    
    public boolean remove(int minY, int maxY)
    {
      return false;
    }
    
    public BoundProperty.Bound get(int minY, int maxY)
    {
      return null;
    }
    
    public Collection<BoundProperty.Bound> getAll()
    {
      return Collections.emptySet();
    }
    
    public boolean isWithinBoundaries(int posY)
    {
      return true;
    }
  }
}
