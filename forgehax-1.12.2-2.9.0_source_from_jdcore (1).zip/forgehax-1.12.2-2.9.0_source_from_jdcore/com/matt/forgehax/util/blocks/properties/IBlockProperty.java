package com.matt.forgehax.util.blocks.properties;

import com.matt.forgehax.util.serialization.ISerializableJson;



















public abstract interface IBlockProperty
  extends ISerializableJson
{
  public abstract boolean isNecessary();
  
  public abstract String helpText();
  
  public abstract IBlockProperty newImmutableInstance();
  
  public <T extends IBlockProperty> T cast()
  {
    return this;
  }
  
  public <T extends IBlockProperty> T checkedCast() {
    try {
      return cast();
    } catch (Throwable t) {}
    return null;
  }
}
