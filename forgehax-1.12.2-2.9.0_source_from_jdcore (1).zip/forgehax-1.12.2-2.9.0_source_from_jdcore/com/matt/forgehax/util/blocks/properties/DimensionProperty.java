package com.matt.forgehax.util.blocks.properties;

import com.google.common.collect.Sets;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonToken;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import java.util.Collection;
import java.util.Iterator;
import java.util.Objects;
import net.minecraft.world.DimensionType;
import net.minecraftforge.common.DimensionManager;

public class DimensionProperty
  implements IBlockProperty
{
  private static final String HEADING = "dimensions";
  
  public DimensionProperty() {}
  
  private Collection<DimensionType> dimensions = Sets.newHashSet();
  
  private boolean add(DimensionType type) {
    return (type != null) && (dimensions.add(type));
  }
  
  public boolean add(int id) {
    try {
      return add(DimensionManager.getProviderType(id));
    }
    catch (Exception e) {}
    return false;
  }
  
  private boolean remove(DimensionType type)
  {
    return (type != null) && (dimensions.remove(type));
  }
  
  public boolean remove(int id) {
    try {
      return remove(DimensionManager.getProviderType(id));
    } catch (Exception e) {}
    return false;
  }
  
  public boolean contains(int id)
  {
    if (dimensions.isEmpty()) {
      return true;
    }
    try {
      return dimensions.contains(DimensionManager.getProviderType(id));
    } catch (Exception e) {}
    return false;
  }
  

  public void serialize(JsonWriter writer)
    throws IOException
  {
    writer.beginArray();
    for (DimensionType dimension : dimensions) {
      writer.value(dimension.func_186065_b());
    }
    writer.endArray();
  }
  
  public void deserialize(JsonReader reader) throws IOException
  {
    reader.beginArray();
    while ((reader.hasNext()) && (reader.peek().equals(JsonToken.STRING))) {
      String dim = reader.nextString();
      for (DimensionType type : DimensionType.values()) {
        if (Objects.equals(type.func_186065_b(), dim)) {
          add(type);
          break;
        }
      }
    }
  }
  
  public boolean isNecessary()
  {
    return !dimensions.isEmpty();
  }
  
  public String helpText()
  {
    StringBuilder builder = new StringBuilder("{");
    Iterator<DimensionType> it = dimensions.iterator();
    while (it.hasNext()) {
      String name = ((DimensionType)it.next()).func_186065_b();
      builder.append(name);
      if (it.hasNext()) {
        builder.append(", ");
      }
    }
    builder.append("}");
    return builder.toString();
  }
  
  public IBlockProperty newImmutableInstance()
  {
    return new ImmutableDimension(null);
  }
  
  public String toString()
  {
    return "dimensions";
  }
  
  private static class ImmutableDimension extends DimensionProperty {
    private ImmutableDimension() {}
    
    public boolean add(int id) {
      return false;
    }
    
    public boolean remove(int id)
    {
      return false;
    }
    
    public boolean contains(int id)
    {
      return true;
    }
  }
}
