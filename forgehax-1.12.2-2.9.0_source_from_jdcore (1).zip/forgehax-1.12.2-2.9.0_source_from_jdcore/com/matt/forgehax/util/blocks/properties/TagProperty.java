package com.matt.forgehax.util.blocks.properties;

import com.google.common.collect.Sets;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;
import java.util.Collection;
import java.util.Iterator;
import joptsimple.internal.Strings;

public class TagProperty
  implements IBlockProperty
{
  private static final String HEADING = "tags";
  
  public TagProperty() {}
  
  private final Collection<String> tags = Sets.newTreeSet(String.CASE_INSENSITIVE_ORDER);
  
  public boolean add(String tag) {
    return (!Strings.isNullOrEmpty(tag)) && (tags.add(tag));
  }
  
  public boolean remove(String tag) {
    return (!Strings.isNullOrEmpty(tag)) && (tags.remove(tag));
  }
  
  public boolean contains(String tag) {
    return (!Strings.isNullOrEmpty(tag)) && (tags.contains(tag));
  }
  
  public void serialize(JsonWriter writer) throws IOException
  {
    writer.beginArray();
    for (String tag : tags) {
      writer.value(tag);
    }
    writer.endArray();
  }
  
  public void deserialize(JsonReader reader) throws IOException
  {
    reader.beginArray();
    while (reader.hasNext()) {
      add(reader.nextString());
    }
    reader.endArray();
  }
  
  public boolean isNecessary()
  {
    return !tags.isEmpty();
  }
  
  public String helpText()
  {
    StringBuilder builder = new StringBuilder("{");
    Iterator<String> it = tags.iterator();
    while (it.hasNext()) {
      String tag = (String)it.next();
      builder.append(tag);
      if (it.hasNext()) {
        builder.append(", ");
      }
    }
    builder.append("}");
    return builder.toString();
  }
  
  public IBlockProperty newImmutableInstance()
  {
    return new ImmutableBlockTag(null);
  }
  
  public String toString()
  {
    return "tags";
  }
  
  private static class ImmutableBlockTag extends TagProperty {
    private ImmutableBlockTag() {}
    
    public boolean add(String tag) {
      return false;
    }
    
    public boolean remove(String tag)
    {
      return false;
    }
    
    public boolean contains(String tag)
    {
      return false;
    }
  }
}
