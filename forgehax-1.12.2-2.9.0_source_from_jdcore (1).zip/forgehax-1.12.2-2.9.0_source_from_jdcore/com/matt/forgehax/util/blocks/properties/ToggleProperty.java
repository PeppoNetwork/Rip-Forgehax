package com.matt.forgehax.util.blocks.properties;

import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import java.io.IOException;

public class ToggleProperty
  implements IBlockProperty
{
  private static final String HEADING = "enabled";
  
  public ToggleProperty() {}
  
  private boolean enabled = true;
  
  public boolean isEnabled() {
    return enabled;
  }
  
  public void setEnabled(boolean enabled) {
    this.enabled = enabled;
  }
  
  public void enable() {
    setEnabled(true);
  }
  
  public void disable() {
    setEnabled(false);
  }
  
  public void toggle() {
    if (enabled) {
      disable();
    } else {
      enable();
    }
  }
  
  public void serialize(JsonWriter writer) throws IOException
  {
    writer.value(enabled);
  }
  
  public void deserialize(JsonReader reader) throws IOException
  {
    setEnabled(reader.nextBoolean());
  }
  
  public boolean isNecessary()
  {
    return !enabled;
  }
  
  public String helpText()
  {
    return Boolean.toString(enabled);
  }
  
  public IBlockProperty newImmutableInstance()
  {
    return new ImmutableToggle(null);
  }
  
  public String toString()
  {
    return "enabled";
  }
  
  private static class ImmutableToggle extends ToggleProperty {
    private ImmutableToggle() {}
    
    public boolean isEnabled() {
      return true;
    }
    
    public void setEnabled(boolean enabled) {}
    
    public void enable() {}
    
    public void disable() {}
    
    public void toggle() {}
  }
}
