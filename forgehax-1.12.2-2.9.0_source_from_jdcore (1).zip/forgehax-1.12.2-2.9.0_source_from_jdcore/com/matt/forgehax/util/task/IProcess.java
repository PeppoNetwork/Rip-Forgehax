package com.matt.forgehax.util.task;

import com.google.common.collect.Maps;
import java.util.Map;




public abstract interface IProcess
{
  public abstract void process(DataEntry paramDataEntry);
  
  public static class DataEntry
  {
    private final Map<String, Object> data = Maps.newTreeMap(String.CASE_INSENSITIVE_ORDER);
    
    public DataEntry() {}
    
    public <T> T getOrDefault(String o, T defaultValue) { try { return data.get(o);
      } catch (Throwable t) {}
      return defaultValue;
    }
    
    public <T> T get(String o)
    {
      return getOrDefault(o, null);
    }
    
    public void set(String name, Object o) {
      data.put(name, o);
    }
  }
}
