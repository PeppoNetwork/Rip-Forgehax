package com.matt.forgehax.util.task;

import com.google.common.collect.Lists;
import com.google.common.collect.Queues;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Queue;

public abstract interface TaskChain<E> extends Iterator<E>
{
  public static final TaskChain EMPTY = new TaskChain()
  {
    public TaskChain<Object> then(Object task)
    {
      throw new UnsupportedOperationException();
    }
    
    public TaskChain<Object> thenLast(Object task)
    {
      throw new UnsupportedOperationException();
    }
    
    public boolean hasNext()
    {
      return false;
    }
    
    public Object next()
    {
      return null;
    }
  };
  
  public static <T> Builder<T> builder() {
    return new Builder();
  }
  
  public static <T> TaskChain<T> singleton(T taskIn) {
    new TaskChain()
    {
      public TaskChain<T> then(T task) {
        throw new UnsupportedOperationException();
      }
      
      public TaskChain<T> thenLast(T task)
      {
        throw new UnsupportedOperationException();
      }
      
      T task = val$taskIn;
      
      public boolean hasNext()
      {
        return task != null;
      }
      
      public T next()
      {
        T ret = task;
        task = null;
        return ret;
      }
    };
  }
  
  public static <T> TaskChain<T> empty() {
    return EMPTY;
  }
  
  public abstract TaskChain<E> then(E paramE);
  
  public abstract TaskChain<E> thenLast(E paramE);
  
  public boolean isEmpty() {
    return !hasNext();
  }
  
  public static class Builder<T> {
    public Builder() {}
    
    private final Queue<T> queue = Queues.newArrayDeque();
    
    public Builder<T> then(T task) {
      queue.add(task);
      return this;
    }
    
    public Builder<T> addAll(Collection<T> tsks) {
      queue.addAll(tsks);
      return this;
    }
    
    public Builder<T> collect(TaskChain<T> ts) {
      while (ts.hasNext()) {
        queue.add(ts.next());
      }
      return this;
    }
    
    public TaskChain<T> build() {
      return new TaskChain.DynamicTaskChain(queue, null);
    }
  }
  
  public static class DynamicTaskChain<T> implements TaskChain<T>
  {
    private final List<T> tasks = Lists.newArrayList();
    
    private DynamicTaskChain() {}
    
    private DynamicTaskChain(Collection<T> collection)
    {
      tasks.addAll(collection);
    }
    
    public TaskChain<T> then(T task)
    {
      tasks.add(0, task);
      return this;
    }
    
    public TaskChain<T> thenLast(T task)
    {
      tasks.add(task);
      return null;
    }
    
    public boolean hasNext()
    {
      return !tasks.isEmpty();
    }
    
    public T next()
    {
      return tasks.remove(0);
    }
  }
}
