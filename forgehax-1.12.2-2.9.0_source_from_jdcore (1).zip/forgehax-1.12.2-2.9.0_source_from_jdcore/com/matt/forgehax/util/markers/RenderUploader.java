package com.matt.forgehax.util.markers;

import com.matt.forgehax.Globals;
import com.matt.forgehax.asm.reflection.FastReflection.Fields;
import com.matt.forgehax.asm.utils.fasttype.FastField;
import java.util.concurrent.locks.ReentrantLock;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.chunk.RenderChunk;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.renderer.vertex.VertexBuffer;
import net.minecraft.client.renderer.vertex.VertexFormat;
import net.minecraft.util.math.BlockPos;

public class RenderUploader<E extends Tessellator>
  implements Globals
{
  private final Uploaders<E> parent;
  private final ReentrantLock _lock = new ReentrantLock();
  



  private final VertexBuffer vertexBuffer;
  


  private volatile E tessellator;
  


  private volatile Thread currentThread;
  


  private boolean complete = false;
  private boolean uploaded = false;
  private int renderCount = 0;
  private BlockPos region = null;
  
  public RenderUploader(Uploaders<E> parent, VertexFormat format) {
    this.parent = parent;
    vertexBuffer = new VertexBuffer(format);
  }
  
  public RenderUploader(Uploaders<E> parent) {
    this(parent, DefaultVertexFormats.field_181706_f);
  }
  
  public boolean isComplete() {
    return complete;
  }
  
  public void setComplete(boolean complete) {
    this.complete = complete;
  }
  




  public E getTessellator()
  {
    return tessellator;
  }
  
  public void setTessellator(E tessellator) throws RenderUploader.UploaderException {
    if ((tessellator != null) && (this.tessellator != null)) {
      throw new UploaderException("Tried to set tessellator without removing the previous one");
    }
    this.tessellator = tessellator;
  }
  
  public void takeTessellator() throws RenderUploader.UploaderException, InterruptedException
  {
    setTessellator(parent.cache().take());
  }
  
  public void freeTessellator() throws RenderUploader.UploaderException, TessellatorCache.TessellatorCacheFreeException
  {
    if (tessellator != null)
    {
      if (isTessellatorDrawing()) {
        getBufferBuilder().func_178977_d();
      }
      
      getBufferBuilder().func_178969_c(0.0D, 0.0D, 0.0D);
      
      parent.cache().free(tessellator);
      
      setTessellator(null);
    }
  }
  
  public BufferBuilder getBufferBuilder() {
    return getTessellator().func_178180_c();
  }
  


  public void setCurrentThread()
  {
    currentThread = Thread.currentThread();
  }
  
  public void nullifyCurrentThread() {
    currentThread = null;
  }
  



  public void validateCurrentThread()
    throws RenderUploader.ThreadMismatchException
  {
    if (currentThread != Thread.currentThread()) {
      throw new ThreadMismatchException("Tried executing in incorrect thread (this is normal)");
    }
  }
  


  public boolean isCorrectCurrentThread()
  {
    return currentThread == Thread.currentThread();
  }
  


  public VertexBuffer getVertexBuffer()
  {
    return vertexBuffer;
  }
  



  public boolean upload()
    throws RenderUploader.UploaderException
  {
    if (getTessellator() == null) {
      return false;
    }
    if (!MC.func_152345_ab()) {
      throw new UploaderException("Not calling from main Minecraft thread");
    }
    




    boolean update = false;
    
    lock().lock();
    try {
      if (isTessellatorDrawing()) {
        finishDrawing();
        update = true;
      }
      
      getBufferBuilder().func_178965_a();
      vertexBuffer.func_181722_a(getBufferBuilder().func_178966_f());
      
      setComplete(true);
      uploaded = true;
      lock().unlock();
    }
    finally
    {
      setComplete(true);
      uploaded = true;
      lock().unlock();
    }
    return update;
  }
  



  public void unload()
    throws RenderUploader.UploaderException
  {
    if (!isUploaded()) {
      return;
    }
    if (!MC.func_152345_ab()) {
      throw new UploaderException("Not calling from main Minecraft thread");
    }
    try
    {
      vertexBuffer.func_177362_c();
      
      uploaded = false;
      setComplete(false);
      resetRegion();
    }
    finally
    {
      uploaded = false;
      setComplete(false);
      resetRegion();
    }
  }
  


  public boolean isTessellatorDrawing()
  {
    return (getTessellator() != null) && 
      (((Boolean)FastReflection.Fields.BufferBuilder_isDrawing.get(getBufferBuilder())).booleanValue());
  }
  
  public void finishDrawing() {
    if (!isTessellatorDrawing()) {
      return;
    }
    
    renderCount = (getBufferBuilder().func_178989_h() / 24);
    getBufferBuilder().func_178977_d();
  }
  


  public boolean isUploaded()
  {
    return uploaded;
  }
  




  public int getRenderCount()
  {
    return renderCount;
  }
  
  public void resetRenderCount() {
    renderCount = 0;
  }
  
  public void setRegion(RenderChunk chunk) {
    region = new BlockPos(chunk.func_178568_j());
  }
  
  public void resetRegion() {
    region = null;
  }
  
  public BlockPos getRegion() {
    return region;
  }
  
  public boolean isCorrectRegion(RenderChunk chunk) {
    return (region != null) && (region.equals(chunk.func_178568_j()));
  }
  
  public ReentrantLock lock() {
    return _lock;
  }
  
  public static class UploaderException extends Exception
  {
    public UploaderException(String msg) {
      super();
    }
  }
  
  public static class ThreadMismatchException extends RenderUploader.UploaderException
  {
    public ThreadMismatchException(String msg) {
      super();
    }
  }
  
  public static class VertexBufferException extends RenderUploader.UploaderException
  {
    public VertexBufferException(String msg) {
      super();
    }
  }
}
