package com.matt.forgehax.util.markers;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.Queues;
import com.matt.forgehax.Globals;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.function.Supplier;
import net.minecraft.client.renderer.Tessellator;


public class TessellatorCache<E extends Tessellator>
  implements Globals
{
  private final BlockingQueue<E> cache;
  private final List<E> originals;
  
  public TessellatorCache(int capacity, Supplier<E> supplier)
  {
    cache = Queues.newArrayBlockingQueue(capacity);
    

    for (int i = 0; i < capacity; i++) {
      cache.add(supplier.get());
    }
    

    originals = ImmutableList.copyOf(cache);
  }
  
  public E take() throws InterruptedException {
    return (Tessellator)cache.take();
  }
  
  public boolean free(E tessellator) throws TessellatorCache.TessellatorCacheFreeException {
    if (!originals.contains(tessellator)) {
      throw new TessellatorCacheFreeException("Tried to add tessellator that wasn't originally in cache");
    }
    
    return (tessellator != null) && (cache.offer(tessellator));
  }
  
  public int size() {
    return cache.size();
  }
  
  public int capacity() {
    return originals.size();
  }
  
  public static class TessellatorCacheFreeException extends Exception
  {
    public TessellatorCacheFreeException(String msg) {
      super();
    }
  }
}
