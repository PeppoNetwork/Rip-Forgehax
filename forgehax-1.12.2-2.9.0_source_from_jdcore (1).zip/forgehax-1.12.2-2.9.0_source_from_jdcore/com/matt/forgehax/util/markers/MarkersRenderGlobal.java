package com.matt.forgehax.util.markers;

import com.matt.forgehax.Globals;
import java.util.Collection;
import javax.annotation.Nullable;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.chunk.ChunkRenderDispatcher;
import net.minecraft.client.renderer.culling.ICamera;
import net.minecraft.client.resources.IResourceManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.world.World;


public class MarkersRenderGlobal
  extends RenderGlobal
  implements Globals
{
  private static final MarkersRenderGlobal INSTANCE = new MarkersRenderGlobal(MC);
  
  public static MarkersRenderGlobal getInstance() {
    return INSTANCE;
  }
  
  private ChunkRenderDispatcher renderDispatcher = null;
  
  public MarkersRenderGlobal(Minecraft mcIn) {
    super(mcIn);
  }
  
  public void func_110549_a(IResourceManager resourceManager)
  {
    super.func_110549_a(resourceManager);
  }
  
  public void func_174975_c()
  {
    super.func_174975_c();
  }
  
  protected boolean func_174985_d()
  {
    return super.func_174985_d();
  }
  
  public void func_72732_a(@Nullable WorldClient worldClientIn)
  {
    super.func_72732_a(worldClientIn);
  }
  
  public void func_72712_a()
  {
    super.func_72712_a();
  }
  
  protected void func_174986_e()
  {
    super.func_174986_e();
  }
  
  public void func_72720_a(int width, int height)
  {
    super.func_72720_a(width, height);
  }
  
  public void func_180446_a(Entity renderViewEntity, ICamera camera, float partialTicks)
  {
    super.func_180446_a(renderViewEntity, camera, partialTicks);
  }
  
  public String func_72735_c()
  {
    return super.func_72735_c();
  }
  
  protected int func_184382_g()
  {
    return super.func_184382_g();
  }
  
  public String func_72723_d()
  {
    return super.func_72723_d();
  }
  





  public void func_174970_a(Entity viewEntity, double partialTicks, ICamera camera, int frameCount, boolean playerSpectator)
  {
    super.func_174970_a(viewEntity, partialTicks, camera, frameCount, playerSpectator);
  }
  

  public int func_174977_a(BlockRenderLayer blockLayerIn, double partialTicks, int pass, Entity entityIn)
  {
    return super.func_174977_a(blockLayerIn, partialTicks, pass, entityIn);
  }
  
  public void func_72734_e()
  {
    super.func_72734_e();
  }
  
  public void func_174976_a(float partialTicks, int pass)
  {
    super.func_174976_a(partialTicks, pass);
  }
  

  public void func_180447_b(float partialTicks, int pass, double p_180447_3_, double p_180447_5_, double p_180447_7_)
  {
    super.func_180447_b(partialTicks, pass, p_180447_3_, p_180447_5_, p_180447_7_);
  }
  
  public boolean func_72721_a(double x, double y, double z, float partialTicks)
  {
    return super.func_72721_a(x, y, z, partialTicks);
  }
  
  public void func_174967_a(long finishTimeNano)
  {
    super.func_174967_a(finishTimeNano);
  }
  
  public void func_180449_a(Entity entityIn, float partialTicks)
  {
    super.func_180449_a(entityIn, partialTicks);
  }
  




  public void func_174981_a(Tessellator tessellatorIn, BufferBuilder worldRendererIn, Entity entityIn, float partialTicks)
  {
    super.func_174981_a(tessellatorIn, worldRendererIn, entityIn, partialTicks);
  }
  

  public void func_72731_b(EntityPlayer player, RayTraceResult movingObjectPositionIn, int execute, float partialTicks)
  {
    super.func_72731_b(player, movingObjectPositionIn, execute, partialTicks);
  }
  

  public void func_184376_a(World worldIn, BlockPos pos, IBlockState oldState, IBlockState newState, int flags)
  {
    super.func_184376_a(worldIn, pos, oldState, newState, flags);
  }
  
  public void func_174959_b(BlockPos pos)
  {
    super.func_174959_b(pos);
  }
  

  public void func_147585_a(int x1, int y1, int z1, int x2, int y2, int z2) {}
  
  public void func_184377_a(@Nullable SoundEvent soundIn, BlockPos pos)
  {
    super.func_184377_a(soundIn, pos);
  }
  








  public void func_184375_a(@Nullable EntityPlayer player, SoundEvent soundIn, SoundCategory category, double x, double y, double z, float volume, float pitch)
  {
    super.func_184375_a(player, soundIn, category, x, y, z, volume, pitch);
  }
  










  public void func_190570_a(int id, boolean ignoreRange, boolean p_190570_3_, double x, double y, double z, double xSpeed, double ySpeed, double zSpeed, int... parameters)
  {
    super.func_190570_a(id, ignoreRange, p_190570_3_, x, y, z, xSpeed, ySpeed, zSpeed, parameters);
  }
  
  public void func_72703_a(Entity entityIn)
  {
    super.func_72703_a(entityIn);
  }
  
  public void func_72709_b(Entity entityIn)
  {
    super.func_72709_b(entityIn);
  }
  
  public void func_72728_f()
  {
    super.func_72728_f();
  }
  
  public void func_180440_a(int soundID, BlockPos pos, int data)
  {
    super.func_180440_a(soundID, pos, data);
  }
  
  public void func_180439_a(EntityPlayer player, int type, BlockPos blockPosIn, int data)
  {
    super.func_180439_a(player, type, blockPosIn, data);
  }
  
  public void func_180441_b(int breakerId, BlockPos pos, int progress)
  {
    super.func_180441_b(breakerId, pos, progress);
  }
  
  public boolean func_184384_n()
  {
    return super.func_184384_n();
  }
  
  public void func_174979_m()
  {
    super.func_174979_m();
  }
  

  public void func_181023_a(Collection<TileEntity> tileEntitiesToRemove, Collection<TileEntity> tileEntitiesToAdd)
  {
    super.func_181023_a(tileEntitiesToRemove, tileEntitiesToAdd);
  }
}
