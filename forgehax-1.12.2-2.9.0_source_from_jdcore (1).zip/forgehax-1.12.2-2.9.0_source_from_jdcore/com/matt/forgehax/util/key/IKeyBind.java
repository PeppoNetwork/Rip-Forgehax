package com.matt.forgehax.util.key;

import net.minecraft.client.settings.KeyBinding;




public abstract interface IKeyBind
{
  public abstract void bind(int paramInt);
  
  public abstract KeyBinding getBind();
  
  public abstract void onKeyPressed();
  
  public abstract void onKeyDown();
  
  public void unbind()
  {
    bind(0);
  }
}
