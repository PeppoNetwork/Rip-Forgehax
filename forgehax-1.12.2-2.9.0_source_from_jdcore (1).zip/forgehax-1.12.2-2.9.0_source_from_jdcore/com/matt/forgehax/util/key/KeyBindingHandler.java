package com.matt.forgehax.util.key;

import com.matt.forgehax.asm.reflection.FastReflection.Fields;
import com.matt.forgehax.asm.utils.fasttype.FastField;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.client.settings.IKeyConflictContext;

public class KeyBindingHandler implements com.matt.forgehax.Globals
{
  private static final IKeyConflictContext OVERRIDE_KEYCONFLICT_CONTEXT = new IKeyConflictContext()
  {
    public boolean isActive()
    {
      return true;
    }
    
    public boolean conflicts(IKeyConflictContext other)
    {
      return false;
    }
  };
  
  private final KeyBinding binding;
  
  private IKeyConflictContext oldConflictContext = null;
  
  private int bindingCount = 0;
  
  public KeyBindingHandler(KeyBinding bind) {
    binding = bind;
  }
  
  public KeyBinding getBinding() {
    return binding;
  }
  
  public boolean isPressed() {
    return ((Boolean)FastReflection.Fields.Binding_pressed.get(binding)).booleanValue();
  }
  
  public void setPressed(boolean pressed) {
    FastReflection.Fields.Binding_pressed.set(binding, Boolean.valueOf(pressed));
  }
  
  public int getPressTime() {
    return ((Integer)FastReflection.Fields.Binding_pressTime.get(binding)).intValue();
  }
  
  public void setPressTime(int time) {
    FastReflection.Fields.Binding_pressTime.set(binding, Integer.valueOf(time));
  }
  
  public boolean isBound() {
    return binding.getKeyConflictContext() == OVERRIDE_KEYCONFLICT_CONTEXT;
  }
  

  public void bind()
  {
    bindingCount += 1;
    if (oldConflictContext == null) {
      oldConflictContext = binding.getKeyConflictContext();
      binding.setKeyConflictContext(OVERRIDE_KEYCONFLICT_CONTEXT);
    }
  }
  
  public void attemptBind() {
    if (!isBound()) {
      bind();
    }
  }
  
  public void unbind() {
    bindingCount -= 1;
    
    if ((oldConflictContext != null) && (bindingCount <= 0)) {
      binding.setKeyConflictContext(oldConflictContext);
      oldConflictContext = null;
    }
    
    if (bindingCount < 0) {
      bindingCount = 0;
    }
  }
  
  public void attemptUnbind() {
    if (isBound()) {
      unbind();
    }
  }
}
