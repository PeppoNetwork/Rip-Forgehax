package com.matt.forgehax.util.key;

import com.google.common.collect.Maps;
import java.util.Map;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.client.settings.IKeyConflictContext;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

public class BindingHelper
{
  private static final Map<Integer, String> MOUSE_CODES = ;
  private static final IKeyConflictContext EMPTY = new IKeyConflictContext()
  {
    public boolean isActive()
    {
      return false;
    }
    
    public boolean conflicts(IKeyConflictContext other)
    {
      return false;
    }
  };
  
  static {
    MOUSE_CODES.put(Integer.valueOf(-100), "MOUSE_LEFT");
    MOUSE_CODES.put(Integer.valueOf(-99), "MOUSE_RIGHT");
    MOUSE_CODES.put(Integer.valueOf(-98), "MOUSE_MIDDLE");
  }
  
  public static String getIndexName(int code) {
    if (MOUSE_CODES.get(Integer.valueOf(code)) != null)
      return (String)MOUSE_CODES.get(Integer.valueOf(code));
    if (code < 0) {
      return Mouse.getButtonName(100 + code);
    }
    return Keyboard.getKeyName(code);
  }
  
  public static String getIndexName(KeyBinding binding)
  {
    return getIndexName(binding.func_151463_i());
  }
  
  public static IKeyConflictContext getEmptyKeyConflictContext() {
    return EMPTY;
  }
  
  public BindingHelper() {}
}
