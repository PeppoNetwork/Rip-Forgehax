package com.matt.forgehax.util.entry;

import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import com.matt.forgehax.util.serialization.ISerializableJson;
import java.io.IOException;
import java.util.Objects;
import javax.annotation.Nullable;
import net.minecraft.launchwrapper.Launch;


public class ClassEntry
  implements ISerializableJson
{
  private final String clazzName;
  private Class<?> clazz;
  
  public ClassEntry(String clazzName)
  {
    this.clazzName = clazzName;
    getClassInstance();
  }
  
  public ClassEntry(Class<?> clazz) {
    Objects.requireNonNull(clazz);
    clazzName = clazz.getCanonicalName();
    this.clazz = clazz;
  }
  
  public String getClassName() {
    return clazzName;
  }
  
  @Nullable
  public Class<?> getClassInstance() {
    if (clazz == null) {
      try {
        clazz = Class.forName(clazzName, true, Launch.classLoader);
      }
      catch (Throwable localThrowable) {}
    }
    return clazz;
  }
  
  public void serialize(JsonWriter writer) throws IOException
  {
    writer.beginObject();
    writer.endObject();
  }
  
  public void deserialize(JsonReader reader) throws IOException
  {
    reader.beginObject();
    reader.endObject();
  }
  
  public boolean equals(Object obj)
  {
    if ((obj != this) && ((!(obj instanceof ClassEntry)) || 
      (!clazzName.equals(clazzName))) && ((!(obj instanceof String)) || 
      (!clazzName.equals(obj)))) {
      if ((getClassInstance() == null) || (obj == null) || (!(obj instanceof Class))) {
        break label80;
      }
    }
    label80:
    return 
    




      getClassInstance().equals(obj);
  }
  
  public int hashCode()
  {
    return clazzName.toLowerCase().hashCode();
  }
  
  public String toString()
  {
    return clazzName;
  }
}
