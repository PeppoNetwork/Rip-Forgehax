package com.matt.forgehax.util.entry;

import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import com.matt.forgehax.util.serialization.ISerializableJson;
import java.io.IOException;
import net.minecraft.util.EnumFacing;

public class FacingEntry implements ISerializableJson
{
  private final EnumFacing facing;
  
  public FacingEntry(EnumFacing facing)
  {
    java.util.Objects.requireNonNull(facing);
    this.facing = facing;
  }
  
  public FacingEntry(String str) {
    this(EnumFacing.func_176739_a(str));
  }
  
  public EnumFacing getFacing() {
    return facing;
  }
  
  public void serialize(JsonWriter writer) throws IOException
  {
    writer.beginArray();
    writer.endArray();
  }
  
  public void deserialize(JsonReader reader) throws IOException
  {
    reader.beginArray();
    reader.endArray();
  }
  
  public boolean equals(Object obj)
  {
    return (this == obj) || (((obj instanceof FacingEntry)) && 
      (facing.equals(((FacingEntry)obj).getFacing()))) || (((obj instanceof EnumFacing)) && 
      (facing.equals(obj)));
  }
  
  public String toString()
  {
    return getFacing().func_176742_j();
  }
}
