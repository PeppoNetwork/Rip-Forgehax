package com.matt.forgehax.util.typeconverter;

import com.matt.forgehax.util.typeconverter.types.BooleanType;
import com.matt.forgehax.util.typeconverter.types.ByteType;
import com.matt.forgehax.util.typeconverter.types.CharacterType;
import com.matt.forgehax.util.typeconverter.types.DoubleType;
import com.matt.forgehax.util.typeconverter.types.FloatType;
import com.matt.forgehax.util.typeconverter.types.IntegerType;
import com.matt.forgehax.util.typeconverter.types.LongType;
import com.matt.forgehax.util.typeconverter.types.ShortType;
import com.matt.forgehax.util.typeconverter.types.StringType;




public abstract interface TypeConverters
{
  public static final TypeConverter<Boolean> BOOLEAN = new BooleanType();
  public static final TypeConverter<Byte> BYTE = new ByteType();
  public static final TypeConverter<Character> CHARACTER = new CharacterType();
  public static final TypeConverter<Double> DOUBLE = new DoubleType();
  public static final TypeConverter<Float> FLOAT = new FloatType();
  public static final TypeConverter<Integer> INTEGER = new IntegerType();
  public static final TypeConverter<Long> LONG = new LongType();
  public static final TypeConverter<Short> SHORT = new ShortType();
  public static final TypeConverter<String> STRING = new StringType();
}
