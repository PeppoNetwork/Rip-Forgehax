package com.matt.forgehax.util.typeconverter.types;

import com.matt.forgehax.util.typeconverter.TypeConverter;
import java.util.Comparator;
import javax.annotation.Nullable;

public class StringType
  extends TypeConverter<String>
{
  public StringType() {}
  
  public String label()
  {
    return "string";
  }
  
  public Class<String> type()
  {
    return String.class;
  }
  
  public String parse(String value)
  {
    return value;
  }
  
  public String toString(String value)
  {
    return value != null ? value : "null";
  }
  
  @Nullable
  public Comparator<String> comparator()
  {
    new Comparator()
    {
      public int compare(String o1, String o2) {
        return o1.compareTo(o2);
      }
    };
  }
}
