package com.matt.forgehax.util;

import com.google.common.collect.Sets;
import java.util.Objects;
import java.util.Set;

public abstract class Switch
{
  private final Set<Handle> handles = Sets.newHashSet();
  
  private final String name;
  private int level = 0;
  
  public Switch(String name) {
    this.name = name;
  }
  
  public Handle createHandle(String id) {
    Handle handle = new Handle(this, id, null);
    synchronized (handles) {
      if (handles.add(handle)) {
        return handle;
      }
      throw new Error("failed to add handle with id '" + id + "'");
    }
  }
  
  public boolean removeHandle(Handle handle)
  {
    synchronized (handles) {
      return handles.remove(handle);
    }
  }
  
  private void enable() {
    level = Math.min(handles.size(), level + 1);
  }
  
  private void disable() {
    level = Math.max(0, level - 1);
  }
  
  public boolean isEnabled() {
    return level > 0;
  }
  
  public boolean isDisabled() {
    return !isEnabled();
  }
  
  protected abstract void onEnabled();
  
  protected abstract void onDisabled();
  
  public String toString()
  {
    return name + "@" + handles.size();
  }
  

  public static class Handle
  {
    private final Switch parent;
    
    private final String id;
    private boolean enabled = false;
    
    private Handle(Switch parent, String id) {
      Objects.requireNonNull(parent, "null parent");
      Objects.requireNonNull(id, "null id");
      this.parent = parent;
      this.id = id;
    }
    
    public void enable() {
      if (!enabled) {
        enabled = true;
        parent.enable();
      }
      
      if (parent.isEnabled()) {
        parent.onEnabled();
      }
    }
    
    public void disable() {
      if (enabled) {
        enabled = false;
        parent.disable();
      }
      
      if (parent.isDisabled()) {
        parent.onDisabled();
      }
    }
    
    public int hashCode()
    {
      return id.hashCode();
    }
    
    public boolean equals(Object obj)
    {
      return (this == obj) || (((obj instanceof Handle)) && (parent.equals(parent)) && (id == id));
    }
    

    public String toString()
    {
      return id;
    }
  }
}
