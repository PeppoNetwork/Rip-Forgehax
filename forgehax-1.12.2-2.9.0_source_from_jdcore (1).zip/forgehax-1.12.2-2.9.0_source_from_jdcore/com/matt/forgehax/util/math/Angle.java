package com.matt.forgehax.util.math;

import java.util.Objects;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;




public abstract class Angle
{
  public static final Angle ZERO = degrees(0.0F, 0.0F, 0.0F);
  private final float pitch;
  
  public static Angle radians(float pitch, float yaw, float roll) { return new Radians(pitch, yaw, roll, null); }
  
  public static Angle radians(float pitch, float yaw)
  {
    return radians(pitch, yaw, 0.0F);
  }
  
  public static Angle radians(double pitch, double yaw, double roll) {
    return radians(
      (float)AngleHelper.roundAngle(pitch), 
      (float)AngleHelper.roundAngle(yaw), 
      (float)AngleHelper.roundAngle(roll));
  }
  
  public static Angle radians(double pitch, double yaw) {
    return radians(pitch, yaw, 0.0D);
  }
  
  public static Angle degrees(float pitch, float yaw, float roll) {
    return new Degrees(pitch, yaw, roll, null);
  }
  
  public static Angle degrees(float pitch, float yaw) {
    return degrees(pitch, yaw, 0.0F);
  }
  
  public static Angle degrees(double pitch, double yaw, double roll) {
    return degrees(
      (float)AngleHelper.roundAngle(pitch), 
      (float)AngleHelper.roundAngle(yaw), 
      (float)AngleHelper.roundAngle(roll));
  }
  
  public static Angle degrees(double pitch, double yaw) {
    return degrees(pitch, yaw, 0.0D);
  }
  
  public static Angle copy(Angle ang) {
    return ang.newInstance(ang.getPitch(), ang.getYaw(), ang.getRoll());
  }
  

  private final float yaw;
  private final float roll;
  private Angle(float pitch, float yaw, float roll)
  {
    this.pitch = pitch;
    this.yaw = yaw;
    this.roll = roll;
  }
  
  public float getPitch() {
    return pitch;
  }
  
  public float getYaw() {
    return yaw;
  }
  
  public float getRoll() {
    return roll;
  }
  
  public Angle setPitch(float pitch) {
    return newInstance(pitch, getYaw(), getRoll());
  }
  
  public Angle setYaw(float yaw) {
    return newInstance(getPitch(), yaw, getRoll());
  }
  
  public Angle setRoll(float roll) {
    return newInstance(getPitch(), getYaw(), roll);
  }
  
  public abstract boolean isInDegrees();
  
  public boolean isInRadians() {
    return !isInDegrees();
  }
  
  public Angle add(Angle ang) {
    return newInstance(
      getPitch() + ang.same(this).getPitch(), 
      getYaw() + ang.same(this).getYaw(), 
      getRoll() + ang.same(this).getRoll());
  }
  
  public Angle add(float p, float y, float r) {
    return add(newInstance(p, y, r));
  }
  
  public Angle add(float p, float y) {
    return add(p, y, 0.0F);
  }
  
  public Angle sub(Angle ang) {
    return add(ang.scale(-1.0F));
  }
  
  public Angle sub(float p, float y, float r) {
    return add(-p, -y, -r);
  }
  
  public Angle sub(float p, float y) {
    return sub(p, y, 0.0F);
  }
  
  public Angle scale(float factor) {
    return newInstance(getPitch() * factor, getYaw() * factor, getRoll() * factor);
  }
  

  public abstract Angle normalize();
  

  public double[] getForwardVector()
  {
    double kps = Math.sin(inRadians().getPitch());
    double kpc = Math.cos(inRadians().getPitch());
    double kys = Math.sin(inRadians().getYaw());
    double kyc = Math.cos(inRadians().getYaw());
    return new double[] { kpc * kyc, kps, kpc * kys };
  }
  



  public Vec3d getDirectionVector()
  {
    float cy = MathHelper.func_76134_b(-inDegrees().getYaw() * 0.017453292F - 3.1415927F);
    float sy = MathHelper.func_76126_a(-inDegrees().getYaw() * 0.017453292F - 3.1415927F);
    float cp = -MathHelper.func_76134_b(-inDegrees().getPitch() * 0.017453292F);
    float sp = MathHelper.func_76126_a(-inDegrees().getPitch() * 0.017453292F);
    return new Vec3d(sy * cp, sp, cy * cp);
  }
  
  public float[] toArray() {
    return new float[] { getPitch(), getYaw(), getRoll() };
  }
  
  public abstract Angle inRadians();
  
  public abstract Angle inDegrees();
  
  protected Angle same(Angle other) {
    return other.isInDegrees() ? inDegrees() : inRadians();
  }
  
  protected abstract Angle newInstance(float paramFloat1, float paramFloat2, float paramFloat3);
  
  public boolean equals(Object obj)
  {
    return (this == obj) || (((obj instanceof Angle)) && (AngleHelper.isEqual(this, (Angle)obj)));
  }
  
  public int hashCode()
  {
    Angle a = normalize().inDegrees();
    return Objects.hash(new Object[] { Float.valueOf(a.getPitch()), Float.valueOf(a.getYaw()), Float.valueOf(a.getRoll()) });
  }
  
  public String toString()
  {
    return String.format("(%.15f, %.15f, %.15f)[%s]", new Object[] {
    
      Float.valueOf(getPitch()), Float.valueOf(getYaw()), Float.valueOf(getRoll()), isInRadians() ? "rad" : "deg" });
  }
  
  static class Degrees extends Angle
  {
    private Angle.Radians radians = null;
    
    private Degrees(float pitch, float yaw, float roll) {
      super(yaw, roll, null);
    }
    
    public boolean isInDegrees()
    {
      return true;
    }
    
    public Angle normalize()
    {
      return newInstance(
        AngleHelper.normalizeInDegrees(getPitch()), 
        AngleHelper.normalizeInDegrees(getYaw()), 
        AngleHelper.normalizeInDegrees(getRoll()));
    }
    
    public Angle inRadians()
    {
      return radians == null ? 
      

        (this.radians = (Angle.Radians)radians(
        Math.toRadians(getPitch()), 
        Math.toRadians(getYaw()), 
        Math.toRadians(getRoll()))) : radians;
    }
    




    public Angle inDegrees()
    {
      return this;
    }
    
    protected Angle newInstance(float pitch, float yaw, float roll)
    {
      return new Degrees(pitch, yaw, roll);
    }
  }
  
  static class Radians extends Angle
  {
    private Angle.Degrees degrees = null;
    
    private Radians(float pitch, float yaw, float roll) {
      super(yaw, roll, null);
    }
    
    public boolean isInDegrees()
    {
      return false;
    }
    
    public Angle normalize()
    {
      return newInstance(
        AngleHelper.normalizeInRadians(getPitch()), 
        AngleHelper.normalizeInRadians(getYaw()), 
        AngleHelper.normalizeInRadians(getRoll()));
    }
    
    public Angle inRadians()
    {
      return this;
    }
    
    public Angle inDegrees()
    {
      return degrees == null ? 
      

        (this.degrees = (Angle.Degrees)degrees(
        Math.toDegrees(getPitch()), 
        Math.toDegrees(getYaw()), 
        Math.toDegrees(getRoll()))) : degrees;
    }
    




    protected Angle newInstance(float pitch, float yaw, float roll)
    {
      return new Radians(pitch, yaw, roll);
    }
  }
}
