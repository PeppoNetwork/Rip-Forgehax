package com.matt.forgehax.util.math;

import com.matt.forgehax.asm.reflection.FastReflection.Fields;
import com.matt.forgehax.asm.utils.fasttype.FastField;
import java.nio.FloatBuffer;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.util.vector.Matrix4f;
import org.lwjgl.util.vector.Vector4f;

public class VectorUtils implements com.matt.forgehax.Globals
{
  public VectorUtils() {}
  
  static Matrix4f modelMatrix = new Matrix4f();
  static Matrix4f projectionMatrix = new Matrix4f();
  
  private static void VecTransformCoordinate(Vector4f vec, Matrix4f matrix) {
    float x = vec.x;
    float y = vec.y;
    float z = vec.z;
    vec.x = (x * m00 + y * m10 + z * m20 + m30);
    vec.y = (x * m01 + y * m11 + z * m21 + m31);
    vec.z = (x * m02 + y * m12 + z * m22 + m32);
    w = (x * m03 + y * m13 + z * m23 + m33);
  }
  


  public static Plane toScreen(double x, double y, double z)
  {
    net.minecraft.entity.Entity view = MC.func_175606_aa();
    
    if (view == null) {
      return new Plane(0.0D, 0.0D, false);
    }
    
    Vec3d camPos = (Vec3d)FastReflection.Fields.ActiveRenderInfo_position.getStatic();
    Vec3d eyePos = net.minecraft.client.renderer.ActiveRenderInfo.func_178806_a(view, MC.func_184121_ak());
    
    float vecX = (float)(field_72450_a + field_72450_a - (float)x);
    float vecY = (float)(field_72448_b + field_72448_b - (float)y);
    float vecZ = (float)(field_72449_c + field_72449_c - (float)z);
    
    Vector4f pos = new Vector4f(vecX, vecY, vecZ, 1.0F);
    
    modelMatrix.load(
      ((FloatBuffer)FastReflection.Fields.ActiveRenderInfo_MODELVIEW.getStatic()).asReadOnlyBuffer());
    projectionMatrix.load(
      ((FloatBuffer)FastReflection.Fields.ActiveRenderInfo_PROJECTION.getStatic()).asReadOnlyBuffer());
    
    VecTransformCoordinate(pos, modelMatrix);
    VecTransformCoordinate(pos, projectionMatrix);
    
    if (w > 0.0F) {
      x *= -100000.0F;
      y *= -100000.0F;
    } else {
      float invert = 1.0F / w;
      x *= invert;
      y *= invert;
    }
    
    ScaledResolution res = new ScaledResolution(MC);
    float halfWidth = res.func_78326_a() / 2.0F;
    float halfHeight = res.func_78328_b() / 2.0F;
    
    x = (halfWidth + (0.5F * x * res.func_78326_a() + 0.5F));
    y = (halfHeight - (0.5F * y * res.func_78328_b() + 0.5F));
    
    boolean bVisible = true;
    
    if ((x < 0.0F) || (y < 0.0F) || (x > res.func_78326_a()) || (y > res.func_78328_b())) {
      bVisible = false;
    }
    
    return new Plane(x, y, bVisible);
  }
  
  public static Plane toScreen(Vec3d vec) {
    return toScreen(field_72450_a, field_72448_b, field_72449_c);
  }
  
  @Deprecated
  public static ScreenPos _toScreen(double x, double y, double z) {
    Plane plane = toScreen(x, y, z);
    return new ScreenPos(plane.getX(), plane.getY(), plane.isVisible());
  }
  
  @Deprecated
  public static ScreenPos _toScreen(Vec3d vec3d) {
    return _toScreen(field_72450_a, field_72448_b, field_72449_c);
  }
  


  @Deprecated
  public static Object vectorAngle(Vec3d vec3d)
  {
    return null;
  }
  
  public static Vec3d multiplyBy(Vec3d vec1, Vec3d vec2) {
    return new Vec3d(field_72450_a * field_72450_a, field_72448_b * field_72448_b, field_72449_c * field_72449_c);
  }
  
  public static Vec3d copy(Vec3d toCopy) {
    return new Vec3d(field_72450_a, field_72448_b, field_72449_c);
  }
  
  public static double getCrosshairDistance(Vec3d eyes, Vec3d directionVec, Vec3d pos) {
    return pos.func_178788_d(eyes).func_72432_b().func_178788_d(directionVec).func_189985_c();
  }
  
  @Deprecated
  public static class ScreenPos
  {
    public final int x;
    public final int y;
    public final boolean isVisible;
    public final double xD;
    public final double yD;
    
    public ScreenPos(double x, double y, boolean isVisible)
    {
      this.x = ((int)x);
      this.y = ((int)y);
      xD = x;
      yD = y;
      this.isVisible = isVisible;
    }
  }
}
