package com.matt.forgehax.util.math;

import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;


public class AngleHelper
{
  public static final long DEFAULT_N = 1000000000L;
  public static final double DEFAULT_EPSILON = 1.0E-9D;
  public static final double TWO_PI = 6.283185307179586D;
  public static final double HALF_PI = 1.5707963267948966D;
  public static final double QUARTER_PI = 0.7853981633974483D;
  
  public AngleHelper() {}
  
  public static double roundAngle(double a, long n)
  {
    return Math.round(a * n) / n;
  }
  
  public static double roundAngle(double a) {
    return roundAngle(a, 1000000000L);
  }
  
  public static boolean isAngleEqual(double a1, double a2, double epsilon) {
    return (Double.compare(a1, a2) == 0) || (Math.abs(a1 - a2) < epsilon);
  }
  
  public static boolean isAngleEqual(double a1, double a2) {
    return isAngleEqual(a1, a2, 1.0E-4D);
  }
  
  public static boolean isEqual(Angle ang1, Angle ang2) {
    Angle a1 = ang1.normalize();
    Angle a2 = ang2.same(a1).normalize();
    return (isAngleEqual(a1.getPitch(), a2.getPitch())) && 
      (isAngleEqual(a1.getYaw(), a2.getYaw())) && 
      (isAngleEqual(a1.getRoll(), a2.getRoll()));
  }
  
  public static double normalizeInRadians(double ang) {
    while (ang > 3.141592653589793D) {
      ang -= 6.283185307179586D;
    }
    while (ang < -3.141592653589793D) {
      ang += 6.283185307179586D;
    }
    return ang;
  }
  
  public static float normalizeInRadians(float ang) {
    while (ang > 3.141592653589793D) {
      ang = (float)(ang - 6.283185307179586D);
    }
    while (ang < -3.141592653589793D) {
      ang = (float)(ang + 6.283185307179586D);
    }
    return ang;
  }
  
  public static double normalizeInDegrees(double ang) {
    return MathHelper.func_76138_g(ang);
  }
  

  public static float normalizeInDegrees(float ang) { return MathHelper.func_76142_g(ang); }
  
  public static Angle getAngleFacingInRadians(Vec3d vector) { double pitch;
    double yaw;
    double pitch;
    if ((field_72450_a == 0.0D) && (field_72449_c == 0.0D)) {
      double yaw = 0.0D;
      pitch = 1.5707963267948966D;
    } else {
      yaw = Math.atan2(field_72449_c, field_72450_a) - 1.5707963267948966D;
      double mag = Math.sqrt(field_72450_a * field_72450_a + field_72449_c * field_72449_c);
      pitch = -Math.atan2(field_72448_b, mag);
    }
    return Angle.radians((float)pitch, (float)yaw);
  }
  
  public static Angle getAngleFacingInDegrees(Vec3d vector) {
    return getAngleFacingInRadians(vector).inDegrees();
  }
}
