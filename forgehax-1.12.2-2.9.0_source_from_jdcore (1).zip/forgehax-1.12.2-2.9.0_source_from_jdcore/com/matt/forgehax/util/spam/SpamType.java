package com.matt.forgehax.util.spam;

public enum SpamType
{
  RANDOM,  SEQUENTIAL;
  
  private SpamType() {}
}
