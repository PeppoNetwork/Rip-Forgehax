package com.matt.forgehax.util.spam;

import com.google.common.collect.Lists;
import com.google.gson.stream.JsonReader;
import com.google.gson.stream.JsonWriter;
import com.matt.forgehax.util.serialization.ISerializableJson;
import java.io.IOException;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import joptsimple.internal.Strings;









public class SpamEntry
  implements ISerializableJson
{
  private final String name;
  private final List<String> messages = Lists.newCopyOnWriteArrayList();
  
  private boolean enabled = true;
  



  private String keyword = "";
  



  private SpamType type = SpamType.RANDOM;
  



  private SpamTrigger trigger = SpamTrigger.SPAM;
  



  private long delay = 0L;
  
  public SpamEntry(String name) {
    this.name = name;
  }
  
  public void add(String msg) {
    if ((!Strings.isNullOrEmpty(msg)) && (!messages.contains(msg))) {
      messages.add(msg);
    }
  }
  
  public void remove(String msg) {
    messages.remove(msg);
  }
  
  private int nextIndex = 0;
  
  public String next() {
    if (!messages.isEmpty()) {
      switch (1.$SwitchMap$com$matt$forgehax$util$spam$SpamType[type.ordinal()]) {
      case 1: 
        return (String)messages.get(ThreadLocalRandom.current().nextInt(messages.size()));
      case 2: 
        return (String)messages.get(nextIndex++ % messages.size());
      }
    }
    return "";
  }
  
  public void reset() {
    nextIndex = 0;
  }
  
  public boolean isEnabled() {
    return enabled;
  }
  
  public String getName() {
    return name;
  }
  
  public String getKeyword() {
    return keyword;
  }
  
  public SpamType getType() {
    return type;
  }
  
  public SpamTrigger getTrigger() {
    return trigger;
  }
  
  public List<String> getMessages() {
    return Collections.unmodifiableList(messages);
  }
  
  public long getDelay() {
    return delay;
  }
  
  public void setEnabled(boolean enabled) {
    this.enabled = enabled;
  }
  
  public void setKeyword(String keyword) {
    this.keyword = keyword;
  }
  
  public void setType(SpamType type) {
    if (type != null) {
      this.type = type;
    }
  }
  
  public void setType(String type) {
    setType(SpamType.valueOf(type.toUpperCase()));
  }
  
  public void setTrigger(SpamTrigger trigger) {
    if (trigger != null) {
      this.trigger = trigger;
    }
  }
  
  public void setTrigger(String trigger) {
    setTrigger(SpamTrigger.valueOf(trigger.toUpperCase()));
  }
  
  public void setDelay(long delay) {
    this.delay = delay;
  }
  
  public boolean isEmpty() {
    return messages.isEmpty();
  }
  
  public void serialize(JsonWriter writer) throws IOException
  {
    writer.beginObject();
    
    writer.name("enabled");
    writer.value(enabled);
    
    writer.name("keyword");
    writer.value(keyword);
    
    writer.name("type");
    writer.value(type.name());
    
    writer.name("trigger");
    writer.value(trigger.name());
    
    writer.name("delay");
    writer.value(getDelay());
    
    writer.name("messages");
    writer.beginArray();
    for (String msg : messages) {
      writer.value(msg);
    }
    writer.endArray();
    
    writer.endObject();
  }
  
  public void deserialize(JsonReader reader) throws IOException
  {
    reader.beginObject();
    
    while (reader.hasNext()) {
      switch (reader.nextName()) {
      case "enabled": 
        setEnabled(reader.nextBoolean());
        break;
      case "keyword": 
        setKeyword(reader.nextString());
        break;
      case "type": 
        setType(reader.nextString());
        break;
      case "trigger": 
        setTrigger(reader.nextString());
        break;
      case "delay": 
        setDelay(reader.nextLong());
        break;
      case "messages": 
        reader.beginArray();
        while (reader.hasNext()) {
          add(reader.nextString());
        }
        reader.endArray();
      }
      
    }
    


    reader.endObject();
  }
  
  public boolean equals(Object obj)
  {
    if ((!(obj instanceof SpamEntry)) || 
      (String.CASE_INSENSITIVE_ORDER.compare(name, name) != 0)) if (!(obj instanceof String)) {
        break label59;
      }
    label59:
    return 
      String.CASE_INSENSITIVE_ORDER
      
      .compare(name, (String)obj) == 0;
  }
  
  public int hashCode()
  {
    return name.toLowerCase().hashCode();
  }
  
  public String toString()
  {
    return name;
  }
}
