package com.matt.forgehax.util.spam;

public enum SpamTrigger
{
  SPAM,  REPLY,  REPLY_WITH_INPUT,  PLAYER_CONNECT,  PLAYER_DISCONNECT;
  
  private SpamTrigger() {}
}
