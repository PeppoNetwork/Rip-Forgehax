package com.matt.forgehax.util.spam;

import java.util.regex.Matcher;






public enum SpamTokens
{
  PLAYER_NAME("PLAYER_NAME"), 
  



  NAME_HISTORY("NAME_HISTORY"), 
  



  SENDER_NAME("SENDER_NAME"), 
  



  MESSAGE("MESSAGE");
  

  public static SpamTokens[] ALL = { PLAYER_NAME, NAME_HISTORY, SENDER_NAME, MESSAGE };
  
  public static SpamTokens[] PLAYERNAME_NAMEHISTORY = { PLAYER_NAME, NAME_HISTORY };
  public static SpamTokens[] PLAYERNAME_SENDERNAME = { PLAYER_NAME, SENDER_NAME };
  final String token;
  
  private SpamTokens(String token)
  {
    this.token = ("\\{" + token + "\\}");
  }
  
  public String fill(String str, String with) {
    return str.replaceAll(token, Matcher.quoteReplacement(with));
  }
  
  public static String fillAll(String str, SpamTokens[] tokens, String... replacements) {
    if (replacements.length != tokens.length) {
      throw new IllegalArgumentException("replacements length != tokens length");
    }
    for (int i = 0; i < replacements.length; i++) {
      str = tokens[i].fill(str, replacements[i]);
    }
    return str;
  }
}
