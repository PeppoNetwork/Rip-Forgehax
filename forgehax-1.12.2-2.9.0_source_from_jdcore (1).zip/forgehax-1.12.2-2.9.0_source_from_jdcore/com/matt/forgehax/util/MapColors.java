package com.matt.forgehax.util;

import com.matt.forgehax.util.color.Color;
import net.minecraft.block.material.MapColor;










public class MapColors
{
  private static final int[] COLOR_LIST;
  private static final int[] BASE_COLORS;
  
  static
  {
    int baseColorsLength = 0;
    for (int i = MapColor.field_76281_a.length - 1; i >= 0; i--) {
      if (MapColor.field_76281_a[i] != null) {
        baseColorsLength = i + 1;
        break;
      }
    }
    BASE_COLORS = new int[baseColorsLength];
    COLOR_LIST = new int[baseColorsLength * 4];
    
    for (int i = 0; i < BASE_COLORS.length; i++)
    {
      BASE_COLORS[i] = field_76281_afield_76291_p;
    }
    
    for (int i = 0; 
        i < BASE_COLORS.length; 
        i++) {
      int[] rgb = Color.of(BASE_COLORS[i]).toIntegerArray();
      COLOR_LIST[(i * 4)] = Color.of(rgb[0] * 180 / 255, rgb[1] * 180 / 255, rgb[2] * 180 / 255, 0)
      



        .toBuffer();
      COLOR_LIST[(i * 4 + 1)] = Color.of(rgb[0] * 220 / 255, rgb[1] * 220 / 255, rgb[2] * 220 / 255, 0)
      



        .toBuffer();
      COLOR_LIST[(i * 4 + 2)] = BASE_COLORS[i];
      COLOR_LIST[(i * 4 + 3)] = Color.of(rgb[0] * 135 / 255, rgb[1] * 135 / 255, rgb[2] * 135 / 255, 0)
      



        .toBuffer();
    }
  }
  
  public static int getColor(int index) {
    return COLOR_LIST[index];
  }
  
  public static int colorListLength() {
    return COLOR_LIST.length;
  }
  
  public static int getBaseColor(int index) {
    return BASE_COLORS[index];
  }
  
  public static int baseColorListLength() {
    return BASE_COLORS.length;
  }
  
  public MapColors() {}
}
