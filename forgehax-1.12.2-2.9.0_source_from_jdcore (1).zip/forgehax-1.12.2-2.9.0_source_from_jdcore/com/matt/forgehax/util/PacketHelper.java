package com.matt.forgehax.util;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.matt.forgehax.Helper;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.Packet;





public class PacketHelper
{
  private static final LoadingCache<Packet, Boolean> CACHE = CacheBuilder.newBuilder()
    .expireAfterWrite(15L, TimeUnit.SECONDS)
    .build(new CacheLoader()
  {
    public Boolean load(Packet key) throws Exception
    {
      return Boolean.valueOf(false);
    }
  });
  

  public PacketHelper() {}
  

  public static void ignore(Packet packet)
  {
    CACHE.put(packet, Boolean.valueOf(true));
  }
  
  public static void ignoreAndSend(Packet packet) {
    ignore(packet);
    Helper.getNetworkManager().func_179290_a(packet);
  }
  
  public static boolean isIgnored(Packet packet) {
    try {
      return ((Boolean)CACHE.get(packet)).booleanValue();
    } catch (ExecutionException e) {}
    return false;
  }
  
  public static void remove(Packet packet)
  {
    CACHE.invalidate(packet);
  }
}
