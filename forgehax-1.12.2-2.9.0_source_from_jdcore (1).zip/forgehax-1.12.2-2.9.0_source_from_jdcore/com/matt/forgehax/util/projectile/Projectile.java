package com.matt.forgehax.util.projectile;

import com.google.common.collect.Lists;
import com.matt.forgehax.Helper;
import com.matt.forgehax.util.entity.EntityUtils;
import com.matt.forgehax.util.math.Angle;
import com.matt.forgehax.util.math.AngleHelper;
import java.util.List;
import java.util.Objects;
import javax.annotation.Nullable;
import net.minecraft.block.material.Material;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.entity.Entity;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.RayTraceResult;
import net.minecraft.util.math.Vec3d;



public enum Projectile
  implements IProjectile
{
  NULL, 
  







































  BOW, 
  








































  SNOWBALL, 
  




  EGG, 
  




  FISHING_ROD, 
  














  ENDER_PEARL;
  

  private static final int MAX_ITERATIONS = 1000;
  
  private static final double SHOOT_POS_OFFSET = 0.10000000149011612D;
  

  private Projectile() {}
  
  public boolean isNull()
  {
    return getItem() == null;
  }
  
  @Nullable
  public SimulationResult getSimulatedTrajectory(Vec3d shootPos, Angle angle, double force, int factor) throws IllegalArgumentException
  {
    if (isNull()) {
      return null;
    }
    
    Entity hitEntity = null;
    
    double[] forward = angle.getForwardVector();
    Vec3d v = new Vec3d(forward[0], forward[1], forward[2]).func_72432_b().func_186678_a(force);
    
    double velocityX = field_72450_a;
    double velocityY = field_72448_b;
    double velocityZ = field_72449_c;
    
    double distanceTraveledSq = 0.0D;
    


    List<Vec3d> points = Lists.newArrayList();
    points.add(shootPos);
    
    Vec3d next = new Vec3d(field_72450_a, field_72448_b, field_72449_c);
    Vec3d previous = next;
    
    int index = points.size(); for (int n = 0; index < 1000; index++) {
      next = next.func_72441_c(velocityX, velocityY, velocityZ);
      
      AxisAlignedBB bb = getBoundBox(next);
      RayTraceResult trace = rayTraceCheckEntityCollisions(previous, next, bb, velocityX, velocityY, velocityZ);
      
      if (trace != null) {
        hitEntity = field_72308_g;
        distanceTraveledSq += previous.func_72436_e(field_72307_f);
        
        points.add(field_72307_f);
        break;
      }
      
      if (n == factor) {
        points.add(next);
        n = 0;
      } else {
        n++;
      }
      
      distanceTraveledSq += previous.func_72436_e(next);
      

      if (field_72448_b <= 0.0D) {
        break;
      }
      
      double d = Helper.getWorld().func_72875_a(bb, Material.field_151586_h) ? getWaterDrag() : getDrag();
      
      velocityX *= d;
      velocityY = velocityY * d - getGravity();
      velocityZ *= d;
      
      previous = next;
    }
    return new SimulationResult(points, distanceTraveledSq, hitEntity);
  }
  
  @Nullable
  public SimulationResult getSimulatedTrajectoryFromEntity(Entity shooter, Angle angle, double force, int factor)
  {
    angle = getAngleFacing(angle);
    return getSimulatedTrajectory(getShootPosFacing(shooter, angle), angle, force, factor);
  }
  
  @Nullable
  public Angle getEstimatedImpactAngleInRadians(Vec3d shooterPos, Vec3d targetPos, double force) {
    if (isNull()) {
      return null;
    }
    Vec3d start = shooterPos.func_178788_d(targetPos);
    

    double yaw = AngleHelper.getAngleFacingInRadians(targetPos.func_178788_d(shooterPos)).getYaw();
    




    force *= getDrag();
    

    double x = Math.sqrt(field_72450_a * field_72450_a + field_72449_c * field_72449_c);
    double g = getGravity();
    
    double root = Math.pow(force, 4.0D) - g * (g * Math.pow(x, 2.0D) + 2.0D * field_72448_b * Math.pow(force, 2.0D));
    

    if (root < 0.0D) {
      return null;
    }
    


    double A = (Math.pow(force, 2.0D) + Math.sqrt(root)) / (g * x);
    double B = (Math.pow(force, 2.0D) - Math.sqrt(root)) / (g * x);
    

    double pitch = Math.atan(Math.max(A, B));
    
    return Angle.radians((float)pitch, (float)yaw).normalize();
  }
  
  @Nullable
  public Angle getEstimatedImpactAngleInRadiansFromEntity(Entity entity, Vec3d targetPos, double force)
  {
    return getEstimatedImpactAngleInRadians(getEntityShootPos(entity), targetPos, force);
  }
  
  public boolean canHitEntity(Vec3d shooterPos, Entity targetEntity) {
    if (isNull()) {
      return false;
    }
    
    Vec3d targetPos = EntityUtils.getOBBCenter(targetEntity);
    
    double min = getMinForce();
    double max = getMaxForce();
    



    for (double force = max; force >= min; force -= min) {
      Angle shootAngle = getEstimatedImpactAngleInRadians(shooterPos, targetPos, force);
      if (shootAngle != null)
      {


        SimulationResult result = getSimulatedTrajectory(shooterPos, shootAngle, force, -1);
        if (result == null) {
          return false;
        }
        

        if (Objects.equals(targetEntity, result.getHitEntity()))
          return true;
      }
    }
    return false;
  }
  

  private AxisAlignedBB getBoundBox(Vec3d pos)
  {
    double mp = getProjectileSize() / 2.0D;
    return new AxisAlignedBB(field_72450_a - mp, field_72448_b - mp, field_72449_c - mp, field_72450_a + mp, field_72448_b + mp, field_72449_c + mp);
  }
  



  private static RayTraceResult rayTraceCheckEntityCollisions(Vec3d start, Vec3d end, AxisAlignedBB bb, double motionX, double motionY, double motionZ)
  {
    RayTraceResult trace = Helper.getWorld().func_147447_a(start, end, false, true, false);
    
    if (trace != null) {
      end = field_72307_f;
    }
    



    List<Entity> entities = Helper.getWorld().func_72839_b(
      Helper.getLocalPlayer(), bb.func_72321_a(motionX, motionY, motionZ).func_186662_g(1.0D));
    
    double best = 0.0D;
    Vec3d hitPos = Vec3d.field_186680_a;
    Entity hitEntity = null;
    
    for (Entity entity : entities) {
      if (entity.func_70067_L()) {
        float size = entity.func_70111_Y();
        AxisAlignedBB bbe = entity.func_174813_aQ().func_186662_g(size);
        RayTraceResult tr = bbe.func_72327_a(start, end);
        if (tr != null) {
          double distance = start.func_72436_e(field_72307_f);
          if ((distance < best) || (hitEntity == null)) {
            best = distance;
            hitPos = field_72307_f;
            hitEntity = entity;
          }
        }
      }
    }
    
    if (hitEntity != null) {
      trace = new RayTraceResult(hitEntity, hitPos);
    }
    
    return trace;
  }
  
  private static Vec3d getEntityShootPos(Entity entity) {
    return EntityUtils.getEyePos(entity).func_178786_a(0.0D, 0.10000000149011612D, 0.0D);
  }
  
  private static Vec3d getShootPosFacing(Entity entity, Angle angleFacing) {
    return 
      getEntityShootPos(entity).func_178786_a(
      Math.cos(angleFacing.inRadians().getYaw() - 1.5707963267948966D) * 0.16D, 0.0D, 
      
      Math.sin(angleFacing.inRadians().getYaw() - 1.5707963267948966D) * 0.16D);
  }
  
  private static Angle getAngleFacing(Angle angle) {
    return Angle.radians(
      -angle.inRadians().getPitch(), (float)(angle.inRadians().getYaw() + 1.5707963267948966D));
  }
  
  public static Projectile getProjectileByItem(Item item) {
    if (item != null) {
      for (Projectile p : values()) {
        if ((p.getItem() != null) && (p.getItem().equals(item))) {
          return p;
        }
      }
    }
    return NULL;
  }
  
  public static Projectile getProjectileByItemStack(ItemStack item) {
    return item == null ? NULL : getProjectileByItem(item.func_77973_b());
  }
}
