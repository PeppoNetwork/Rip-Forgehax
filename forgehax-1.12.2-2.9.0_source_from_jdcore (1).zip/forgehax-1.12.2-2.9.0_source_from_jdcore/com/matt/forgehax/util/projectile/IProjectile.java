package com.matt.forgehax.util.projectile;

import net.minecraft.item.Item;



public abstract interface IProjectile
{
  public abstract Item getItem();
  
  public double getForce(int charge)
  {
    return 1.5D;
  }
  
  public double getMaxForce() {
    return 1.5D;
  }
  
  public double getMinForce() {
    return 1.5D;
  }
  
  public double getGravity() {
    return 0.03D;
  }
  
  public double getDrag() {
    return 0.99D;
  }
  
  public double getWaterDrag() {
    return 0.8D;
  }
  
  public double getProjectileSize() {
    return 0.25D;
  }
}
