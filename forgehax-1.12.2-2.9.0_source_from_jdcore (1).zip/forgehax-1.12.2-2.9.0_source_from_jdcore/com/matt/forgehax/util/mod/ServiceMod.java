package com.matt.forgehax.util.mod;

import com.matt.forgehax.util.command.callbacks.CallbackData;


public class ServiceMod
  extends BaseMod
{
  public ServiceMod(String name, String desc)
  {
    super(Category.SERVICE, name, desc);
  }
  
  public ServiceMod(String name) {
    super(Category.SERVICE, name);
  }
  
  public boolean isHidden()
  {
    return true;
  }
  
  public boolean isEnabled()
  {
    return true;
  }
  
  protected void onLoad() {}
  
  protected void onUnload() {}
  
  protected void onEnabled() {}
  
  protected void onDisabled() {}
  
  protected void onBindPressed(CallbackData cb) {}
  
  protected void onBindKeyDown(CallbackData cb) {}
}
