package com.matt.forgehax.util.mod;

import com.matt.forgehax.util.command.Setting;
import com.matt.forgehax.util.command.SettingBuilder;
import com.matt.forgehax.util.command.SettingEnumBuilder;
import com.matt.forgehax.util.math.AlignHelper;
import com.matt.forgehax.util.math.AlignHelper.Align;
import net.minecraft.client.gui.ScaledResolution;

public abstract class HudMod extends ToggleMod
{
  protected static ScaledResolution scaledRes = new ScaledResolution(MC);
  protected final Setting<AlignHelper.Align> alignment;
  protected final Setting<Integer> offsetX;
  
  protected abstract AlignHelper.Align getDefaultAlignment();
  
  protected abstract int getDefaultOffsetX();
  
  protected abstract int getDefaultOffsetY();
  
  protected abstract double getDefaultScale();
  
  public HudMod(Category category, String modName, boolean defaultEnabled, String description) {
    super(category, modName, defaultEnabled, description);
    







    alignment = ((SettingEnumBuilder)((SettingEnumBuilder)getCommandStub().builders().newSettingEnumBuilder().name("alignment")).description("align to corner")).defaultTo(getDefaultAlignment()).build();
    







    offsetX = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("x-offset")).description("shift on X-axis")).defaultTo(Integer.valueOf(getDefaultOffsetX())).build();
    







    offsetY = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("y-offset")).description("shift on Y-axis")).defaultTo(Integer.valueOf(getDefaultOffsetY())).build();
    







    scale = ((SettingBuilder)((SettingBuilder)getCommandStub().builders().newSettingBuilder().name("scale")).description("size scaling")).defaultTo(Double.valueOf(getDefaultScale())).build();
  }
  
  protected final Setting<Integer> offsetY;
  protected final Setting<Double> scale;
  public final int getPosX(int extraOffset) { int align = ((AlignHelper.Align)alignment.get()).ordinal();
    int dirSignX = AlignHelper.getFlowDirX2(align);
    return (extraOffset + ((Integer)offsetX.get()).intValue()) * dirSignX + AlignHelper.alignH(scaledRes.func_78326_a(), align);
  }
  
  public final int getPosY(int extraOffset) {
    int align = ((AlignHelper.Align)alignment.get()).ordinal();
    int dirSignY = AlignHelper.getFlowDirY2(align);
    return (extraOffset + ((Integer)offsetY.get()).intValue()) * dirSignY + AlignHelper.alignV(scaledRes.func_78328_b(), align);
  }
  
  @net.minecraftforge.fml.common.eventhandler.SubscribeEvent
  public void onScreenUpdated(net.minecraftforge.client.event.GuiScreenEvent.InitGuiEvent.Post ev) {
    scaledRes = new ScaledResolution(MC);
  }
}
