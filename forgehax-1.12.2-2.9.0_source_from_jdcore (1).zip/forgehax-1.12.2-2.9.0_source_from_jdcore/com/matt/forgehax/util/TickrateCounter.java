package com.matt.forgehax.util;


public class TickrateCounter
{
  public TickrateCounter() {}
  
  private static double tr = 0.0D;
  
  public static double getTickrate() {
    return 0.0D;
  }
  
  public static void setTickrate(double tickrate) {
    tr = tickrate;
  }
}
