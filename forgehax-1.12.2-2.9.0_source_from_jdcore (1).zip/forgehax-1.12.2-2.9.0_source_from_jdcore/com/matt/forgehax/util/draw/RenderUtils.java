package com.matt.forgehax.util.draw;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

public class RenderUtils implements com.matt.forgehax.Globals
{
  public RenderUtils() {}
  
  public static Vec3d getRenderPos()
  {
    return new Vec3d(MCfield_71439_g.field_70142_S + (MCfield_71439_g.field_70165_t - MCfield_71439_g.field_70142_S) * MC
    
      .func_184121_ak(), MCfield_71439_g.field_70137_T + (MCfield_71439_g.field_70163_u - MCfield_71439_g.field_70137_T) * MC
      
      .func_184121_ak(), MCfield_71439_g.field_70136_U + (MCfield_71439_g.field_70161_v - MCfield_71439_g.field_70136_U) * MC
      
      .func_184121_ak());
  }
  
  public static void drawLine(Vec3d startPos, Vec3d endPos, int color, boolean smooth, float width)
  {
    Tessellator tessellator = Tessellator.func_178181_a();
    BufferBuilder BufferBuilder = tessellator.func_178180_c();
    
    Vec3d endVecPos = endPos.func_178788_d(startPos);
    
    float r = (color >> 16 & 0xFF) / 255.0F;
    float g = (color >> 8 & 0xFF) / 255.0F;
    float b = (color & 0xFF) / 255.0F;
    float a = (color >> 24 & 0xFF) / 255.0F;
    
    if (smooth) {
      org.lwjgl.opengl.GL11.glEnable(2848);
    }
    
    org.lwjgl.opengl.GL11.glLineWidth(width);
    
    GlStateManager.func_179094_E();
    GlStateManager.func_179137_b(field_72450_a, field_72448_b, field_72449_c);
    GlStateManager.func_179090_x();
    GlStateManager.func_179147_l();
    GlStateManager.func_179118_c();
    GlStateManager.func_179120_a(770, 771, 1, 0);
    GlStateManager.func_179103_j(7425);
    
    BufferBuilder.func_181668_a(1, DefaultVertexFormats.field_181706_f);
    BufferBuilder.func_181662_b(0.0D, 0.0D, 0.0D).func_181666_a(r, g, b, a).func_181675_d();
    BufferBuilder.func_181662_b(field_72450_a, field_72448_b, field_72449_c).func_181666_a(r, g, b, a).func_181675_d();
    tessellator.func_78381_a();
    
    if (smooth) {
      org.lwjgl.opengl.GL11.glDisable(2848);
    }
    
    GlStateManager.func_179103_j(7424);
    GlStateManager.func_179084_k();
    GlStateManager.func_179141_d();
    GlStateManager.func_179098_w();
    GlStateManager.func_179126_j();
    GlStateManager.func_179089_o();
    GlStateManager.func_179121_F();
  }
  

  public static void drawBox(Vec3d startPos, Vec3d endPos, int color, float width, boolean ignoreZ)
  {
    Tessellator tessellator = Tessellator.func_178181_a();
    BufferBuilder buffer = tessellator.func_178180_c();
    
    Vec3d renderPos = com.matt.forgehax.util.entity.EntityUtils.getInterpolatedPos(com.matt.forgehax.Helper.getLocalPlayer(), MC.func_184121_ak());
    
    Vec3d min = startPos.func_178788_d(renderPos);
    Vec3d max = endPos.func_178788_d(renderPos);
    
    double minX = field_72450_a;double minY = field_72448_b;double minZ = field_72449_c;
    double maxX = field_72450_a;double maxY = field_72448_b;double maxZ = field_72449_c;
    
    float r = (color >> 16 & 0xFF) / 255.0F;
    float g = (color >> 8 & 0xFF) / 255.0F;
    float b = (color & 0xFF) / 255.0F;
    float a = (color >> 24 & 0xFF) / 255.0F;
    
    GlStateManager.func_179094_E();
    GlStateManager.func_179090_x();
    GlStateManager.func_179147_l();
    GlStateManager.func_179118_c();
    GlStateManager.func_179120_a(770, 771, 1, 0);
    GlStateManager.func_179103_j(7425);
    GlStateManager.func_187441_d(width);
    
    if (ignoreZ) {
      GlStateManager.func_179097_i();
    }
    
    GlStateManager.func_179131_c(r, g, b, a);
    


    buffer.func_181668_a(3, DefaultVertexFormats.field_181705_e);
    buffer.func_181662_b(minX, minY, minZ).func_181675_d();
    buffer.func_181662_b(maxX, minY, minZ).func_181675_d();
    buffer.func_181662_b(maxX, minY, maxZ).func_181675_d();
    buffer.func_181662_b(minX, minY, maxZ).func_181675_d();
    buffer.func_181662_b(minX, minY, minZ).func_181675_d();
    tessellator.func_78381_a();
    buffer.func_181668_a(3, DefaultVertexFormats.field_181705_e);
    buffer.func_181662_b(minX, maxY, minZ).func_181675_d();
    buffer.func_181662_b(maxX, maxY, minZ).func_181675_d();
    buffer.func_181662_b(maxX, maxY, maxZ).func_181675_d();
    buffer.func_181662_b(minX, maxY, maxZ).func_181675_d();
    buffer.func_181662_b(minX, maxY, minZ).func_181675_d();
    tessellator.func_78381_a();
    buffer.func_181668_a(1, DefaultVertexFormats.field_181705_e);
    buffer.func_181662_b(minX, minY, minZ).func_181675_d();
    buffer.func_181662_b(minX, maxY, minZ).func_181675_d();
    buffer.func_181662_b(maxX, minY, minZ).func_181675_d();
    buffer.func_181662_b(maxX, maxY, minZ).func_181675_d();
    buffer.func_181662_b(maxX, minY, maxZ).func_181675_d();
    buffer.func_181662_b(maxX, maxY, maxZ).func_181675_d();
    buffer.func_181662_b(minX, minY, maxZ).func_181675_d();
    buffer.func_181662_b(minX, maxY, maxZ).func_181675_d();
    tessellator.func_78381_a();
    
    GlStateManager.func_179103_j(7424);
    GlStateManager.func_179084_k();
    GlStateManager.func_179141_d();
    GlStateManager.func_179098_w();
    GlStateManager.func_179126_j();
    GlStateManager.func_179089_o();
    GlStateManager.func_179121_F();
  }
  
  public static void drawBox(BlockPos startPos, BlockPos endPos, int color, float width, boolean ignoreZ)
  {
    drawBox(new Vec3d(startPos
      .func_177958_n(), startPos.func_177956_o(), startPos.func_177952_p()), new Vec3d(endPos
      .func_177958_n(), endPos.func_177956_o(), endPos.func_177952_p()), color, width, ignoreZ);
  }
}
