package com.matt.forgehax.util.draw.font;

import java.awt.Font;




public abstract interface Fonts
{
  public static final MinecraftFontRenderer ARIAL = new MinecraftFontRenderer(new Font("Arial", 0, 18), true, true);
  
  public static final MinecraftFontRenderer CAMBRIA = new MinecraftFontRenderer(new Font("Cambria", 0, 18), true, true);
  
  public static final MinecraftFontRenderer GEORGIA = new MinecraftFontRenderer(new Font("Georgia", 0, 18), true, true);
}
