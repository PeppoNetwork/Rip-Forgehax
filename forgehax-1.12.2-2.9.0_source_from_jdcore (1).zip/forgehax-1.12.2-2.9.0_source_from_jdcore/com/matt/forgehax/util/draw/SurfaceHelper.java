package com.matt.forgehax.util.draw;

import com.matt.forgehax.Globals;
import com.matt.forgehax.Helper;
import com.matt.forgehax.util.draw.font.MinecraftFontRenderer;
import com.matt.forgehax.util.math.AlignHelper;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.GlStateManager.DestFactor;
import net.minecraft.client.renderer.GlStateManager.SourceFactor;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.RenderItem;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.block.model.IBakedModel;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms.TransformType;
import net.minecraft.client.renderer.texture.ITextureObject;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.CooldownTracker;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.client.ForgeHooksClient;
import org.lwjgl.opengl.GL11;

public class SurfaceHelper implements Globals
{
  public SurfaceHelper() {}
  
  public static void drawString(@Nullable MinecraftFontRenderer fontRenderer, String text, double x, double y, int color, boolean shadow)
  {
    if (fontRenderer == null) {
      MCfield_71466_p.func_175065_a(text, (float)Math.round(x), (float)Math.round(y), color, shadow);
    } else {
      fontRenderer.drawString(text, x, y, color, shadow);
    }
  }
  
  public static double getStringWidth(@Nullable MinecraftFontRenderer fontRenderer, String text) {
    if (fontRenderer == null) {
      return MCfield_71466_p.func_78256_a(text);
    }
    return fontRenderer.getStringWidth(text);
  }
  
  public static double getStringHeight(@Nullable MinecraftFontRenderer fontRenderer)
  {
    if (fontRenderer == null) {
      return MCfield_71466_p.field_78288_b;
    }
    return fontRenderer.getHeight();
  }
  
  public static void drawRect(int x, int y, int w, int h, int color)
  {
    GL11.glLineWidth(1.0F);
    Gui.func_73734_a(x, y, x + w, y + h, color);
  }
  
  public static void drawOutlinedRect(int x, int y, int w, int h, int color) {
    drawOutlinedRect(x, y, w, h, color, 1.0F);
  }
  
  public static void drawOutlinedRectShaded(int x, int y, int w, int h, int colorOutline, int shade, float width)
  {
    int shaded = 0xFFFFFF & colorOutline | (shade & 0xFF) << 24;
    
    drawRect(x, y, w, h, shaded);
    drawOutlinedRect(x, y, w, h, colorOutline, width);
  }
  
  public static void drawOutlinedRect(int x, int y, int w, int h, int color, float width) {
    float r = (color >> 16 & 0xFF) / 255.0F;
    float g = (color >> 8 & 0xFF) / 255.0F;
    float b = (color & 0xFF) / 255.0F;
    float a = (color >> 24 & 0xFF) / 255.0F;
    Tessellator tessellator = Tessellator.func_178181_a();
    BufferBuilder BufferBuilder = tessellator.func_178180_c();
    
    GlStateManager.func_179147_l();
    GlStateManager.func_179090_x();
    GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
    



    GlStateManager.func_179131_c(r, g, b, a);
    
    GL11.glLineWidth(width);
    
    BufferBuilder.func_181668_a(2, DefaultVertexFormats.field_181705_e);
    BufferBuilder.func_181662_b(x, y, 0.0D).func_181675_d();
    BufferBuilder.func_181662_b(x, y + h, 0.0D).func_181675_d();
    BufferBuilder.func_181662_b(x + w, y + h, 0.0D).func_181675_d();
    BufferBuilder.func_181662_b(x + w, y, 0.0D).func_181675_d();
    tessellator.func_78381_a();
    
    GlStateManager.func_179098_w();
    GlStateManager.func_179084_k();
  }
  
  public static void drawTexturedRect(int x, int y, int textureX, int textureY, int width, int height, int zLevel)
  {
    Tessellator tessellator = Tessellator.func_178181_a();
    BufferBuilder BufferBuilder = tessellator.func_178180_c();
    BufferBuilder.func_181668_a(7, DefaultVertexFormats.field_181707_g);
    BufferBuilder.func_181662_b(x + 0, y + height, zLevel)
      .func_187315_a((textureX + 0) * 0.00390625F, (textureY + height) * 0.00390625F)
      

      .func_181675_d();
    BufferBuilder.func_181662_b(x + width, y + height, zLevel)
      .func_187315_a((textureX + width) * 0.00390625F, (textureY + height) * 0.00390625F)
      

      .func_181675_d();
    BufferBuilder.func_181662_b(x + width, y + 0, zLevel)
      .func_187315_a((textureX + width) * 0.00390625F, (textureY + 0) * 0.00390625F)
      

      .func_181675_d();
    BufferBuilder.func_181662_b(x + 0, y + 0, zLevel)
      .func_187315_a((textureX + 0) * 0.00390625F, (textureY + 0) * 0.00390625F)
      

      .func_181675_d();
    tessellator.func_78381_a();
  }
  
  public static void drawLine(int x1, int y1, int x2, int y2, int color, float width) {
    float r = (color >> 16 & 0xFF) / 255.0F;
    float g = (color >> 8 & 0xFF) / 255.0F;
    float b = (color & 0xFF) / 255.0F;
    float a = (color >> 24 & 0xFF) / 255.0F;
    Tessellator tessellator = Tessellator.func_178181_a();
    BufferBuilder BufferBuilder = tessellator.func_178180_c();
    
    GlStateManager.func_179147_l();
    GlStateManager.func_179090_x();
    GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
    



    GlStateManager.func_179131_c(r, g, b, a);
    
    GL11.glLineWidth(width);
    
    BufferBuilder.func_181668_a(1, DefaultVertexFormats.field_181705_e);
    BufferBuilder.func_181662_b(x1, y1, 0.0D).func_181675_d();
    BufferBuilder.func_181662_b(x2, y2, 0.0D).func_181675_d();
    tessellator.func_78381_a();
    
    GlStateManager.func_179124_c(1.0F, 1.0F, 1.0F);
    GlStateManager.func_179098_w();
    GlStateManager.func_179084_k();
  }
  
  public static void drawText(String msg, int x, int y, int color) {
    MCfield_71466_p.func_78276_b(msg, x, y, color);
  }
  
  public static void drawTextShadow(String msg, int x, int y, int color) {
    MCfield_71466_p.func_175063_a(msg, x, y, color);
  }
  
  public static void drawTextShadowCentered(String msg, float x, float y, int color) {
    float offsetX = getTextWidth(msg) / 2.0F;
    float offsetY = getTextHeight() / 2.0F;
    MCfield_71466_p.func_175063_a(msg, x - offsetX, y - offsetY, color);
  }
  
  public static void drawTextAlignH(String msg, int x, int y, int color, boolean shadow, int alignmask) {
    int offsetX = AlignHelper.alignH(getTextWidth(msg), alignmask);
    MCfield_71466_p.func_175065_a(msg, x - offsetX, y, color, shadow);
  }
  
  public static void drawTextShadowAlignH(String msg, int x, int y, int color, int alignmask) {
    drawTextAlignH(msg, x, y, color, true, alignmask);
  }
  
  public static void drawTextAlign(String msg, int x, int y, int color, boolean shadow, int alignmask) {
    int offsetX = AlignHelper.alignH(getTextWidth(msg), alignmask);
    int offsetY = AlignHelper.alignV(getTextHeight(), alignmask);
    MCfield_71466_p.func_175065_a(msg, x - offsetX, y - offsetY, color, shadow);
  }
  
  public static void drawTextShadowAlign(String msg, int x, int y, int color, int alignmask) {
    drawTextAlign(msg, x, y, color, true, alignmask);
  }
  
  public static void drawTextAlign(String msg, int x, int y, int color, double scale, boolean shadow, int alignmask) {
    int offsetX = AlignHelper.alignH((int)(getTextWidth(msg) * scale), alignmask);
    int offsetY = AlignHelper.alignV((int)(getTextHeight() * scale), alignmask);
    if (scale != 1.0D) {
      drawText(msg, x - offsetX, y - offsetY, color, scale, shadow);
    } else {
      MCfield_71466_p.func_175065_a(msg, x - offsetX, y - offsetY, color, shadow);
    }
  }
  
  public static void drawTextAlign(List<String> msgList, int x, int y, int color, double scale, boolean shadow, int alignmask) {
    GlStateManager.func_179094_E();
    GlStateManager.func_179097_i();
    GlStateManager.func_179139_a(scale, scale, scale);
    
    int offsetY = AlignHelper.alignV((int)(getTextHeight() * scale), alignmask);
    int height = (int)(AlignHelper.getFlowDirY2(alignmask) * (getTextHeight() + 1) * scale);
    float invScale = (float)(1.0D / scale);
    
    for (int i = 0; i < msgList.size(); i++) {
      int offsetX = AlignHelper.alignH((int)(getTextWidth((String)msgList.get(i)) * scale), alignmask);
      
      MCfield_71466_p.func_175065_a(
        (String)msgList.get(i), (x - offsetX) * invScale, (y - offsetY + height * i) * invScale, color, shadow);
    }
    
    GlStateManager.func_179126_j();
    GlStateManager.func_179121_F();
  }
  
  public static void drawText(String msg, int x, int y, int color, double scale, boolean shadow) {
    GlStateManager.func_179094_E();
    GlStateManager.func_179097_i();
    GlStateManager.func_179139_a(scale, scale, scale);
    MCfield_71466_p.func_175065_a(msg, (int)(x * (1.0D / scale)), (int)(y * (1.0D / scale)), color, shadow);
    
    GlStateManager.func_179126_j();
    GlStateManager.func_179121_F();
  }
  
  public static void drawText(String msg, int x, int y, int color, double scale) {
    drawText(msg, x, y, color, scale, false);
  }
  
  public static void drawTextShadow(String msg, int x, int y, int color, double scale) {
    drawText(msg, x, y, color, scale, true);
  }
  
  public static int getTextWidth(String text, double scale) {
    return (int)(MCfield_71466_p.func_78256_a(text) * scale);
  }
  
  public static int getTextWidth(String text) {
    return getTextWidth(text, 1.0D);
  }
  
  public static int getTextHeight() {
    return MCfield_71466_p.field_78288_b;
  }
  
  public static int getTextHeight(double scale) {
    return (int)(MCfield_71466_p.field_78288_b * scale);
  }
  
  public static void drawItem(ItemStack item, int x, int y) {
    MC.func_175599_af().func_180450_b(item, x, y);
  }
  
  public static void drawItemOverlay(ItemStack stack, int x, int y) {
    MC.func_175599_af().func_180453_a(MCfield_71466_p, stack, x, y, null);
  }
  
  public static void drawItem(ItemStack item, double x, double y) {
    GlStateManager.func_179094_E();
    RenderHelper.func_74520_c();
    GlStateManager.func_179140_f();
    GlStateManager.func_179091_B();
    GlStateManager.func_179142_g();
    GlStateManager.func_179145_e();
    MCfunc_175599_affield_77023_b = 100.0F;
    renderItemAndEffectIntoGUI(Helper.getLocalPlayer(), item, x, y, 16.0D);
    MCfunc_175599_affield_77023_b = 0.0F;
    GlStateManager.func_179121_F();
    GlStateManager.func_179140_f();
    GlStateManager.func_179126_j();
    GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
  }
  
  public static void drawItemWithOverlay(ItemStack item, double x, double y, double scale) {
    GlStateManager.func_179094_E();
    RenderHelper.func_74520_c();
    GlStateManager.func_179140_f();
    GlStateManager.func_179091_B();
    GlStateManager.func_179142_g();
    GlStateManager.func_179145_e();
    MCfunc_175599_affield_77023_b = 100.0F;
    renderItemAndEffectIntoGUI(Helper.getLocalPlayer(), item, x, y, 16.0D);
    renderItemOverlayIntoGUI(MCfield_71466_p, item, x, y, null, scale);
    MCfunc_175599_affield_77023_b = 0.0F;
    GlStateManager.func_179121_F();
    GlStateManager.func_179140_f();
    GlStateManager.func_179126_j();
    GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
  }
  
  public static void drawPotionEffect(PotionEffect potion, int x, int y) {
    int index = potion.func_188419_a().func_76392_e();
    GlStateManager.func_179094_E();
    RenderHelper.func_74520_c();
    GlStateManager.func_179140_f();
    GlStateManager.func_179091_B();
    GlStateManager.func_179142_g();
    GlStateManager.func_179145_e();
    GlStateManager.func_179098_w();
    GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
    MC.func_110434_K().func_110577_a(GuiContainer.field_147001_a);
    drawTexturedRect(x, y, index % 8 * 18, 198 + index / 8 * 18, 18, 18, 100);
    potion.func_188419_a().renderHUDEffect(x, y, potion, MC, 255.0F);
    GlStateManager.func_179140_f();
    GlStateManager.func_179126_j();
    GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
    GlStateManager.func_179121_F();
  }
  
  public static void drawHead(ResourceLocation skinResource, double x, double y, float scale) {
    GlStateManager.func_179094_E();
    MCfield_71446_o.func_110577_a(skinResource);
    GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
    GlStateManager.func_179152_a(scale, scale, scale);
    drawScaledCustomSizeModalRect(x * (1.0F / scale), y * (1.0F / scale), 8.0F, 8.0F, 8.0D, 8.0D, 12.0D, 12.0D, 64.0D, 64.0D);
    
    drawScaledCustomSizeModalRect(x * (1.0F / scale), y * (1.0F / scale), 40.0F, 8.0F, 8.0D, 8.0D, 12.0D, 12.0D, 64.0D, 64.0D);
    
    GlStateManager.func_179121_F();
  }
  
  protected static void renderItemAndEffectIntoGUI(@Nullable EntityLivingBase living, ItemStack stack, double x, double y, double scale)
  {
    if (!stack.func_190926_b()) {
      MCfunc_175599_affield_77023_b += 50.0F;
      try {
        renderItemModelIntoGUI(stack, x, y, MC
          .func_175599_af().func_184393_a(stack, null, living), scale);
        


        MCfunc_175599_affield_77023_b -= 50.0F;
      }
      catch (Throwable t)
      {
        Helper.handleThrowable(t);
        
        MCfunc_175599_affield_77023_b -= 50.0F; } finally { MCfunc_175599_affield_77023_b -= 50.0F;
      }
    }
  }
  
  private static void renderItemModelIntoGUI(ItemStack stack, double x, double y, IBakedModel bakedmodel, double scale)
  {
    GlStateManager.func_179094_E();
    MC.func_110434_K().func_110577_a(TextureMap.field_110575_b);
    MC.func_110434_K()
      .func_110581_b(TextureMap.field_110575_b)
      .func_174936_b(false, false);
    GlStateManager.func_179091_B();
    GlStateManager.func_179141_d();
    GlStateManager.func_179092_a(516, 0.1F);
    GlStateManager.func_179147_l();
    GlStateManager.func_187401_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
    
    GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
    
    GlStateManager.func_179137_b(x, y, 100.0F + MCfunc_175599_affield_77023_b);
    GlStateManager.func_179109_b(8.0F, 8.0F, 0.0F);
    GlStateManager.func_179152_a(1.0F, -1.0F, 1.0F);
    GlStateManager.func_179139_a(scale, scale, scale);
    
    if (bakedmodel.func_177556_c()) {
      GlStateManager.func_179145_e();
    } else {
      GlStateManager.func_179140_f();
    }
    

    bakedmodel = ForgeHooksClient.handleCameraTransforms(bakedmodel, ItemCameraTransforms.TransformType.GUI, false);
    
    MC.func_175599_af().func_180454_a(stack, bakedmodel);
    GlStateManager.func_179118_c();
    GlStateManager.func_179101_C();
    GlStateManager.func_179140_f();
    GlStateManager.func_179121_F();
    MC.func_110434_K().func_110577_a(TextureMap.field_110575_b);
    MC.func_110434_K().func_110581_b(TextureMap.field_110575_b).func_174935_a();
  }
  





  protected static void renderItemOverlayIntoGUI(FontRenderer fr, ItemStack stack, double xPosition, double yPosition, @Nullable String text, double scale)
  {
    double SCALE_RATIO = 1.23076923077D;
    
    if (!stack.func_190926_b()) {
      if ((stack.func_190916_E() != 1) || (text != null)) {
        String s = text == null ? String.valueOf(stack.func_190916_E()) : text;
        GlStateManager.func_179140_f();
        GlStateManager.func_179097_i();
        GlStateManager.func_179084_k();
        fr.func_175063_a(s, 
        
          (float)(xPosition + 19.0D - 2.0D - fr.func_78256_a(s)), (float)(yPosition + 6.0D + 3.0D), 16777215);
        

        GlStateManager.func_179145_e();
        GlStateManager.func_179126_j();
        

        GlStateManager.func_179147_l();
      }
      
      if (stack.func_77973_b().showDurabilityBar(stack)) {
        GlStateManager.func_179140_f();
        GlStateManager.func_179097_i();
        GlStateManager.func_179090_x();
        GlStateManager.func_179118_c();
        GlStateManager.func_179084_k();
        double health = stack.func_77973_b().getDurabilityForDisplay(stack);
        int rgbfordisplay = stack.func_77973_b().getRGBDurabilityForDisplay(stack);
        int i = Math.round(13.0F - (float)health * 13.0F);
        int j = rgbfordisplay;
        draw(xPosition + scale / 8.0D, yPosition + scale / 1.23076923077D, 13.0D, 2.0D, 0, 0, 0, 255);
        draw(xPosition + scale / 8.0D, yPosition + scale / 1.23076923077D, i, 1.0D, j >> 16 & 0xFF, j >> 8 & 0xFF, j & 0xFF, 255);
        







        GlStateManager.func_179147_l();
        GlStateManager.func_179141_d();
        GlStateManager.func_179098_w();
        GlStateManager.func_179145_e();
        GlStateManager.func_179126_j();
      }
      
      EntityPlayerSP entityplayersp = func_71410_xfield_71439_g;
      




      float f3 = entityplayersp == null ? 0.0F : entityplayersp.func_184811_cZ().func_185143_a(stack.func_77973_b(), Minecraft.func_71410_x().func_184121_ak());
      
      if (f3 > 0.0F) {
        GlStateManager.func_179140_f();
        GlStateManager.func_179097_i();
        GlStateManager.func_179090_x();
        draw(xPosition, yPosition + scale * (1.0F - f3), 16.0D, scale * f3, 255, 255, 255, 127);
        GlStateManager.func_179098_w();
        GlStateManager.func_179145_e();
        GlStateManager.func_179126_j();
      }
    }
  }
  
  private static void draw(double x, double y, double width, double height, int red, int green, int blue, int alpha)
  {
    Tessellator tessellator = Tessellator.func_178181_a();
    BufferBuilder renderer = tessellator.func_178180_c();
    renderer.func_181668_a(7, DefaultVertexFormats.field_181706_f);
    renderer
      .func_181662_b(x + 0.0D, y + 0.0D, 0.0D)
      .func_181669_b(red, green, blue, alpha)
      .func_181675_d();
    renderer
      .func_181662_b(x + 0.0D, y + height, 0.0D)
      .func_181669_b(red, green, blue, alpha)
      .func_181675_d();
    renderer
      .func_181662_b(x + width, y + height, 0.0D)
      .func_181669_b(red, green, blue, alpha)
      .func_181675_d();
    renderer
      .func_181662_b(x + width, y + 0.0D, 0.0D)
      .func_181669_b(red, green, blue, alpha)
      .func_181675_d();
    Tessellator.func_178181_a().func_78381_a();
  }
  









  protected static void drawScaledCustomSizeModalRect(double x, double y, float u, float v, double uWidth, double vHeight, double width, double height, double tileWidth, double tileHeight)
  {
    double f = 1.0D / tileWidth;
    double f1 = 1.0D / tileHeight;
    Tessellator tessellator = Tessellator.func_178181_a();
    BufferBuilder bufferbuilder = tessellator.func_178180_c();
    bufferbuilder.func_181668_a(7, DefaultVertexFormats.field_181707_g);
    bufferbuilder
      .func_181662_b(x, y + height, 0.0D)
      .func_187315_a(u * f, (v + (float)vHeight) * f1)
      .func_181675_d();
    bufferbuilder
      .func_181662_b(x + width, y + height, 0.0D)
      .func_187315_a((u + (float)uWidth) * f, (v + (float)vHeight) * f1)
      .func_181675_d();
    bufferbuilder
      .func_181662_b(x + width, y, 0.0D)
      .func_187315_a((u + (float)uWidth) * f, v * f1)
      .func_181675_d();
    bufferbuilder
      .func_181662_b(x, y, 0.0D)
      .func_187315_a(u * f, v * f1)
      .func_181675_d();
    tessellator.func_78381_a();
  }
  
  public static int getHeadWidth(float scale) {
    return (int)(scale * 12.0F);
  }
  
  public static int getHeadWidth() {
    return getHeadWidth(1.0F);
  }
  
  public static int getHeadHeight(float scale) {
    return (int)(scale * 12.0F);
  }
  
  public static int getHeadHeight() {
    return getHeadWidth(1.0F);
  }
}
