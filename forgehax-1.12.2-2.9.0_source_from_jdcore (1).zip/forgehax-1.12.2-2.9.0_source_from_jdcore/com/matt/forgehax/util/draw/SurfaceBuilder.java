package com.matt.forgehax.util.draw;

import com.matt.forgehax.Globals;
import com.matt.forgehax.Helper;
import com.matt.forgehax.util.color.Color;
import com.matt.forgehax.util.draw.font.MinecraftFontRenderer;
import java.util.Stack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.GlStateManager.DestFactor;
import net.minecraft.client.renderer.GlStateManager.SourceFactor;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.item.ItemStack;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.opengl.GL11;









public class SurfaceBuilder
{
  public static final int COLOR = 1;
  public static final int SCALE = 2;
  public static final int TRANSLATION = 4;
  public static final int ROTATION = 8;
  public static final int ALL = 15;
  
  public SurfaceBuilder() {}
  
  private static final SurfaceBuilder INSTANCE = new SurfaceBuilder();
  
  public static SurfaceBuilder getBuilder() {
    return INSTANCE; }
  



  private final Stack<RenderSettings> settings = new Stack();
  private final RenderSettings DEFAULT_SETTINGS = new RenderSettings(null);
  
  private RenderSettings current() {
    return !settings.isEmpty() ? (RenderSettings)settings.peek() : DEFAULT_SETTINGS;
  }
  
  public SurfaceBuilder begin(int mode) {
    GL11.glBegin(mode);
    return this;
  }
  
  public SurfaceBuilder beginLines() {
    return begin(1);
  }
  
  public SurfaceBuilder beginLineLoop() {
    return begin(2);
  }
  
  public SurfaceBuilder beginQuads() {
    return begin(7);
  }
  
  public SurfaceBuilder beginPolygon() {
    return begin(9);
  }
  
  public SurfaceBuilder end() {
    GL11.glEnd();
    return this;
  }
  
  public SurfaceBuilder autoApply(boolean enabled) {
    current().setAutoApply(enabled);
    return this;
  }
  
  public SurfaceBuilder apply() {
    return apply(15);
  }
  
  public SurfaceBuilder apply(int flags) {
    RenderSettings current = current();
    if ((flags & 0x1) == 1) {
      current.applyColor();
    }
    if ((flags & 0x2) == 2) {
      current.applyScale();
    }
    if ((flags & 0x4) == 4) {
      current.applyTranslation();
    }
    if ((flags & 0x8) == 8) {
      current.applyRotation();
    }
    return this;
  }
  
  public SurfaceBuilder reset() {
    return reset(15);
  }
  
  public SurfaceBuilder reset(int flags) {
    RenderSettings current = current();
    if ((flags & 0x1) == 1) {
      current.resetColor();
    }
    if ((flags & 0x2) == 2) {
      current.resetScale();
    }
    if ((flags & 0x4) == 4) {
      current.resetTranslation();
    }
    if ((flags & 0x8) == 8) {
      current.resetRotation();
    }
    return this;
  }
  
  public SurfaceBuilder push() {
    GlStateManager.func_179094_E();
    settings.push(new RenderSettings(null));
    return this;
  }
  
  public SurfaceBuilder pop() {
    if (!settings.isEmpty()) {
      settings.pop();
    }
    GlStateManager.func_179121_F();
    return this;
  }
  
  public SurfaceBuilder color(double r, double g, double b, double a)
  {
    current().setColor4d(new double[] {
    
      MathHelper.func_151237_a(r, 0.0D, 1.0D), 
      MathHelper.func_151237_a(g, 0.0D, 1.0D), 
      MathHelper.func_151237_a(b, 0.0D, 1.0D), 
      MathHelper.func_151237_a(a, 0.0D, 1.0D) });
    
    return this;
  }
  
  public SurfaceBuilder color(int buffer) {
    return color((buffer >> 16 & 0xFF) / 255.0D, (buffer >> 8 & 0xFF) / 255.0D, (buffer & 0xFF) / 255.0D, (buffer >> 24 & 0xFF) / 255.0D);
  }
  



  public SurfaceBuilder color(int r, int g, int b, int a)
  {
    return color(r / 255.0D, g / 255.0D, b / 255.0D, a / 255.0D);
  }
  
  public SurfaceBuilder scale(double x, double y, double z) {
    current().setScale3d(new double[] { x, y, z });
    return this;
  }
  
  public SurfaceBuilder scale(double s) {
    return scale(s, s, s);
  }
  
  public SurfaceBuilder scale() {
    return scale(0.0D);
  }
  
  public SurfaceBuilder translate(double x, double y, double z) {
    current().setTranslate3d(new double[] { x, y, z });
    return this;
  }
  
  public SurfaceBuilder translate(double x, double y) {
    return translate(x, y, 0.0D);
  }
  
  public SurfaceBuilder rotate(double angle, double x, double y, double z) {
    current().setRotated4d(new double[] { angle, x, y, z });
    return this;
  }
  
  public SurfaceBuilder width(double width) {
    GlStateManager.func_187441_d((float)width);
    return this;
  }
  
  public SurfaceBuilder vertex(double x, double y, double z) {
    GL11.glVertex3d(x, y, z);
    return this;
  }
  
  public SurfaceBuilder vertex(double x, double y) {
    GL11.glVertex2d(x, y);
    return this;
  }
  
  public SurfaceBuilder line(double startX, double startY, double endX, double endY) {
    return vertex(startX, startY).vertex(endX, endY);
  }
  
  public SurfaceBuilder rectangle(double x, double y, double w, double h) {
    return vertex(x, y).vertex(x, y + h).vertex(x + w, y + h).vertex(x + w, y);
  }
  
  public SurfaceBuilder fontRenderer(MinecraftFontRenderer fontRenderer) {
    current().setFontRenderer(fontRenderer);
    return this;
  }
  
  private SurfaceBuilder text(String text, double x, double y, boolean shadow) {
    if (current().hasFontRenderer())
    {


      current().getFontRenderer().drawString(text, x, y + 1.0D, 
      


        Color.of(current().getColor4d()).toBuffer(), shadow);
    }
    else
    {
      GlStateManager.func_179094_E();
      GlStateManager.func_179137_b(x, y, 0.0D);
      
      MCfield_71466_p.func_175065_a(text, 0.0F, 0.0F, Color.of(current().getColor4d()).toBuffer(), shadow);
      
      GlStateManager.func_179121_F();
    }
    return this;
  }
  
  public SurfaceBuilder text(String text, double x, double y) {
    return text(text, x, y, false);
  }
  
  public SurfaceBuilder textWithShadow(String text, double x, double y) {
    return text(text, x, y, true);
  }
  
  public SurfaceBuilder task(Runnable task) {
    task.run();
    return this;
  }
  
  public SurfaceBuilder item(ItemStack stack, double x, double y) {
    MCfunc_175599_affield_77023_b = 100.0F;
    SurfaceHelper.renderItemAndEffectIntoGUI(
      Helper.getLocalPlayer(), stack, x, y, current().hasScale() ? current().getScale3d()[0] : 16.0D);
    MCfunc_175599_affield_77023_b = 0.0F;
    return this;
  }
  
  public SurfaceBuilder itemOverlay(ItemStack stack, double x, double y) {
    SurfaceHelper.renderItemOverlayIntoGUI(MCfield_71466_p, stack, x, y, null, 
    




      current().hasScale() ? current().getScale3d()[0] : 16.0D);
    return this;
  }
  
  public SurfaceBuilder head(ResourceLocation resource, double x, double y) {
    MCfield_71446_o.func_110577_a(resource);
    double scale = current().hasScale() ? current().getScale3d()[0] : 12.0D;
    SurfaceHelper.drawScaledCustomSizeModalRect(x * (1.0D / scale), y * (1.0D / scale), 8.0F, 8.0F, 8.0D, 8.0D, 12.0D, 12.0D, 64.0D, 64.0D);
    
    SurfaceHelper.drawScaledCustomSizeModalRect(x * (1.0D / scale), y * (1.0D / scale), 40.0F, 8.0F, 8.0D, 8.0D, 12.0D, 12.0D, 64.0D, 64.0D);
    
    return this;
  }
  
  public int getFontWidth(String text) {
    return current().hasFontRenderer() ? 
      current().getFontRenderer().getStringWidth(text) : MCfield_71466_p
      .func_78256_a(text);
  }
  
  public int getFontHeight() {
    return current().hasFontRenderer() ? 
      current().getFontRenderer().getHeight() : MCfield_71466_p.field_78288_b;
  }
  
  public int getFontHeight(String text)
  {
    return getFontHeight();
  }
  
  private double _getScaled(int index, double p) {
    return p * (1.0D / current().getScale3d()[index]);
  }
  
  public double getScaledX(double x) {
    return _getScaled(0, x);
  }
  
  public double getScaledY(double y) {
    return _getScaled(1, y);
  }
  
  public double getScaledZ(double z) {
    return _getScaled(2, z);
  }
  
  public double getScaled(double p) {
    return getScaledX(p);
  }
  
  public double getItemSize() {
    return 16.0D;
  }
  


  public static void disableTexture2D() {}
  


  public static void enableTexture2D() {}
  

  public static void enableBlend()
  {
    GlStateManager.func_179147_l();
    GlStateManager.func_187428_a(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA, GlStateManager.SourceFactor.ONE, GlStateManager.DestFactor.ZERO);
  }
  



  public static void disableBlend() {}
  


  public static void enableFontRendering() {}
  


  public static void disableFontRendering() {}
  


  public static void enableItemRendering()
  {
    RenderHelper.func_74520_c();
    GlStateManager.func_179140_f();
    GlStateManager.func_179091_B();
    GlStateManager.func_179142_g();
    GlStateManager.func_179145_e();
  }
  
  public static void disableItemRendering() {
    GlStateManager.func_179140_f();
    GlStateManager.func_179126_j();
  }
  

  public static void clearColor() { GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F); }
  
  private static class RenderSettings {
    private RenderSettings() {}
    
    private static final double[] EMPTY_VECTOR3D = { 0.0D, 0.0D, 0.0D };
    private static final double[] EMPTY_VECTOR4D = { 0.0D, 0.0D, 0.0D, 0.0D };
    
    private double[] color4d = EMPTY_VECTOR4D;
    private double[] scale3d = EMPTY_VECTOR3D;
    private double[] translate3d = EMPTY_VECTOR3D;
    private double[] rotated4d = EMPTY_VECTOR4D;
    
    private boolean autoApply = true;
    
    private MinecraftFontRenderer fontRenderer = null;
    
    public double[] getColor4d() {
      return color4d;
    }
    
    public void setColor4d(double[] color4d) {
      this.color4d = color4d;
      if (autoApply) {
        applyColor();
      }
    }
    
    public double[] getScale3d() {
      return scale3d;
    }
    
    public void setScale3d(double[] scale3d) {
      this.scale3d = scale3d;
      if (autoApply) {
        applyScale();
      }
    }
    
    public double[] getTranslate3d() {
      return translate3d;
    }
    
    public void setTranslate3d(double[] translate3d) {
      this.translate3d = translate3d;
      if (autoApply) {
        applyTranslation();
      }
    }
    
    public double[] getRotated4d() {
      return rotated4d;
    }
    
    public void setRotated4d(double[] rotated4d) {
      this.rotated4d = rotated4d;
      if (autoApply) {
        applyRotation();
      }
    }
    
    public MinecraftFontRenderer getFontRenderer() {
      return fontRenderer;
    }
    
    public void setFontRenderer(MinecraftFontRenderer fontRenderer) {
      this.fontRenderer = fontRenderer;
    }
    
    public void setAutoApply(boolean autoApply) {
      this.autoApply = autoApply;
    }
    
    public boolean hasColor() {
      return color4d != EMPTY_VECTOR4D;
    }
    
    public boolean hasScale() {
      return scale3d != EMPTY_VECTOR3D;
    }
    
    public boolean hasTranslation() {
      return translate3d != EMPTY_VECTOR3D;
    }
    
    public boolean hasRotation() {
      return rotated4d != EMPTY_VECTOR4D;
    }
    
    public boolean hasFontRenderer() {
      return fontRenderer != null;
    }
    
    public void applyColor() {
      if (hasColor()) {
        GL11.glColor4d(color4d[0], color4d[1], color4d[2], color4d[3]);
      }
    }
    
    public void applyScale() {
      if (hasScale()) {
        GL11.glScaled(scale3d[0], scale3d[1], scale3d[2]);
      }
    }
    
    public void applyTranslation() {
      if (hasTranslation()) {
        GL11.glTranslated(translate3d[0], translate3d[1], translate3d[2]);
      }
    }
    
    public void applyRotation() {
      if (hasRotation()) {
        GL11.glRotated(rotated4d[0], rotated4d[1], rotated4d[2], rotated4d[3]);
      }
    }
    
    public void clearColor() {
      color4d = EMPTY_VECTOR4D;
    }
    
    public void clearScale() {
      scale3d = EMPTY_VECTOR3D;
    }
    
    public void clearTranslation() {
      translate3d = EMPTY_VECTOR3D;
    }
    
    public void clearRotation() {
      rotated4d = EMPTY_VECTOR4D;
    }
    
    public void clearFontRenderer() {
      fontRenderer = null;
    }
    
    public void resetColor() {
      if (hasColor()) {
        clearColor();
        GL11.glColor4d(1.0D, 1.0D, 1.0D, 1.0D);
      }
    }
    
    public void resetScale() {
      if (hasScale()) {
        clearScale();
        GL11.glScaled(1.0D, 1.0D, 1.0D);
      }
    }
    
    public void resetTranslation() {
      if (hasTranslation()) {
        clearTranslation();
        GL11.glTranslated(0.0D, 0.0D, 0.0D);
      }
    }
    
    public void resetRotation() {
      if (hasRotation()) {
        clearRotation();
        GL11.glRotated(0.0D, 0.0D, 0.0D, 0.0D);
      }
    }
  }
}
