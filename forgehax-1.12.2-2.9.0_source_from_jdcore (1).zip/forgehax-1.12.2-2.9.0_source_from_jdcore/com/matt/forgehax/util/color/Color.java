package com.matt.forgehax.util.color;

import java.util.Objects;

public abstract class Color
{
  public Color() {}
  
  public static int clamp(int c)
  {
    return Math.min(255, Math.max(0, c));
  }
  
  public static float clamp(float c) {
    return Math.min(1.0F, Math.max(0.0F, c));
  }
  
  public static Color ofInteger() {
    return ColorBuffer.getFactory();
  }
  
  public static Color ofFloat() {
    return Color4F.getFactory();
  }
  
  public static Color of(int buffer) {
    return ofInteger().set(buffer);
  }
  
  public static Color of(int red, int green, int blue, int alpha) {
    return ofInteger().set(red, green, blue, alpha);
  }
  
  public static Color of(int red, int green, int blue) {
    return ofInteger().set(red, green, blue);
  }
  
  public static Color of(int[] color) {
    return ofInteger().set(color);
  }
  
  public static Color of(float red, float green, float blue, float alpha) {
    return ofFloat().set(red, green, blue, alpha);
  }
  
  public static Color of(float red, float green, float blue) {
    return ofFloat().set(red, green, blue);
  }
  
  public static Color of(float[] color) {
    return ofFloat().set(color);
  }
  
  public static Color of(double red, double green, double blue, double alpha) {
    return ofFloat().set(red, green, blue, alpha);
  }
  
  public static Color of(double red, double green, double blue) {
    return ofFloat().set(red, green, blue);
  }
  
  public static Color of(double[] color) {
    return ofFloat().set(color);
  }
  








  public abstract Color set(int paramInt);
  








  public Color set(int red, int green, int blue, int alpha)
  {
    return set((red << 16) + (green << 8) + blue + (alpha << 24));
  }
  






  public Color set(int red, int green, int blue)
  {
    return set(red, green, blue, 255);
  }
  
  public Color set(int[] color) {
    Objects.requireNonNull(color);
    switch (color.length) {
    case 3: 
      return set(color[0], color[1], color[2]);
    case 4: 
      return set(color[0], color[1], color[2], color[3]);
    }
    throw new IllegalArgumentException("color[] must be of length 3 or 4");
  }
  








  public abstract Color set(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4);
  







  public Color set(float red, float green, float blue)
  {
    return set(red, green, blue, 1.0F);
  }
  
  public Color set(float[] color) {
    Objects.requireNonNull(color);
    switch (color.length) {
    case 3: 
      return set(color[0], color[1], color[2]);
    case 4: 
      return set(color[0], color[1], color[2], color[3]);
    }
    throw new IllegalArgumentException("color[] must be of length 3 or 4");
  }
  








  public Color set(double red, double green, double blue, double alpha)
  {
    return set((float)red, (float)green, (float)blue, (float)alpha);
  }
  







  public Color set(double red, double green, double blue)
  {
    return set(red, green, blue, 1.0D);
  }
  
  public Color set(double[] color) {
    Objects.requireNonNull(color);
    switch (color.length) {
    case 3: 
      return set(color[0], color[1], color[2]);
    case 4: 
      return set(color[0], color[1], color[2], color[3]);
    }
    throw new IllegalArgumentException("color[] must be of length 3 or 4");
  }
  





  public abstract int getRed();
  





  public abstract int getGreen();
  





  public abstract int getBlue();
  





  public abstract int getAlpha();
  





  public Color setRed(int red)
  {
    return set(red, getGreen(), getBlue(), getAlpha());
  }
  




  public Color setGreen(int green)
  {
    return set(getRed(), green, getBlue(), getAlpha());
  }
  




  public Color setBlue(int blue)
  {
    return set(getRed(), getGreen(), blue, getAlpha());
  }
  




  public Color setAlpha(int alpha)
  {
    return set(getRed(), getGreen(), getBlue(), alpha);
  }
  





  public abstract float getRedAsFloat();
  





  public abstract float getGreenAsFloat();
  





  public abstract float getBlueAsFloat();
  





  public abstract float getAlphaAsFloat();
  




  public Color setRed(float red)
  {
    return set(red, getGreenAsFloat(), getBlueAsFloat(), getAlphaAsFloat());
  }
  




  public Color setGreen(float green)
  {
    return set(getRedAsFloat(), green, getBlueAsFloat(), getAlphaAsFloat());
  }
  




  public Color setBlue(float blue)
  {
    return set(getRedAsFloat(), getGreenAsFloat(), blue, getAlphaAsFloat());
  }
  




  public Color setAlpha(float alpha)
  {
    return set(getRedAsFloat(), getGreenAsFloat(), getBlueAsFloat(), alpha);
  }
  





  public double getRedAsDouble()
  {
    return getRedAsFloat();
  }
  





  public double getGreenAsDouble()
  {
    return getGreenAsFloat();
  }
  





  public double getBlueAsDouble()
  {
    return getBlueAsFloat();
  }
  





  public double getAlphaAsDouble()
  {
    return getAlphaAsFloat();
  }
  





  public Color setRed(double red)
  {
    return setRed((float)red);
  }
  





  public Color setGreen(double green)
  {
    return setGreen((float)green);
  }
  





  public Color setBlue(double blue)
  {
    return setBlue((float)blue);
  }
  





  public Color setAlpha(double alpha)
  {
    return setAlpha((float)alpha);
  }
  




  public int toBuffer()
  {
    return (getRed() << 16) + (getGreen() << 8) + getBlue() + (getAlpha() << 24);
  }
  




  public int[] toIntegerArray()
  {
    return new int[] { getRed(), getGreen(), getBlue(), getAlpha() };
  }
  




  public float[] toFloatArray()
  {
    return new float[] { getRedAsFloat(), getGreenAsFloat(), getBlueAsFloat(), getAlphaAsFloat() };
  }
  





  public double[] toDoubleArray()
  {
    float[] array = toFloatArray();
    return new double[] { array[0], array[1], array[2], array[3] };
  }
  

  public abstract String toString();
  

  public abstract int hashCode();
  
  public boolean equals(Object obj)
  {
    return (this == obj) || (((obj instanceof Color)) && (hashCode() == obj.hashCode()));
  }
}
