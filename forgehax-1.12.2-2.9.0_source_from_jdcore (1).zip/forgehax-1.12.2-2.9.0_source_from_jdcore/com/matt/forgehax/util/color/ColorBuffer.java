package com.matt.forgehax.util.color;



public class ColorBuffer
  extends Color
{
  private static final Color FACTORY = new ColorBuffer();
  private final int buffer;
  
  public static Color getFactory() { return FACTORY; }
  






  private ColorBuffer()
  {
    this(0);
  }
  
  private ColorBuffer(int buffer) {
    this.buffer = buffer;
  }
  
  public Color set(int buffer)
  {
    return new ColorBuffer(buffer);
  }
  
  public Color set(float red, float green, float blue, float alpha)
  {
    return set((int)(red * 255.0F), (int)(green * 255.0F), (int)(blue * 255.0F), (int)(alpha * 255.0F));
  }
  

  public int getRed()
  {
    return toBuffer() >> 16 & 0xFF;
  }
  
  public int getGreen()
  {
    return toBuffer() >> 8 & 0xFF;
  }
  
  public int getBlue()
  {
    return toBuffer() & 0xFF;
  }
  
  public int getAlpha()
  {
    return toBuffer() >> 24 & 0xFF;
  }
  
  public float getRedAsFloat()
  {
    return getRed() / 255.0F;
  }
  
  public float getGreenAsFloat()
  {
    return getGreen() / 255.0F;
  }
  
  public float getBlueAsFloat()
  {
    return getBlue() / 255.0F;
  }
  
  public float getAlphaAsFloat()
  {
    return getAlpha() / 255.0F;
  }
  
  public int toBuffer()
  {
    return buffer;
  }
  
  public float[] toFloatArray()
  {
    return new float[] { getRedAsFloat(), getGreenAsFloat(), getBlueAsFloat(), getAlphaAsFloat() };
  }
  
  public int hashCode()
  {
    return Integer.hashCode(buffer);
  }
  
  public String toString()
  {
    return String.format("r=%d,g=%d,b=%d,a=%d", new Object[] { Integer.valueOf(getRed()), Integer.valueOf(getGreen()), Integer.valueOf(getBlue()), Integer.valueOf(getAlpha()) });
  }
}
