package com.matt.forgehax.util.color;




public abstract interface Colors
{
  public static final Color WHITE = Color.of(255, 255, 255, 255);
  public static final Color BLACK = Color.of(0, 0, 0, 255);
  public static final Color RED = Color.of(255, 0, 0, 255);
  public static final Color GREEN = Color.of(0, 255, 0, 255);
  public static final Color BLUE = Color.of(0, 0, 255, 255);
  public static final Color ORANGE = Color.of(255, 128, 0, 255);
  public static final Color PURPLE = Color.of(163, 73, 163, 255);
  public static final Color GRAY = Color.of(127, 127, 127, 255);
  public static final Color DARK_RED = Color.of(64, 0, 0, 255);
  public static final Color YELLOW = Color.of(255, 255, 0, 255);
}
