package com.matt.forgehax.util.color;

import java.util.Arrays;



public class Color4F
  extends Color
{
  private static final Color FACTORY = new Color4F();
  
  public static Color getFactory() {
    return FACTORY;
  }
  




  private final float[] color = new float[4];
  
  private Color4F() {}
  
  private Color4F(float red, float green, float blue, float alpha)
  {
    color[0] = red;
    color[1] = green;
    color[2] = blue;
    color[3] = alpha;
  }
  
  public Color set(int buffer)
  {
    return set((buffer >> 16 & 0xFF) / 255.0F, (buffer >> 8 & 0xFF) / 255.0F, (buffer & 0xFF) / 255.0F, (buffer >> 24 & 0xFF) / 255.0F);
  }
  




  public Color set(float red, float green, float blue, float alpha)
  {
    return new Color4F(red, green, blue, alpha);
  }
  
  public int getRed()
  {
    return (int)(getRedAsFloat() * 255.0F);
  }
  
  public int getGreen()
  {
    return (int)(getRedAsFloat() * 255.0F);
  }
  
  public int getBlue()
  {
    return (int)(getRedAsFloat() * 255.0F);
  }
  
  public int getAlpha()
  {
    return (int)(getRedAsFloat() * 255.0F);
  }
  
  public float getRedAsFloat()
  {
    return color[0];
  }
  
  public float getGreenAsFloat()
  {
    return color[1];
  }
  
  public float getBlueAsFloat()
  {
    return color[2];
  }
  
  public float getAlphaAsFloat()
  {
    return color[3];
  }
  
  public float[] toFloatArray()
  {
    return Arrays.copyOf(color, color.length);
  }
  
  public String toString()
  {
    return String.format("r=%.2f,g=%.2f,b=%.2f,a=%.2f", new Object[] {
    
      Float.valueOf(getRedAsFloat()), Float.valueOf(getGreenAsFloat()), Float.valueOf(getBlueAsFloat()), Float.valueOf(getAlphaAsFloat()) });
  }
  
  public int hashCode()
  {
    return Arrays.hashCode(color);
  }
}
