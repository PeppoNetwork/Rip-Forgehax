package com.matt.forgehax.util.console;

import com.matt.forgehax.Globals;
import com.matt.forgehax.Helper;
import java.util.concurrent.atomic.AtomicInteger;
import joptsimple.internal.Strings;
import net.minecraft.util.text.Style;
import net.minecraft.util.text.TextFormatting;





public class ConsoleIO
  implements Globals
{
  public static final Style HEADING = new Style().func_150238_a(TextFormatting.GRAY).func_150217_b(Boolean.valueOf(true));
  
  private static final ThreadLocal<AtomicInteger> INDENTATION = new ThreadLocal();
  
  public ConsoleIO() {}
  
  private static AtomicInteger getOrCreate() { AtomicInteger count = (AtomicInteger)INDENTATION.get();
    if (count == null) {
      count = new AtomicInteger(1);
      INDENTATION.set(count);
    }
    return count;
  }
  
  private static final int MIN_INDENT = 1;
  public static void start() { getOrCreate().set(1); }
  

  public static void write(String msg, Style style) {
    String tab = Strings.repeat('>', Math.max(getOrCreate().get(), 1)) + " ";
    if (style == null) {
      Helper.printMessageNaked(tab, msg);
    } else {
      Helper.printMessageNaked(tab, msg, style);
    }
  }
  
  public static void write(String msg) {
    write(msg, null);
  }
  
  public static void incrementIndent() {
    getOrCreate().incrementAndGet();
  }
  
  public static void decrementIndent() {
    getOrCreate().decrementAndGet();
  }
  
  public static int getIndents() {
    return getOrCreate().get();
  }
  
  public static void setIndents(int indents) {
    getOrCreate().set(indents);
  }
  
  public static void finished() {
    INDENTATION.remove();
  }
}
