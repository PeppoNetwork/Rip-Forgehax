package com.matt.forgehax.util.console;



public abstract interface ConsoleWriter
{
  public void write(String msg)
  {
    ConsoleIO.write(msg);
  }
  
  public void incrementIndent() {}
  
  public void decrementIndent() {}
}
