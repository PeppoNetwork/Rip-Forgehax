package com.matt.forgehax.util.classloader;

import com.matt.forgehax.util.FileHelper;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.FileSystem;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Iterator;

public class CustomClassLoaders
{
  public CustomClassLoaders() {}
  
  public static ClassLoader newFsClassLoader(ClassLoader parent, FileSystem fs) throws RuntimeException
  {
    try
    {
      return new FsClassLoader(parent, fs);
    } catch (MalformedURLException e) {
      throw new RuntimeException(e);
    }
  }
  
  private static class FsClassLoader extends URLClassLoader
  {
    private final Path root;
    
    private FsClassLoader(ClassLoader parent, Path path) throws MalformedURLException {
      super(parent);
      root = path;
    }
    
    public FsClassLoader(ClassLoader parent, FileSystem fileSystem) throws MalformedURLException {
      this(parent, (Path)fileSystem.getRootDirectories().iterator().next());
    }
    
    public Path getRoot() {
      return root;
    }
    
    public FileSystem getFileSystem() {
      return root.getFileSystem();
    }
    
    protected Class<?> findClass(String name) throws ClassNotFoundException
    {
      try {
        Path location = getRoot().resolve(FileHelper.asFilePath(name).concat(".class"));
        if (Files.exists(location, new java.nio.file.LinkOption[0])) {
          byte[] classData = Files.readAllBytes(location);
          return defineClass(name, classData, 0, classData.length);
        }
      } catch (IOException e) {
        e.printStackTrace();
      }
      return null;
    }
  }
}
