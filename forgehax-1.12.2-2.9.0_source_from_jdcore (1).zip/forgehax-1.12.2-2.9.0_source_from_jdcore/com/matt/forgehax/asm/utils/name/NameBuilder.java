package com.matt.forgehax.asm.utils.name;

public class NameBuilder
{
  public NameBuilder() {}
  
  public static <E> IName<E> create(E real, E srg, E obf)
  {
    if ((srg == null) && (obf == null)) {
      return createSingleName(real);
    }
    return createMcMultiName(real, srg, obf);
  }
  
  public static <E> IName<E> createSingleName(E real)
  {
    return new SingleName(real);
  }
  
  public static <E> IName<E> createMcMultiName(E real, E srg, E obf) {
    return new McMultiName(real, srg, obf);
  }
}
