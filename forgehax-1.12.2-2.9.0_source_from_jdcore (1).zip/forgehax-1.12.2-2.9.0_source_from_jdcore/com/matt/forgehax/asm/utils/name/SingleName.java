package com.matt.forgehax.asm.utils.name;

import com.matt.forgehax.asm.utils.environment.State;
import java.util.Objects;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;


public class SingleName<E>
  implements IName<E>
{
  private final E normal;
  
  public SingleName(@Nonnull E normal)
  {
    Objects.requireNonNull(normal);
    this.normal = normal;
  }
  
  public E get()
  {
    return normal;
  }
  
  @Nullable
  public E getByState(State state)
  {
    switch (1.$SwitchMap$com$matt$forgehax$asm$utils$environment$State[state.ordinal()]) {
    case 1: 
      return get();
    }
    return null;
  }
  

  public int getStateCount()
  {
    return 1;
  }
}
