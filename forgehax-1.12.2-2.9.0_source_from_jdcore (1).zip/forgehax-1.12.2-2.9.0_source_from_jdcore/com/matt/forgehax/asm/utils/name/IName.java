package com.matt.forgehax.asm.utils.name;

import com.matt.forgehax.asm.utils.environment.State;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;



public abstract interface IName<E>
{
  @Nonnull
  public abstract E get();
  
  @Nullable
  public abstract E getByState(State paramState);
  
  @Nonnull
  public E getByStateSafe(State state)
  {
    E value = getByState(state);
    return value != null ? value : get();
  }
  
  public abstract int getStateCount();
}
