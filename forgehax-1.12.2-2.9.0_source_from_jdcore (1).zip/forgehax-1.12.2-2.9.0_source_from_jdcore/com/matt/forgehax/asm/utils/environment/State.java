package com.matt.forgehax.asm.utils.environment;

public enum State
{
  NORMAL,  SRG,  OBFUSCATED;
  
  private State() {}
}
