package com.matt.forgehax.asm.utils.environment;

import javax.annotation.Nullable;

public abstract interface IStateMapper
{
  @Nullable
  public abstract String getObfClassName(String paramString);
  
  @Nullable
  public abstract String getMcpClassName(String paramString);
  
  @Nullable
  public abstract String getSrgMethodName(String paramString1, String paramString2, String paramString3);
  
  @Nullable
  public abstract String getObfMethodName(String paramString1, String paramString2, String paramString3);
  
  @Nullable
  public abstract String getSrgFieldName(String paramString1, String paramString2);
  
  @Nullable
  public abstract String getObfFieldName(String paramString1, String paramString2);
}
