package com.matt.forgehax.asm.utils;

import org.objectweb.asm.tree.AbstractInsnNode;

public class InsnPattern
{
  private final AbstractInsnNode first;
  private final AbstractInsnNode last;
  
  public InsnPattern(AbstractInsnNode first, AbstractInsnNode last)
  {
    java.util.Objects.requireNonNull(first);
    java.util.Objects.requireNonNull(last);
    this.first = first;
    this.last = last;
  }
  
  public <T extends AbstractInsnNode> T getFirst() {
    return first;
  }
  
  public <T extends AbstractInsnNode> T getLast() {
    return last;
  }
  
  public <T extends AbstractInsnNode> T getIndex(int index) {
    AbstractInsnNode node = first;
    for (int i = 0; i < index; i++) {
      node = node.getNext();
    }
    

    return node;
  }
}
