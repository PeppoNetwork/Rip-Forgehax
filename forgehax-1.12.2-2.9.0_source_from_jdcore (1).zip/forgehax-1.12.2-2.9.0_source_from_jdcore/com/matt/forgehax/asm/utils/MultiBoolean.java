package com.matt.forgehax.asm.utils;

import com.google.common.collect.Sets;
import java.util.Set;





public class MultiBoolean
{
  public MultiBoolean() {}
  
  private final Set<String> ids = Sets.newCopyOnWriteArraySet();
  
  private int level = 0;
  
  private void clampLevel() {
    level = Math.max(0, Math.min(ids.size(), level));
  }
  




  public void enable(String uniqueId)
  {
    if (ids.add(uniqueId)) {
      level += 1;
      clampLevel();
    }
  }
  




  public void disable(String uniqueId)
  {
    if (ids.remove(uniqueId)) {
      level -= 1;
      clampLevel();
    }
  }
  



  public void forceDisable()
  {
    level = 0;
    ids.clear();
  }
  




  public boolean isEnabled()
  {
    return level > 0;
  }
}
