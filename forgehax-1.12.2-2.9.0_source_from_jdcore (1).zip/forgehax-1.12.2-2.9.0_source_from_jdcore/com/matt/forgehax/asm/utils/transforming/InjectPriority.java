package com.matt.forgehax.asm.utils.transforming;

public enum InjectPriority
{
  HIGHEST,  HIGH,  DEFAULT,  LOW,  LOWEST;
  
  private InjectPriority() {}
}
