package com.matt.forgehax.asm.utils.transforming;

import java.lang.annotation.Annotation;

public @interface RegisterClassPatch {}
