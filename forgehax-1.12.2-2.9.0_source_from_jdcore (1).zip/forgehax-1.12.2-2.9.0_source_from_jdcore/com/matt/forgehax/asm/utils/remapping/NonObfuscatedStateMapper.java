package com.matt.forgehax.asm.utils.remapping;

import com.matt.forgehax.asm.utils.environment.IStateMapper;
import javax.annotation.Nullable;

public class NonObfuscatedStateMapper
  implements IStateMapper
{
  public NonObfuscatedStateMapper() {}
  
  private static NonObfuscatedStateMapper INSTANCE = null;
  
  public static NonObfuscatedStateMapper getInstance() {
    return INSTANCE == null ? (NonObfuscatedStateMapper.INSTANCE = new NonObfuscatedStateMapper()) : INSTANCE;
  }
  
  @Nullable
  public String getObfClassName(String className)
  {
    return null;
  }
  
  @Nullable
  public String getMcpClassName(String className)
  {
    return null;
  }
  

  @Nullable
  public String getSrgMethodName(String parentClassName, String methodName, String methodDescriptor)
  {
    return 
      ObfuscatedStateMapper.getInstance().getSrgMethodName(parentClassName, methodName, methodDescriptor);
  }
  

  @Nullable
  public String getObfMethodName(String parentClassName, String methodName, String methodDescriptor)
  {
    return null;
  }
  
  @Nullable
  public String getSrgFieldName(String parentClassName, String fieldName)
  {
    return ObfuscatedStateMapper.getInstance().getSrgFieldName(parentClassName, fieldName);
  }
  
  @Nullable
  public String getObfFieldName(String parentClassName, String fieldName)
  {
    return null;
  }
}
