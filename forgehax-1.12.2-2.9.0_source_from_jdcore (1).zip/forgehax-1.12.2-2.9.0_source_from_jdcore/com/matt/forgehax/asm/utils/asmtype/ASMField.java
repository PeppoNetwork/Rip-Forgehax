package com.matt.forgehax.asm.utils.asmtype;

import com.matt.forgehax.asm.utils.environment.State;
import com.matt.forgehax.asm.utils.name.IName;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import javax.annotation.Nullable;
import org.objectweb.asm.Type;

public class ASMField
  extends ASMClassChild
{
  private final IName<String> fieldName;
  private final IName<Type> type;
  
  public ASMField(@Nullable ASMClass parentClass, IName<String> fieldName, IName<Type> type)
  {
    super(parentClass);
    this.fieldName = fieldName;
    this.type = type;
  }
  






  public String getNameByState(State state)
  {
    return (String)fieldName.getByStateSafe(state);
  }
  
  public String getDescriptorByState(State state)
  {
    return ((Type)type.getByStateSafe(state)).getDescriptor();
  }
  
  public boolean equals(Object obj)
  {
    return ((obj instanceof ASMField)) && 
      (Objects.equals(getName(), ((ASMField)obj).getName())) && 
      (Objects.equals(getDescriptor(), ((ASMField)obj).getDescriptor()));
  }
  
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append(
      String.format("FIELD[states=%d,maxStates=%d]{", new Object[] {
      
      Integer.valueOf(fieldName.getStateCount()), Integer.valueOf(Math.max(fieldName.getStateCount(), type.getStateCount())) }));
    Iterator<State> it = Arrays.asList(State.values()).iterator();
    boolean needsSeparator = false;
    while (it.hasNext()) {
      State next = (State)it.next();
      if ((fieldName.getByState(next) != null) || (type.getByState(next) != null)) {
        if (needsSeparator) {
          builder.append(",");
        }
        builder.append(next.name());
        builder.append("=");
        builder.append(getNameByState(next));
        builder.append(":");
        builder.append(getDescriptorByState(next));
        needsSeparator = true;
      }
    }
    builder.append("}");
    return builder.toString();
  }
}
