package com.matt.forgehax.asm.utils.asmtype;

import com.matt.forgehax.asm.utils.environment.RuntimeState;
import com.matt.forgehax.asm.utils.environment.State;
import com.matt.forgehax.asm.utils.name.IName;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import javax.annotation.Nullable;
import org.objectweb.asm.Type;





public class ASMMethod
  extends ASMClassChild
{
  private final IName<String> methodName;
  private final IName<Type>[] parameters;
  private final IName<Type> returnType;
  
  public ASMMethod(@Nullable ASMClass parentClass, IName<String> methodName, IName<Type>[] parameters, IName<Type> returnType)
  {
    super(parentClass);
    this.methodName = methodName;
    this.parameters = ((IName[])Arrays.copyOf(parameters, parameters.length));
    this.returnType = returnType;
  }
  






  public String getNameByState(State state)
  {
    return (String)methodName.getByStateSafe(state);
  }
  
  public String getDescriptorByState(State state)
  {
    return 
      Type.getMethodType(getReturnTypeByState(state), getArgumentTypesByState(state)).getDescriptor();
  }
  




  public Type[] getArgumentTypes()
  {
    return getArgumentTypesByState(State.NORMAL);
  }
  
  public Type[] getArgumentTypesByState(State state) {
    Type[] all = new Type[parameters.length];
    for (int i = 0; i < parameters.length; i++) {
      all[i] = ((Type)parameters[i].getByStateSafe(state));
    }
    return all;
  }
  


  private boolean isArgumentStatePresent(State state)
  {
    for (int i = 0; i < parameters.length; i++) {
      Type arg = (Type)parameters[i].getByState(state);
      if (arg != null) {
        return true;
      }
    }
    return false;
  }
  




  public Type[] getRuntimeArgumentTypes()
  {
    return getArgumentTypesByState(RuntimeState.getState());
  }
  




  public Type getReturnType()
  {
    return (Type)returnType.get();
  }
  
  public Type getReturnTypeByState(State state) {
    return (Type)returnType.getByStateSafe(state);
  }
  




  public Type getRuntimeReturnType()
  {
    return getReturnTypeByState(RuntimeState.getState());
  }
  
  public boolean equals(Object obj)
  {
    return ((obj instanceof ASMMethod)) && 
      (Objects.equals(getName(), ((ASMMethod)obj).getName())) && 
      (Objects.equals(getDescriptor(), ((ASMMethod)obj).getDescriptor()));
  }
  
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    

    int maxStates = Math.max(methodName.getStateCount(), returnType.getStateCount());
    for (IName<Type> nm : parameters) {
      maxStates = Math.max(maxStates, nm.getStateCount());
    }
    builder.append(
      String.format("METHOD[states=%d,maxStates=%d]{", new Object[] {Integer.valueOf(methodName.getStateCount()), Integer.valueOf(maxStates) }));
    Object it = Arrays.asList(State.values()).iterator();
    boolean needsSeparator = false;
    while (((Iterator)it).hasNext()) {
      State next = (State)((Iterator)it).next();
      
      if ((methodName.getByState(next) != null) || 
        (returnType.getByState(next) != null) || 
        (isArgumentStatePresent(next))) {
        if (needsSeparator) {
          builder.append(",");
        }
        builder.append(next.name());
        builder.append("=");
        builder.append(getNameByState(next));
        builder.append(getDescriptorByState(next));
        needsSeparator = true;
      }
    }
    builder.append("}");
    return builder.toString();
  }
}
