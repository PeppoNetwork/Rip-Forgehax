package com.matt.forgehax.asm.utils.asmtype;

import com.matt.forgehax.asm.utils.asmtype.builders.ASMBuilders;
import com.matt.forgehax.asm.utils.asmtype.builders.ASMFieldBuilder;
import com.matt.forgehax.asm.utils.asmtype.builders.ASMMethodBuilder;
import com.matt.forgehax.asm.utils.environment.RuntimeState;
import com.matt.forgehax.asm.utils.environment.State;
import com.matt.forgehax.asm.utils.name.IName;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import org.objectweb.asm.Type;

public class ASMClass
  implements IASMType
{
  private final IName<Type> className;
  
  public ASMClass(IName<Type> className)
  {
    this.className = className;
  }
  
  public IName<Type> getAll() {
    return className;
  }
  





  public String getNameByState(State state)
  {
    return ((Type)className.getByStateSafe(state)).getClassName();
  }
  
  public String getDescriptorByState(State state)
  {
    return ((Type)className.getByStateSafe(state)).getDescriptor();
  }
  
  public String getInternalName() {
    return ((Type)className.get()).getInternalName();
  }
  
  public String getInternalNameByState(State state) {
    return ((Type)className.getByStateSafe(state)).getInternalName();
  }
  
  public String getRuntimeInternalName() {
    return getInternalNameByState(RuntimeState.getState());
  }
  




  public ASMMethodBuilder childMethod()
  {
    return ASMBuilders.newMethodBuilder().setParentClass(this);
  }
  




  public ASMFieldBuilder childField()
  {
    return ASMBuilders.newFieldBuilder().setParentClass(this);
  }
  
  public boolean equals(Object obj)
  {
    return ((obj instanceof ASMClass)) && (Objects.equals(getName(), ((ASMClass)obj).getName()));
  }
  
  public String toString()
  {
    StringBuilder builder = new StringBuilder();
    builder.append(String.format("CLASS[states=%d]{", new Object[] { Integer.valueOf(className.getStateCount()) }));
    Iterator<State> it = Arrays.asList(State.values()).iterator();
    boolean needsSeparator = false;
    while (it.hasNext()) {
      State next = (State)it.next();
      Type type = (Type)className.getByState(next);
      if (type != null) {
        if (needsSeparator) {
          builder.append(",");
        }
        builder.append(next.name());
        builder.append("=");
        builder.append(type.getInternalName());
        needsSeparator = true;
      }
    }
    builder.append("}");
    return builder.toString();
  }
}
