package com.matt.forgehax.asm.utils.asmtype;

import com.matt.forgehax.asm.utils.environment.RuntimeState;
import com.matt.forgehax.asm.utils.environment.State;



public abstract interface IASMType
{
  public abstract String getNameByState(State paramState);
  
  public abstract String getDescriptorByState(State paramState);
  
  public String getName()
  {
    return getNameByState(State.NORMAL);
  }
  
  public String getDescriptor() {
    return getDescriptorByState(State.NORMAL);
  }
  
  public String getSrgName() {
    return getNameByState(State.SRG);
  }
  
  public String getSrgDescriptor() {
    return getDescriptorByState(State.SRG);
  }
  
  public String getObfuscatedName() {
    return getNameByState(State.OBFUSCATED);
  }
  
  public String getObfuscatedDescriptor() {
    return getDescriptorByState(State.OBFUSCATED);
  }
  
  public String getRuntimeName() {
    return getNameByState(RuntimeState.getState());
  }
  
  public String getRuntimeDescriptor() {
    return getDescriptorByState(RuntimeState.getState());
  }
}
