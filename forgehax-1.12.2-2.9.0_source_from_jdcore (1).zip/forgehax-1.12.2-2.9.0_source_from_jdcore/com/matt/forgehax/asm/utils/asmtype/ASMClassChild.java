package com.matt.forgehax.asm.utils.asmtype;

import javax.annotation.Nullable;


public abstract class ASMClassChild
  implements IASMType
{
  private final ASMClass parentClass;
  
  public ASMClassChild(@Nullable ASMClass parentClass)
  {
    this.parentClass = parentClass;
  }
  




  @Nullable
  public ASMClass getParentClass()
  {
    return parentClass;
  }
}
