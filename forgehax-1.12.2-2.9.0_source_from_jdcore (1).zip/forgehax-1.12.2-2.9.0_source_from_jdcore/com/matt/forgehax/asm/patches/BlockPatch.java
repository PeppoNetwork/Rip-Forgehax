package com.matt.forgehax.asm.patches;

import com.matt.forgehax.asm.TypesHook.Methods;
import com.matt.forgehax.asm.TypesMc.Methods;
import com.matt.forgehax.asm.utils.ASMHelper;
import com.matt.forgehax.asm.utils.asmtype.ASMMethod;
import com.matt.forgehax.asm.utils.transforming.ClassTransformer;
import com.matt.forgehax.asm.utils.transforming.Inject;
import com.matt.forgehax.asm.utils.transforming.MethodTransformer;
import com.matt.forgehax.asm.utils.transforming.RegisterMethodTransformer;
import java.util.Objects;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.LabelNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.VarInsnNode;

public class BlockPatch extends ClassTransformer
{
  public BlockPatch()
  {
    super(com.matt.forgehax.asm.TypesMc.Classes.Block);
  }
  
  @RegisterMethodTransformer
  private class CanRenderInLayer extends MethodTransformer {
    private CanRenderInLayer() {}
    
    public ASMMethod getMethod() {
      return TypesMc.Methods.Block_canRenderInLayer;
    }
    
    @Inject(description="Changes in layer code so that we can change it")
    public void inject(MethodNode main)
    {
      AbstractInsnNode node = ASMHelper.findPattern(instructions.getFirst(), new int[] { 182 }, "x");
      
      Objects.requireNonNull(node, "Find pattern failed for node");
      
      InsnList insnList = new InsnList();
      


      insnList.add(new VarInsnNode(58, 3));
      insnList.add(new VarInsnNode(25, 0));
      insnList.add(new VarInsnNode(25, 1));
      insnList.add(new VarInsnNode(25, 3));
      insnList.add(new VarInsnNode(25, 2));
      
      insnList.add(
        ASMHelper.call(184, TypesHook.Methods.ForgeHaxHooks_onRenderBlockInLayer));
      

      instructions.insert(node, insnList);
    }
  }
  
  @RegisterMethodTransformer
  private class AddCollisionBoxToList extends MethodTransformer {
    private AddCollisionBoxToList() {}
    
    public ASMMethod getMethod() {
      return TypesMc.Methods.Block_addCollisionBoxToList;
    }
    



    @Inject(description="Redirects method to our hook and allows the vanilla code to be canceled from executing", priority=com.matt.forgehax.asm.utils.transforming.InjectPriority.LOWEST)
    public void inject(MethodNode main)
    {
      AbstractInsnNode node = instructions.getFirst();
      
      AbstractInsnNode end = ASMHelper.findPattern(instructions.getFirst(), new int[] { 177 }, "x");
      
      Objects.requireNonNull(node, "Find pattern failed for node");
      Objects.requireNonNull(end, "Find pattern failed for end");
      
      LabelNode jumpPast = new LabelNode();
      
      InsnList insnList = new InsnList();
      insnList.add(new VarInsnNode(25, 0));
      insnList.add(new VarInsnNode(25, 1));
      insnList.add(new VarInsnNode(25, 2));
      insnList.add(new VarInsnNode(25, 3));
      insnList.add(new VarInsnNode(25, 4));
      insnList.add(new VarInsnNode(25, 5));
      insnList.add(new VarInsnNode(25, 6));
      insnList.add(new VarInsnNode(21, 7));
      insnList.add(
        ASMHelper.call(184, TypesHook.Methods.ForgeHaxHooks_onAddCollisionBoxToList));
      insnList.add(new org.objectweb.asm.tree.JumpInsnNode(154, jumpPast));
      
      instructions.insertBefore(end, jumpPast);
      instructions.insertBefore(node, insnList);
    }
  }
}
