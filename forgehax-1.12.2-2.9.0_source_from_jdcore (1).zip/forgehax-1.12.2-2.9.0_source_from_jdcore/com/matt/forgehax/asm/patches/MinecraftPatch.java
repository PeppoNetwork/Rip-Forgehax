package com.matt.forgehax.asm.patches;

import com.matt.forgehax.asm.TypesHook.Methods;
import com.matt.forgehax.asm.TypesMc.Methods;
import com.matt.forgehax.asm.utils.ASMHelper;
import com.matt.forgehax.asm.utils.asmtype.ASMMethod;
import com.matt.forgehax.asm.utils.transforming.Inject;
import com.matt.forgehax.asm.utils.transforming.MethodTransformer;
import com.matt.forgehax.asm.utils.transforming.RegisterMethodTransformer;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.VarInsnNode;

public class MinecraftPatch extends com.matt.forgehax.asm.utils.transforming.ClassTransformer
{
  public MinecraftPatch()
  {
    super(com.matt.forgehax.asm.TypesMc.Classes.Minecraft);
  }
  
  @RegisterMethodTransformer
  public class SetIngameFocus extends MethodTransformer {
    public SetIngameFocus() {}
    
    public ASMMethod getMethod() {
      return TypesMc.Methods.Minecraft_setIngameFocus;
    }
    
    @Inject(description="Add callback before setting leftclick timer")
    public void inject(MethodNode method)
    {
      AbstractInsnNode node = ASMHelper.findPattern(instructions
        .getFirst(), new int[] { 17, 181, 0, 0, 0, 177 }, "xx???x");
      

      java.util.Objects.requireNonNull(node, "Failed to find SIPUSH node");
      
      InsnList list = new InsnList();
      list.add(new VarInsnNode(25, 0));
      list.add(ASMHelper.call(184, TypesHook.Methods.ForgeHaxHooks_onLeftClickCounterSet));
      
      instructions.insert(node, list);
    }
  }
  
  @RegisterMethodTransformer
  public class RunTick extends MethodTransformer {
    public RunTick() {}
    
    public ASMMethod getMethod() {
      return TypesMc.Methods.Minecraft_runTick;
    }
    
    @Inject(description="Add callback before setting leftclick timer")
    public void inject(MethodNode method)
    {
      AbstractInsnNode node = ASMHelper.findPattern(instructions
        .getFirst(), new int[] { 17, 181, 0, 0, 0, 25, 180, 198, 0, 0, 25, 180, 182 }, "xx???xxx??xxx");
      















      java.util.Objects.requireNonNull(node, "Failed to find SIPUSH node");
      
      InsnList list = new InsnList();
      list.add(new VarInsnNode(25, 0));
      list.add(ASMHelper.call(184, TypesHook.Methods.ForgeHaxHooks_onLeftClickCounterSet));
      
      instructions.insert(node, list);
    }
  }
  
  @RegisterMethodTransformer
  public class SendClickBlockToController extends MethodTransformer {
    public SendClickBlockToController() {}
    
    public ASMMethod getMethod() {
      return TypesMc.Methods.Minecraft_sendClickBlockToController;
    }
    
    @Inject(description="Add hook to set left click")
    public void inject(MethodNode method) {
      InsnList list = new InsnList();
      list.add(new VarInsnNode(25, 0));
      list.add(new VarInsnNode(21, 1));
      list.add(
        ASMHelper.call(184, TypesHook.Methods.ForgeHaxHooks_onSendClickBlockToController));
      
      list.add(new VarInsnNode(54, 1));
      
      instructions.insert(list);
    }
  }
}
