package com.matt.forgehax.asm.patches;

import com.matt.forgehax.asm.TypesHook.Methods;
import com.matt.forgehax.asm.TypesMc.Methods;
import com.matt.forgehax.asm.utils.ASMHelper;
import com.matt.forgehax.asm.utils.asmtype.ASMMethod;
import com.matt.forgehax.asm.utils.transforming.ClassTransformer;
import com.matt.forgehax.asm.utils.transforming.Inject;
import java.util.Objects;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.JumpInsnNode;
import org.objectweb.asm.tree.LabelNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.VarInsnNode;

public class NetManagerPatch extends ClassTransformer
{
  public NetManagerPatch()
  {
    super(com.matt.forgehax.asm.TypesMc.Classes.NetworkManager);
  }
  
  @com.matt.forgehax.asm.utils.transforming.RegisterMethodTransformer
  private class DispatchPacket extends com.matt.forgehax.asm.utils.transforming.MethodTransformer {
    private DispatchPacket() {}
    
    public ASMMethod getMethod() {
      return TypesMc.Methods.NetworkManager_dispatchPacket;
    }
    
    @Inject(description="Add pre and post hooks that allow method to be disabled")
    public void inject(MethodNode main)
    {
      AbstractInsnNode preNode = ASMHelper.findPattern(instructions
        .getFirst(), new int[] { 25, 25, 165, 25, 193, 154, 0, 0, 25, 25, 182 }, "xxxxxx??xxx");
      














      AbstractInsnNode postNode = ASMHelper.findPattern(instructions
        .getFirst(), new int[] { 87, 0, 0, 167, 0, 0, 0, 25, 180, 185, 187, 89 }, "x??x???xxxxx");
      




      Objects.requireNonNull(preNode, "Find pattern failed for preNode");
      Objects.requireNonNull(postNode, "Find pattern failed for postNode");
      
      LabelNode endJump = new LabelNode();
      
      InsnList insnPre = new InsnList();
      insnPre.add(new VarInsnNode(25, 1));
      insnPre.add(ASMHelper.call(184, TypesHook.Methods.ForgeHaxHooks_onSendingPacket));
      insnPre.add(new JumpInsnNode(154, endJump));
      
      InsnList insnPost = new InsnList();
      insnPost.add(new VarInsnNode(25, 1));
      insnPost.add(ASMHelper.call(184, TypesHook.Methods.ForgeHaxHooks_onSentPacket));
      insnPost.add(endJump);
      
      instructions.insertBefore(preNode, insnPre);
      instructions.insert(postNode, insnPost);
    }
  }
  
  @com.matt.forgehax.asm.utils.transforming.RegisterMethodTransformer
  private class ChannelRead0 extends com.matt.forgehax.asm.utils.transforming.MethodTransformer {
    private ChannelRead0() {}
    
    public ASMMethod getMethod() {
      return TypesMc.Methods.NetworkManager_channelRead0;
    }
    
    @Inject(description="Add pre and post hook that allows the method to be disabled")
    public void inject(MethodNode main)
    {
      AbstractInsnNode preNode = ASMHelper.findPattern(instructions
        .getFirst(), new int[] { 25, 25, 180, 185 }, "xxxx");
      


      AbstractInsnNode postNode = ASMHelper.findPattern(instructions
        .getFirst(), new int[] { 185, 0, 0, 167 }, "x??x");
      




      Objects.requireNonNull(preNode, "Find pattern failed for preNode");
      Objects.requireNonNull(postNode, "Find pattern failed for postNode");
      
      LabelNode endJump = new LabelNode();
      
      InsnList insnPre = new InsnList();
      insnPre.add(new VarInsnNode(25, 2));
      insnPre.add(ASMHelper.call(184, TypesHook.Methods.ForgeHaxHooks_onPreReceived));
      insnPre.add(new JumpInsnNode(154, endJump));
      
      InsnList insnPost = new InsnList();
      insnPost.add(new VarInsnNode(25, 2));
      insnPost.add(ASMHelper.call(184, TypesHook.Methods.ForgeHaxHooks_onPostReceived));
      insnPost.add(endJump);
      
      instructions.insertBefore(preNode, insnPre);
      instructions.insert(postNode, insnPost);
    }
  }
}
