package com.matt.forgehax.asm.patches;

import com.matt.forgehax.asm.TypesHook.Methods;
import com.matt.forgehax.asm.TypesMc.Classes;
import com.matt.forgehax.asm.utils.ASMHelper;
import com.matt.forgehax.asm.utils.asmtype.ASMMethod;
import com.matt.forgehax.asm.utils.transforming.ClassTransformer;
import com.matt.forgehax.asm.utils.transforming.Inject;
import java.util.Objects;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.InsnNode;
import org.objectweb.asm.tree.IntInsnNode;
import org.objectweb.asm.tree.JumpInsnNode;
import org.objectweb.asm.tree.LabelNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.VarInsnNode;

public class BufferBuilderPatch extends ClassTransformer
{
  public BufferBuilderPatch()
  {
    super(TypesMc.Classes.BufferBuilder);
  }
  
  @com.matt.forgehax.asm.utils.transforming.RegisterMethodTransformer
  private class PutColorMultiplier extends com.matt.forgehax.asm.utils.transforming.MethodTransformer {
    private PutColorMultiplier() {}
    
    public ASMMethod getMethod() {
      return com.matt.forgehax.asm.TypesMc.Methods.BufferBuilder_putColorMultiplier;
    }
    
    @Inject(description="Add hook that allows method to be overwritten")
    public void inject(MethodNode main)
    {
      AbstractInsnNode preNode = ASMHelper.findPattern(instructions
        .getFirst(), new int[] { 184, 178, 166, 0, 0, 21, 17, 126, 134, 23, 106, 139, 54 }, "xxx??xxxxxxxx");
      
















      AbstractInsnNode postNode = ASMHelper.findPattern(instructions
        .getFirst(), new int[] { 25, 180, 21, 21, 182, 87 }, "xxxxxx");
      


      Objects.requireNonNull(preNode, "Find pattern failed for preNode");
      Objects.requireNonNull(postNode, "Find pattern failed for postNode");
      
      LabelNode endJump = new LabelNode();
      
      InsnList insnPre = new InsnList();
      insnPre.add(new InsnNode(4));
      insnPre.add(new IntInsnNode(188, 4));
      insnPre.add(new InsnNode(89));
      insnPre.add(new InsnNode(3));
      insnPre.add(new InsnNode(3));
      insnPre.add(new InsnNode(84));
      insnPre.add(new VarInsnNode(58, 10));
      insnPre.add(new VarInsnNode(23, 1));
      insnPre.add(new VarInsnNode(23, 2));
      insnPre.add(new VarInsnNode(23, 3));
      insnPre.add(new VarInsnNode(21, 6));
      insnPre.add(new VarInsnNode(25, 10));
      insnPre.add(
        ASMHelper.call(184, TypesHook.Methods.ForgeHaxHooks_onPutColorMultiplier));
      insnPre.add(new VarInsnNode(54, 6));
      insnPre.add(new VarInsnNode(25, 10));
      insnPre.add(new InsnNode(3));
      insnPre.add(new InsnNode(51));
      insnPre.add(new JumpInsnNode(154, endJump));
      
      instructions.insertBefore(preNode, insnPre);
      instructions.insertBefore(postNode, endJump);
    }
  }
}
