package com.matt.forgehax.asm.patches;

import com.matt.forgehax.asm.TypesHook.Methods;
import com.matt.forgehax.asm.TypesMc.Classes;
import com.matt.forgehax.asm.utils.ASMHelper;
import com.matt.forgehax.asm.utils.asmtype.ASMMethod;
import com.matt.forgehax.asm.utils.transforming.ClassTransformer;
import com.matt.forgehax.asm.utils.transforming.Inject;
import java.util.Objects;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.InsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.VarInsnNode;

public class EntityLivingBasePatch extends ClassTransformer
{
  public EntityLivingBasePatch()
  {
    super(TypesMc.Classes.EntityLivingBase);
  }
  
  @com.matt.forgehax.asm.utils.transforming.RegisterMethodTransformer
  public class Travel extends com.matt.forgehax.asm.utils.transforming.MethodTransformer {
    public Travel() {}
    
    public ASMMethod getMethod() {
      return com.matt.forgehax.asm.TypesMc.Methods.EntityLivingBase_travel;
    }
    

    @Inject(description="Add hook before first slippery motion calculation")
    public void injectFirst(MethodNode node)
    {
      AbstractInsnNode first = ASMHelper.findPattern(node, new int[] { 182, 18, 106, 56, 64870, 64870, 64870, 18, 23, 23, 106, 23, 106, 110, 56, 64870, 64870, 25, 180, 153 });
      





















      Objects.requireNonNull(first, "Could not find first slip motion node");
      
      InsnList list = new InsnList();
      list.add(new VarInsnNode(25, 0));
      list.add(new VarInsnNode(25, 6));
      list.add(new InsnNode(3));
      list.add(
        ASMHelper.call(184, TypesHook.Methods.ForgeHaxHooks_onEntityBlockSlipApply));
      

      instructions.insert(first, list);
    }
    

    @Inject(description="Add hook before second slippery motion calculation")
    public void injectSecond(MethodNode node)
    {
      AbstractInsnNode second = ASMHelper.findPattern(node, new int[] { 182, 18, 106, 56, 64870, 64870, 64870, 25, 182, 153, 64870, 64870, 18, 56, 64870, 64870, 25, 25, 180, 18, 18, 184, 181 });
      
























      Objects.requireNonNull(second, "Could not find second slip motion node");
      
      InsnList list = new InsnList();
      list.add(new VarInsnNode(25, 0));
      list.add(new VarInsnNode(25, 8));
      list.add(new InsnNode(4));
      list.add(
        ASMHelper.call(184, TypesHook.Methods.ForgeHaxHooks_onEntityBlockSlipApply));
      

      instructions.insert(second, list);
    }
  }
}
