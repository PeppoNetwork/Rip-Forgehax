package com.matt.forgehax.asm.patches;

import com.matt.forgehax.asm.TypesMc.Classes;
import com.matt.forgehax.asm.TypesMc.Methods;
import com.matt.forgehax.asm.utils.ASMHelper;
import com.matt.forgehax.asm.utils.asmtype.ASMMethod;
import com.matt.forgehax.asm.utils.transforming.ClassTransformer;
import com.matt.forgehax.asm.utils.transforming.Inject;
import com.matt.forgehax.asm.utils.transforming.RegisterMethodTransformer;
import java.util.Objects;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.MethodNode;

public class KeyBindingPatch extends ClassTransformer
{
  public KeyBindingPatch()
  {
    super(TypesMc.Classes.KeyBinding);
  }
  
  @RegisterMethodTransformer
  private class IsKeyDown extends com.matt.forgehax.asm.utils.transforming.MethodTransformer {
    private IsKeyDown() {}
    
    public ASMMethod getMethod() {
      return TypesMc.Methods.KeyBinding_isKeyDown;
    }
    
    @Inject(description="Shut down forge's shit for GuiMove")
    public void inject(MethodNode main)
    {
      AbstractInsnNode node = ASMHelper.findPattern(instructions
        .getFirst(), new int[] { 25, 180, 153 }, "xxx");
      
      Objects.requireNonNull(node, "Find pattern failed for getfield node");
      


      AbstractInsnNode iteratorNode = node.getNext().getNext();
      while (iteratorNode.getOpcode() != 172) {
        iteratorNode = iteratorNode.getNext();
        instructions.remove(iteratorNode.getPrevious());
      }
    }
  }
}
