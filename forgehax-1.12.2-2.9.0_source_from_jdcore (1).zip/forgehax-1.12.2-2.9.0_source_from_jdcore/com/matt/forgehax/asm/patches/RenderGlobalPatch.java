package com.matt.forgehax.asm.patches;

import com.matt.forgehax.asm.TypesHook.Methods;
import com.matt.forgehax.asm.utils.ASMHelper;
import com.matt.forgehax.asm.utils.asmtype.ASMMethod;
import com.matt.forgehax.asm.utils.transforming.Inject;
import com.matt.forgehax.asm.utils.transforming.MethodTransformer;
import java.util.Objects;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.LabelNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.VarInsnNode;

public class RenderGlobalPatch extends com.matt.forgehax.asm.utils.transforming.ClassTransformer
{
  public RenderGlobalPatch()
  {
    super(com.matt.forgehax.asm.TypesMc.Classes.RenderGlobal);
  }
  
  @com.matt.forgehax.asm.utils.transforming.RegisterMethodTransformer
  private class LoadRenderers extends MethodTransformer {
    private LoadRenderers() {}
    
    public ASMMethod getMethod() {
      return com.matt.forgehax.asm.TypesMc.Methods.RenderGlobal_loadRenderers;
    }
    
    @Inject(description="At hook callback at end of method")
    public void inject(MethodNode main)
    {
      AbstractInsnNode node = ASMHelper.findPattern(instructions
        .getFirst(), new int[] { 181, 0, 0, 0, 177 }, "x???x");
      


      Objects.requireNonNull(node, "Find pattern failed for node");
      
      InsnList insnList = new InsnList();
      insnList.add(new VarInsnNode(25, 0));
      insnList.add(ASMHelper.call(180, com.matt.forgehax.asm.TypesMc.Fields.RenderGlobal_viewFrustum));
      insnList.add(new VarInsnNode(25, 0));
      insnList.add(ASMHelper.call(180, com.matt.forgehax.asm.TypesMc.Fields.RenderGlobal_renderDispatcher));
      insnList.add(ASMHelper.call(184, TypesHook.Methods.ForgeHaxHooks_onLoadRenderers));
      
      instructions.insert(node, insnList);
    }
  }
  
  @com.matt.forgehax.asm.utils.transforming.RegisterMethodTransformer
  private class RenderBlockLayer extends MethodTransformer {
    private RenderBlockLayer() {}
    
    public ASMMethod getMethod() {
      return com.matt.forgehax.asm.TypesMc.Methods.RenderGlobal_renderBlockLayer;
    }
    
    @Inject(description="Add hooks at the top and bottom of the method")
    public void inject(MethodNode main)
    {
      AbstractInsnNode preNode = ASMHelper.findPattern(instructions
        .getFirst(), new int[] { 184, 0, 0, 25, 178, 166, 0, 0, 25, 180, 180 }, "x??xxx??xxx");
      














      AbstractInsnNode postNode = ASMHelper.findPattern(instructions
        .getFirst(), new int[] { 25, 180, 180, 182, 0, 0, 21, 172 }, "xxxx??xx");
      


      Objects.requireNonNull(preNode, "Find pattern failed for preNode");
      Objects.requireNonNull(postNode, "Find pattern failed for postNode");
      
      LabelNode endJump = new LabelNode();
      
      InsnList insnPre = new InsnList();
      insnPre.add(new org.objectweb.asm.tree.InsnNode(3));
      insnPre.add(new VarInsnNode(54, 6));
      insnPre.add(new VarInsnNode(25, 1));
      insnPre.add(new VarInsnNode(24, 2));
      insnPre.add(
        ASMHelper.call(184, TypesHook.Methods.ForgeHaxHooks_onPreRenderBlockLayer));
      insnPre.add(new org.objectweb.asm.tree.JumpInsnNode(154, endJump));
      
      InsnList insnPost = new InsnList();
      insnPost.add(new VarInsnNode(25, 1));
      insnPost.add(new VarInsnNode(24, 2));
      insnPost.add(
        ASMHelper.call(184, TypesHook.Methods.ForgeHaxHooks_onPostRenderBlockLayer));
      insnPost.add(endJump);
      
      instructions.insertBefore(preNode, insnPre);
      instructions.insertBefore(postNode, insnPost);
    }
  }
  
  @com.matt.forgehax.asm.utils.transforming.RegisterMethodTransformer
  private class SetupTerrain extends MethodTransformer {
    private SetupTerrain() {}
    
    public ASMMethod getMethod() {
      return com.matt.forgehax.asm.TypesMc.Methods.RenderGlobal_setupTerrain;
    }
    
    @Inject(description="Add hook at the top of the method")
    public void inject(MethodNode main)
    {
      AbstractInsnNode node = ASMHelper.findPattern(instructions
        .getFirst(), new int[] { 25, 180, 180, 180, 25 }, "xxxxx");
      


      Objects.requireNonNull(node, "Find pattern failed for node");
      
      InsnList insnPre = new InsnList();
      insnPre.add(new VarInsnNode(25, 1));
      insnPre.add(new VarInsnNode(21, 6));
      insnPre.add(ASMHelper.call(184, TypesHook.Methods.ForgeHaxHooks_onSetupTerrain));
      insnPre.add(new VarInsnNode(54, 6));
      
      instructions.insertBefore(node, insnPre);
    }
    

    @Inject(description="Add or logic to this.mc.renderChunksMany flag")
    public void injectAtFlag(MethodNode main)
    {
      AbstractInsnNode node = ASMHelper.findPattern(instructions
        .getFirst(), new int[] { 54, 0, 0, 25, 198, 0, 0, 3, 54, 0, 0, 187, 89, 25, 25, 1, 192, 3, 1, 183, 58 }, "x??xx??xx??xxxxxxxxxx");
      
























      Objects.requireNonNull(node, "Find pattern failed for node");
      
      LabelNode storeLabel = new LabelNode();
      LabelNode falseLabel = new LabelNode();
      
      InsnList insnList = new InsnList();
      insnList.add(new org.objectweb.asm.tree.JumpInsnNode(153, falseLabel));
      insnList.add(ASMHelper.call(184, TypesHook.Methods.ForgeHaxHooks_shouldDisableCaveCulling));
      insnList.add(new org.objectweb.asm.tree.JumpInsnNode(154, falseLabel));
      insnList.add(new org.objectweb.asm.tree.InsnNode(4));
      insnList.add(new org.objectweb.asm.tree.JumpInsnNode(167, storeLabel));
      insnList.add(falseLabel);
      insnList.add(new org.objectweb.asm.tree.InsnNode(3));
      insnList.add(storeLabel);
      

      instructions.insertBefore(node, insnList);
    }
  }
  
  @com.matt.forgehax.asm.utils.transforming.RegisterMethodTransformer
  private class DrawBoundingBox extends MethodTransformer {
    private DrawBoundingBox() {}
    
    public ASMMethod getMethod() {
      return com.matt.forgehax.asm.TypesMc.Methods.RenderGlobal_drawBoundingBox;
    }
    
    @Inject(description="Add hook at the top of the method")
    public void inject(MethodNode main) {
      AbstractInsnNode start = instructions.getFirst();
      AbstractInsnNode end = ASMHelper.findPattern(start, new int[] { 177 });
      

      int eventIndex = ASMHelper.addNewLocalVariable(main, "forgehax_event", 
        scala.tools.asm.Type.getDescriptor(com.matt.forgehax.asm.events.DrawBlockBoundingBoxEvent.Pre.class));
      
      InsnList pushArgs = new InsnList();
      pushArgs.add(new VarInsnNode(23, 12));
      pushArgs.add(new VarInsnNode(23, 13));
      pushArgs.add(new VarInsnNode(23, 14));
      pushArgs.add(new VarInsnNode(23, 15));
      

      InsnList newEvent = ASMHelper.newInstance(
        scala.tools.asm.Type.getInternalName(com.matt.forgehax.asm.events.DrawBlockBoundingBoxEvent.Pre.class), "(FFFF)V", pushArgs);
      
      InsnList pre = new InsnList();
      pre.add(newEvent);
      pre.add(new VarInsnNode(58, eventIndex));
      pre.add(new VarInsnNode(25, eventIndex));
      pre.add(ASMHelper.call(184, TypesHook.Methods.ForgeHaxHooks_fireEvent_v));
      pre.add(setColor(eventIndex, "red", 12));
      pre.add(setColor(eventIndex, "green", 13));
      pre.add(setColor(eventIndex, "blue", 14));
      pre.add(setColor(eventIndex, "alpha", 15));
      
      InsnList post = new InsnList();
      post.add(
        ASMHelper.call(184, TypesHook.Methods.ForgeHaxHooks_onDrawBoundingBox_Post));
      
      instructions.insert(start, pre);
      instructions.insertBefore(end, post);
    }
    
    private InsnList setColor(int eventIndex, String field, int colorIndex) {
      InsnList list = new InsnList();
      list.add(new VarInsnNode(25, eventIndex));
      list.add(new org.objectweb.asm.tree.FieldInsnNode(180, 
      
        scala.tools.asm.Type.getInternalName(com.matt.forgehax.asm.events.DrawBlockBoundingBoxEvent.class), field, "F"));
      list.add(new VarInsnNode(56, colorIndex));
      
      return list;
    }
  }
}
