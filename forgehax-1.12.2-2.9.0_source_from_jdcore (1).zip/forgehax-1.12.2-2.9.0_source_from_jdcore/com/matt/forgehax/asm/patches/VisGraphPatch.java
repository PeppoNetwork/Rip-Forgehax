package com.matt.forgehax.asm.patches;

import com.matt.forgehax.asm.TypesHook.Methods;
import com.matt.forgehax.asm.TypesMc.Methods;
import com.matt.forgehax.asm.utils.ASMHelper;
import com.matt.forgehax.asm.utils.asmtype.ASMMethod;
import com.matt.forgehax.asm.utils.transforming.ClassTransformer;
import com.matt.forgehax.asm.utils.transforming.Inject;
import java.util.Objects;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.JumpInsnNode;
import org.objectweb.asm.tree.LabelNode;
import org.objectweb.asm.tree.MethodNode;

public class VisGraphPatch extends ClassTransformer
{
  public VisGraphPatch()
  {
    super(com.matt.forgehax.asm.TypesMc.Classes.VisGraph);
  }
  
  @com.matt.forgehax.asm.utils.transforming.RegisterMethodTransformer
  private class SetOpaqueCube extends com.matt.forgehax.asm.utils.transforming.MethodTransformer {
    private SetOpaqueCube() {}
    
    public ASMMethod getMethod() {
      return TypesMc.Methods.VisGraph_setOpaqueCube;
    }
    
    @Inject(description="Add hook at the end that can override the return value")
    public void inject(MethodNode main) {
      AbstractInsnNode top = instructions.getFirst();
      
      AbstractInsnNode bottom = ASMHelper.findPattern(instructions.getFirst(), new int[] { 177 }, "x");
      
      Objects.requireNonNull(top, "Find pattern failed for top");
      Objects.requireNonNull(bottom, "Find pattern failed for bottom");
      
      LabelNode cancelNode = new LabelNode();
      
      InsnList insnList = new InsnList();
      insnList.add(
        ASMHelper.call(184, TypesHook.Methods.ForgeHaxHooks_shouldDisableCaveCulling));
      insnList.add(new JumpInsnNode(154, cancelNode));
      
      instructions.insertBefore(top, insnList);
      instructions.insertBefore(bottom, cancelNode);
    }
  }
  
  @com.matt.forgehax.asm.utils.transforming.RegisterMethodTransformer
  private class ComputeVisibility extends com.matt.forgehax.asm.utils.transforming.MethodTransformer {
    private ComputeVisibility() {}
    
    public ASMMethod getMethod() {
      return TypesMc.Methods.VisGraph_computeVisibility;
    }
    



    @Inject(description="Add hook that adds or logic to the jump that checks if setAllVisible(true) should be called")
    public void inject(MethodNode main)
    {
      AbstractInsnNode node = ASMHelper.findPattern(instructions.getFirst(), new int[] { 17, 162 }, "xx");
      
      Objects.requireNonNull(node, "Find pattern failed for node");
      

      JumpInsnNode greaterThanJump = (JumpInsnNode)node.getNext();
      LabelNode nextIfStatement = label;
      LabelNode orLabel = new LabelNode();
      

      instructions.remove(greaterThanJump);
      
      InsnList insnList = new InsnList();
      insnList.add(new JumpInsnNode(161, orLabel));
      insnList.add(
        ASMHelper.call(184, TypesHook.Methods.ForgeHaxHooks_shouldDisableCaveCulling));
      insnList.add(new JumpInsnNode(153, nextIfStatement));
      insnList.add(orLabel);
      
      instructions.insert(node, insnList);
    }
  }
}
