package com.matt.forgehax.asm.patches;

import com.matt.forgehax.asm.TypesHook.Fields;
import com.matt.forgehax.asm.TypesMc.Methods;
import com.matt.forgehax.asm.utils.ASMHelper;
import com.matt.forgehax.asm.utils.asmtype.ASMMethod;
import com.matt.forgehax.asm.utils.transforming.Inject;
import com.matt.forgehax.asm.utils.transforming.RegisterMethodTransformer;
import java.util.Objects;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.JumpInsnNode;
import org.objectweb.asm.tree.LabelNode;
import org.objectweb.asm.tree.MethodNode;

public class BoatPatch extends com.matt.forgehax.asm.utils.transforming.ClassTransformer
{
  public BoatPatch()
  {
    super(com.matt.forgehax.asm.TypesMc.Classes.EntityBoat);
  }
  
  @RegisterMethodTransformer
  private class UpdateMotion extends com.matt.forgehax.asm.utils.transforming.MethodTransformer {
    private UpdateMotion() {}
    
    public ASMMethod getMethod() {
      return TypesMc.Methods.EntityBoat_updateMotion;
    }
    
    @Inject(description="Add hook to disable boat gravity")
    public void inject(MethodNode main)
    {
      AbstractInsnNode gravityNode = ASMHelper.findPattern(instructions
        .getFirst(), new int[] { 25, 89, 180, 24, 99, 181 }, "xxxxxx");
      


      Objects.requireNonNull(gravityNode, "Find pattern failed for gravityNode");
      
      AbstractInsnNode putFieldNode = gravityNode;
      for (int i = 0; i < 5; i++) {
        putFieldNode = putFieldNode.getNext();
      }
      
      LabelNode newLabelNode = new LabelNode();
      
      InsnList insnList = new InsnList();
      insnList.add(
        ASMHelper.call(178, TypesHook.Fields.ForgeHaxHooks_isNoBoatGravityActivated));
      insnList.add(new JumpInsnNode(154, newLabelNode));
      
      instructions.insertBefore(gravityNode, insnList);
      instructions.insert(putFieldNode, newLabelNode);
    }
  }
  
  @RegisterMethodTransformer
  private class ControlBoat extends com.matt.forgehax.asm.utils.transforming.MethodTransformer {
    private ControlBoat() {}
    
    public ASMMethod getMethod() {
      return TypesMc.Methods.EntityBoat_controlBoat;
    }
    
    @Inject(description="Add hooks to disable boat rotation")
    public void inject(MethodNode main)
    {
      AbstractInsnNode rotationLeftNode = ASMHelper.findPattern(instructions
        .getFirst(), new int[] { 25, 89, 180, 18, 98, 181 }, "xxxxxx");
      


      AbstractInsnNode rotationRightNode = ASMHelper.findPattern(instructions
        .getFirst(), new int[] { 25, 89, 180, 12, 98, 181 }, "xxxxxx");
      


      Objects.requireNonNull(rotationLeftNode, "Find pattern failed for leftNode");
      Objects.requireNonNull(rotationRightNode, "Find pattern failed for rightNode");
      
      AbstractInsnNode putFieldNodeLeft = rotationLeftNode;
      for (int i = 0; i < 5; i++) {
        putFieldNodeLeft = putFieldNodeLeft.getNext();
      }
      
      AbstractInsnNode putFieldNodeRight = rotationRightNode;
      for (int i = 0; i < 5; i++) {
        putFieldNodeRight = putFieldNodeRight.getNext();
      }
      



      LabelNode newLabelNodeLeft = new LabelNode();
      
      InsnList insnListLeft = new InsnList();
      insnListLeft.add(
        ASMHelper.call(178, TypesHook.Fields.ForgeHaxHooks_isBoatSetYawActivated));
      insnListLeft.add(new JumpInsnNode(154, newLabelNodeLeft));
      
      instructions.insertBefore(rotationLeftNode, insnListLeft);
      instructions.insert(putFieldNodeLeft, newLabelNodeLeft);
      



      LabelNode newLabelNodeRight = new LabelNode();
      
      InsnList insnListRight = new InsnList();
      insnListRight.add(
        ASMHelper.call(178, TypesHook.Fields.ForgeHaxHooks_isBoatSetYawActivated));
      insnListRight.add(new JumpInsnNode(154, newLabelNodeRight));
      
      instructions.insertBefore(rotationRightNode, insnListRight);
      instructions.insert(putFieldNodeRight, newLabelNodeRight);
    }
  }
  
  @RegisterMethodTransformer
  private class RemoveClamp extends com.matt.forgehax.asm.utils.transforming.MethodTransformer {
    private RemoveClamp() {}
    
    public ASMMethod getMethod() {
      return TypesMc.Methods.EntityBoat_applyYawToEntity;
    }
    
    @Inject(description="Disable boat view clamping")
    public void inject(MethodNode main)
    {
      AbstractInsnNode pre = ASMHelper.findPattern(instructions
        .getFirst(), new int[] { 23, 18, 18, 184, 56 }, "xxxxx");
      

      AbstractInsnNode post = pre.getNext().getNext().getNext();
      
      Objects.requireNonNull(pre, "Find pattern failed for clamp node");
      Objects.requireNonNull(post, "Find pattern failed for clamp node post");
      
      InsnList insnList = new InsnList();
      
      LabelNode jump = new LabelNode();
      
      insnList.add(ASMHelper.call(178, TypesHook.Fields.ForgeHaxHooks_isNoClampingActivated));
      insnList.add(new JumpInsnNode(154, jump));
      
      instructions.insert(pre, insnList);
      instructions.insert(post, jump);
    }
  }
}
