package com.matt.forgehax.asm.patches.special;

import com.matt.forgehax.asm.TypesHook.Methods;
import com.matt.forgehax.asm.TypesSpecial.Classes;
import com.matt.forgehax.asm.TypesSpecial.Methods;
import com.matt.forgehax.asm.utils.ASMHelper;
import com.matt.forgehax.asm.utils.asmtype.ASMMethod;
import com.matt.forgehax.asm.utils.environment.State;
import com.matt.forgehax.asm.utils.transforming.ClassTransformer;
import com.matt.forgehax.asm.utils.transforming.Inject;
import com.matt.forgehax.asm.utils.transforming.MethodTransformer;
import com.matt.forgehax.asm.utils.transforming.RegisterMethodTransformer;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.VarInsnNode;

public class SchematicPrinterPatch
  extends ClassTransformer
{
  public SchematicPrinterPatch()
  {
    super(TypesSpecial.Classes.SchematicPrinter);
  }
  
  public State getClassObfuscationState()
  {
    return State.NORMAL;
  }
  
  @RegisterMethodTransformer
  private class PlaceBlock extends MethodTransformer {
    private PlaceBlock() {}
    
    public ASMMethod getMethod() {
      return TypesSpecial.Methods.SchematicPrinter_placeBlock;
    }
    
    @Inject(description="Add hook for schematica block placing event")
    public void inject(MethodNode main) {
      AbstractInsnNode start = instructions.getFirst();
      
      InsnList insnList = new InsnList();
      insnList.add(new VarInsnNode(25, 3));
      insnList.add(new VarInsnNode(25, 4));
      insnList.add(new VarInsnNode(25, 6));
      insnList.add(new VarInsnNode(25, 5));
      insnList.add(
        ASMHelper.call(184, TypesHook.Methods.ForgeHaxHooks_onSchematicaPlaceBlock));
      
      instructions.insertBefore(start, insnList);
    }
  }
}
