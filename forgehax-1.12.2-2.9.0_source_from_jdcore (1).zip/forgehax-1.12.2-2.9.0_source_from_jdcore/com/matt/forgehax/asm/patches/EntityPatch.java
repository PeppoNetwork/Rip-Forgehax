package com.matt.forgehax.asm.patches;

import com.matt.forgehax.asm.TypesHook.Methods;
import com.matt.forgehax.asm.TypesMc.Methods;
import com.matt.forgehax.asm.utils.ASMHelper;
import com.matt.forgehax.asm.utils.asmtype.ASMMethod;
import com.matt.forgehax.asm.utils.transforming.Inject;
import com.matt.forgehax.asm.utils.transforming.MethodTransformer;
import com.matt.forgehax.asm.utils.transforming.RegisterMethodTransformer;
import java.util.Objects;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.JumpInsnNode;
import org.objectweb.asm.tree.LabelNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.VarInsnNode;

public class EntityPatch extends com.matt.forgehax.asm.utils.transforming.ClassTransformer
{
  public EntityPatch()
  {
    super(com.matt.forgehax.asm.TypesMc.Classes.Entity);
  }
  
  @RegisterMethodTransformer
  private class ApplyEntityCollision extends MethodTransformer {
    private ApplyEntityCollision() {}
    
    public ASMMethod getMethod() {
      return TypesMc.Methods.Entity_applyEntityCollision;
    }
    
    @Inject(description="Add hook to disable push motion")
    private void inject(MethodNode main)
    {
      AbstractInsnNode thisEntityPreNode = ASMHelper.findPattern(instructions
        .getFirst(), new int[] { 25, 24, 119, 14, 24, 119, 182 }, "xxxxxxx");
      



      AbstractInsnNode thisEntityPostNode = ASMHelper.findPattern(thisEntityPreNode, new int[] { 182 }, "x");
      
      AbstractInsnNode otherEntityPreNode = ASMHelper.findPattern(thisEntityPostNode, new int[] { 25, 24, 14, 24, 182 }, "xxxxx");
      




      AbstractInsnNode otherEntityPostNode = ASMHelper.findPattern(otherEntityPreNode, new int[] { 182 }, "x");
      
      Objects.requireNonNull(thisEntityPreNode, "Find pattern failed for thisEntityPreNode");
      Objects.requireNonNull(thisEntityPostNode, "Find pattern failed for thisEntityPostNode");
      Objects.requireNonNull(otherEntityPreNode, "Find pattern failed for otherEntityPreNode");
      Objects.requireNonNull(otherEntityPostNode, "Find pattern failed for otherEntityPostNode");
      
      LabelNode endJumpForThis = new LabelNode();
      LabelNode endJumpForOther = new LabelNode();
      


      InsnList insnThisPre = new InsnList();
      insnThisPre.add(new VarInsnNode(25, 0));
      insnThisPre.add(new VarInsnNode(25, 1));
      insnThisPre.add(new VarInsnNode(24, 2));
      insnThisPre.add(new org.objectweb.asm.tree.InsnNode(119));
      insnThisPre.add(new VarInsnNode(24, 4));
      insnThisPre.add(new org.objectweb.asm.tree.InsnNode(119));
      insnThisPre.add(
        ASMHelper.call(184, TypesHook.Methods.ForgeHaxHooks_onApplyCollisionMotion));
      insnThisPre.add(new JumpInsnNode(154, endJumpForThis));
      
      InsnList insnOtherPre = new InsnList();
      insnOtherPre.add(new VarInsnNode(25, 1));
      insnOtherPre.add(new VarInsnNode(25, 0));
      insnOtherPre.add(new VarInsnNode(24, 2));
      insnOtherPre.add(new VarInsnNode(24, 4));
      insnOtherPre.add(
        ASMHelper.call(184, TypesHook.Methods.ForgeHaxHooks_onApplyCollisionMotion));
      insnOtherPre.add(new JumpInsnNode(154, endJumpForOther));
      
      instructions.insertBefore(thisEntityPreNode, insnThisPre);
      instructions.insert(thisEntityPostNode, endJumpForThis);
      
      instructions.insertBefore(otherEntityPreNode, insnOtherPre);
      instructions.insert(otherEntityPostNode, endJumpForOther);
    }
  }
  
  @RegisterMethodTransformer
  private class MoveEntity extends MethodTransformer {
    private MoveEntity() {}
    
    public ASMMethod getMethod() {
      return TypesMc.Methods.Entity_move;
    }
    
    @Inject(description="Insert flag into statement that performs sneak movement")
    public void inject(MethodNode main)
    {
      AbstractInsnNode sneakFlagNode = ASMHelper.findPattern(instructions
        .getFirst(), new int[] { 153, 25, 193, 153, 0, 0, 18, 57 }, "xxxx??xx");
      


      Objects.requireNonNull(sneakFlagNode, "Find pattern failed for sneakFlagNode");
      
      AbstractInsnNode instanceofCheck = sneakFlagNode.getNext();
      for (int i = 0; i < 3; i++) {
        instanceofCheck = instanceofCheck.getNext();
        instructions.remove(instanceofCheck.getPrevious());
      }
      

      LabelNode jumpToLabel = label;
      
      LabelNode orJump = new LabelNode();
      
      InsnList insnList = new InsnList();
      insnList.add(new JumpInsnNode(154, orJump));
      

      insnList.add(ASMHelper.call(178, com.matt.forgehax.asm.TypesHook.Fields.ForgeHaxHooks_isSafeWalkActivated));
      insnList.add(new JumpInsnNode(153, jumpToLabel));
      insnList.add(orJump);
      
      AbstractInsnNode previousNode = sneakFlagNode.getPrevious();
      instructions.remove(sneakFlagNode);
      instructions.insert(previousNode, insnList);
    }
  }
  
  @RegisterMethodTransformer
  private class DoBlockCollisions extends MethodTransformer {
    private DoBlockCollisions() {}
    
    public ASMMethod getMethod() {
      return TypesMc.Methods.Entity_doBlockCollisions;
    }
    
    @Inject(description="Add hook to disable block motion effects")
    public void inject(MethodNode main)
    {
      AbstractInsnNode preNode = ASMHelper.findPattern(instructions
        .getFirst(), new int[] { 58, 0, 0, 25, 185, 25, 180, 25, 25, 25, 182 }, "x??xxxxxxxx");
      













      AbstractInsnNode postNode = ASMHelper.findPattern(preNode, new int[] { 167 }, "x");
      
      Objects.requireNonNull(preNode, "Find pattern failed for preNode");
      Objects.requireNonNull(postNode, "Find pattern failed for postNode");
      
      LabelNode endJump = new LabelNode();
      
      InsnList insnList = new InsnList();
      insnList.add(new VarInsnNode(25, 0));
      insnList.add(new VarInsnNode(25, 8));
      insnList.add(ASMHelper.call(184, TypesHook.Methods.ForgeHaxHooks_isBlockFiltered));
      insnList.add(new JumpInsnNode(154, endJump));
      
      instructions.insertBefore(postNode, endJump);
      instructions.insert(preNode, insnList);
    }
  }
}
