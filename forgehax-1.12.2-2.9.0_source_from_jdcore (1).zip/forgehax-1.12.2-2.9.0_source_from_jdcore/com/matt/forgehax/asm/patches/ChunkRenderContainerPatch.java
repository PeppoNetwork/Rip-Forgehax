package com.matt.forgehax.asm.patches;

import com.matt.forgehax.asm.TypesHook.Methods;
import com.matt.forgehax.asm.TypesMc.Classes;
import com.matt.forgehax.asm.TypesMc.Methods;
import com.matt.forgehax.asm.utils.ASMHelper;
import com.matt.forgehax.asm.utils.asmtype.ASMMethod;
import com.matt.forgehax.asm.utils.transforming.ClassTransformer;
import com.matt.forgehax.asm.utils.transforming.Inject;
import com.matt.forgehax.asm.utils.transforming.MethodTransformer;
import com.matt.forgehax.asm.utils.transforming.RegisterMethodTransformer;
import java.util.Objects;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.VarInsnNode;

public class ChunkRenderContainerPatch extends ClassTransformer
{
  public ChunkRenderContainerPatch()
  {
    super(TypesMc.Classes.ChunkRenderContainer);
  }
  
  @RegisterMethodTransformer
  private class AddRenderChunk extends MethodTransformer {
    private AddRenderChunk() {}
    
    public ASMMethod getMethod() {
      return TypesMc.Methods.ChunkRenderContainer_addRenderChunk;
    }
    
    @Inject
    public void inject(MethodNode main) {
      AbstractInsnNode node = instructions.getFirst();
      
      Objects.requireNonNull(node, "Find pattern failed for node");
      
      InsnList insnList = new InsnList();
      insnList.add(new VarInsnNode(25, 1));
      insnList.add(new VarInsnNode(25, 2));
      insnList.add(ASMHelper.call(184, TypesHook.Methods.ForgeHaxHooks_onAddRenderChunk));
      
      instructions.insertBefore(node, insnList);
    }
  }
}
