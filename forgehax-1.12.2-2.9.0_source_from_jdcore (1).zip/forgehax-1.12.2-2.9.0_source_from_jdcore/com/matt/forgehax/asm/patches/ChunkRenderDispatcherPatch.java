package com.matt.forgehax.asm.patches;

import com.matt.forgehax.asm.TypesHook.Methods;
import com.matt.forgehax.asm.TypesMc.Classes;
import com.matt.forgehax.asm.TypesMc.Methods;
import com.matt.forgehax.asm.utils.ASMHelper;
import com.matt.forgehax.asm.utils.asmtype.ASMMethod;
import com.matt.forgehax.asm.utils.transforming.ClassTransformer;
import com.matt.forgehax.asm.utils.transforming.Inject;
import com.matt.forgehax.asm.utils.transforming.MethodTransformer;
import com.matt.forgehax.asm.utils.transforming.RegisterMethodTransformer;
import java.util.Objects;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.VarInsnNode;

public class ChunkRenderDispatcherPatch extends ClassTransformer
{
  public ChunkRenderDispatcherPatch()
  {
    super(TypesMc.Classes.ChunkRenderDispatcher);
  }
  
  @RegisterMethodTransformer
  private class UploadChunk extends MethodTransformer {
    private UploadChunk() {}
    
    public ASMMethod getMethod() {
      return TypesMc.Methods.ChunkRenderDispatcher_uploadChunk;
    }
    
    @Inject(description="Insert hook before buffer is uploaded")
    public void inject(MethodNode main)
    {
      AbstractInsnNode node = ASMHelper.findPattern(instructions
        .getFirst(), new int[] { 184, 153, 0, 0, 25 }, "xx??x");
      




      Objects.requireNonNull(node, "Find pattern failed for node");
      
      InsnList insnList = new InsnList();
      insnList.add(new VarInsnNode(25, 3));
      insnList.add(new VarInsnNode(25, 2));
      insnList.add(ASMHelper.call(184, TypesHook.Methods.ForgeHaxHooks_onChunkUploaded));
      
      instructions.insertBefore(node, insnList);
    }
  }
}
