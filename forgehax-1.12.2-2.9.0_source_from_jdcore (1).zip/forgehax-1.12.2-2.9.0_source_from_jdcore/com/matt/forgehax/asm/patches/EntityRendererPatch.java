package com.matt.forgehax.asm.patches;

import com.matt.forgehax.asm.TypesHook.Methods;
import com.matt.forgehax.asm.TypesMc.Classes;
import com.matt.forgehax.asm.utils.ASMHelper;
import com.matt.forgehax.asm.utils.asmtype.ASMMethod;
import com.matt.forgehax.asm.utils.transforming.ClassTransformer;
import com.matt.forgehax.asm.utils.transforming.Inject;
import java.util.Objects;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.JumpInsnNode;
import org.objectweb.asm.tree.LabelNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.VarInsnNode;

public class EntityRendererPatch extends ClassTransformer
{
  public EntityRendererPatch()
  {
    super(TypesMc.Classes.EntityRenderer);
  }
  
  @com.matt.forgehax.asm.utils.transforming.RegisterMethodTransformer
  private class HurtCameraEffect extends com.matt.forgehax.asm.utils.transforming.MethodTransformer {
    private HurtCameraEffect() {}
    
    public ASMMethod getMethod() {
      return com.matt.forgehax.asm.TypesMc.Methods.EntityRenderer_hurtCameraEffect;
    }
    
    @Inject(description="Add hook that allows the method to be canceled")
    public void inject(MethodNode main) {
      AbstractInsnNode preNode = instructions.getFirst();
      
      AbstractInsnNode postNode = ASMHelper.findPattern(instructions.getFirst(), new int[] { 177 }, "x");
      
      Objects.requireNonNull(preNode, "Find pattern failed for preNode");
      Objects.requireNonNull(postNode, "Find pattern failed for postNode");
      
      LabelNode endJump = new LabelNode();
      
      InsnList insnPre = new InsnList();
      insnPre.add(new VarInsnNode(23, 1));
      insnPre.add(ASMHelper.call(184, TypesHook.Methods.ForgeHaxHooks_onHurtcamEffect));
      insnPre.add(new JumpInsnNode(154, endJump));
      
      instructions.insertBefore(preNode, insnPre);
      instructions.insertBefore(postNode, endJump);
    }
  }
}
