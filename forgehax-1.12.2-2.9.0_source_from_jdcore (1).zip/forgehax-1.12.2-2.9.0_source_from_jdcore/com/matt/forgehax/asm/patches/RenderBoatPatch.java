package com.matt.forgehax.asm.patches;

import com.matt.forgehax.asm.TypesHook.Methods;
import com.matt.forgehax.asm.TypesMc.Classes;
import com.matt.forgehax.asm.TypesMc.Methods;
import com.matt.forgehax.asm.utils.ASMHelper;
import com.matt.forgehax.asm.utils.asmtype.ASMMethod;
import com.matt.forgehax.asm.utils.transforming.ClassTransformer;
import com.matt.forgehax.asm.utils.transforming.Inject;
import com.matt.forgehax.asm.utils.transforming.MethodTransformer;
import com.matt.forgehax.asm.utils.transforming.RegisterMethodTransformer;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.VarInsnNode;

public class RenderBoatPatch extends ClassTransformer
{
  public RenderBoatPatch()
  {
    super(TypesMc.Classes.RenderBoat);
  }
  
  @RegisterMethodTransformer
  private class DoRender extends MethodTransformer {
    private DoRender() {}
    
    public ASMMethod getMethod() {
      return TypesMc.Methods.RenderBoat_doRender;
    }
    
    @Inject(description="Add hook to set boat yaw when it's rendered")
    public void inject(MethodNode main)
    {
      InsnList insnList = new InsnList();
      
      insnList.add(new VarInsnNode(25, 1));
      insnList.add(new VarInsnNode(23, 8));
      insnList.add(
        ASMHelper.call(184, TypesHook.Methods.ForgeHaxHooks_onRenderBoat));
      




      insnList.add(new VarInsnNode(56, 8));
      
      instructions.insert(insnList);
    }
  }
}
