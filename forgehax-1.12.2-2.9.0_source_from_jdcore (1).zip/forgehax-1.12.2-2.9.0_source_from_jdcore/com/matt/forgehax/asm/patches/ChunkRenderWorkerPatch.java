package com.matt.forgehax.asm.patches;

import com.matt.forgehax.asm.TypesHook.Methods;
import com.matt.forgehax.asm.TypesMc.Classes;
import com.matt.forgehax.asm.TypesMc.Methods;
import com.matt.forgehax.asm.utils.ASMHelper;
import com.matt.forgehax.asm.utils.asmtype.ASMMethod;
import com.matt.forgehax.asm.utils.transforming.ClassTransformer;
import com.matt.forgehax.asm.utils.transforming.Inject;
import com.matt.forgehax.asm.utils.transforming.MethodTransformer;
import com.matt.forgehax.asm.utils.transforming.RegisterMethodTransformer;
import java.util.Objects;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.VarInsnNode;

public class ChunkRenderWorkerPatch extends ClassTransformer
{
  public ChunkRenderWorkerPatch()
  {
    super(TypesMc.Classes.ChunkRenderWorker);
  }
  
  @RegisterMethodTransformer
  private class FreeRenderBuilder extends MethodTransformer {
    private FreeRenderBuilder() {}
    
    public ASMMethod getMethod() {
      return TypesMc.Methods.ChunkRenderWorker_freeRenderBuilder;
    }
    
    @Inject(description="Add hook at the very top of the method")
    public void inject(MethodNode main) {
      AbstractInsnNode node = instructions.getFirst();
      
      Objects.requireNonNull(node, "Find pattern failed for node");
      
      InsnList insnList = new InsnList();
      insnList.add(new VarInsnNode(25, 1));
      insnList.add(
        ASMHelper.call(184, TypesHook.Methods.ForgeHaxHooks_onWorldRendererDeallocated));
      
      instructions.insertBefore(node, insnList);
    }
  }
}
