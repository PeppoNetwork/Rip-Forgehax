package com.matt.forgehax.asm.patches;

import com.matt.forgehax.asm.TypesHook.Methods;
import com.matt.forgehax.asm.TypesMc.Classes;
import com.matt.forgehax.asm.TypesMc.Methods;
import com.matt.forgehax.asm.utils.ASMHelper;
import com.matt.forgehax.asm.utils.AsmPattern;
import com.matt.forgehax.asm.utils.AsmPattern.Builder;
import com.matt.forgehax.asm.utils.InsnPattern;
import com.matt.forgehax.asm.utils.asmtype.ASMMethod;
import com.matt.forgehax.asm.utils.transforming.ClassTransformer;
import com.matt.forgehax.asm.utils.transforming.Inject;
import com.matt.forgehax.asm.utils.transforming.MethodTransformer;
import com.matt.forgehax.asm.utils.transforming.RegisterMethodTransformer;
import java.util.Objects;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.InsnNode;
import org.objectweb.asm.tree.JumpInsnNode;
import org.objectweb.asm.tree.LabelNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.VarInsnNode;

public class EntityPlayerSPPatch extends ClassTransformer
{
  public EntityPlayerSPPatch()
  {
    super(TypesMc.Classes.EntityPlayerSP);
  }
  
  @RegisterMethodTransformer
  private class ApplyLivingUpdate extends MethodTransformer {
    private ApplyLivingUpdate() {}
    
    public ASMMethod getMethod() {
      return TypesMc.Methods.EntityPlayerSP_onLivingUpdate;
    }
    
    @Inject(description="Add hook to disable the use slowdown effect")
    public void inject(MethodNode main)
    {
      AbstractInsnNode applySlowdownSpeedNode = ASMHelper.findPattern(instructions
        .getFirst(), new int[] { 154, 0, 0, 25, 180, 89, 180, 18, 106, 181 }, "x??xxxxxxx");
      


      Objects.requireNonNull(applySlowdownSpeedNode, "Find pattern failed for applySlowdownSpeedNode");
      


      LabelNode jumpTo = label;
      
      InsnList insnList = new InsnList();
      insnList.add(ASMHelper.call(178, com.matt.forgehax.asm.TypesHook.Fields.ForgeHaxHooks_isNoSlowDownActivated));
      insnList.add(new JumpInsnNode(154, jumpTo));
      
      instructions.insert(applySlowdownSpeedNode, insnList);
    }
  }
  
  @RegisterMethodTransformer
  private class OnUpdate extends MethodTransformer {
    private OnUpdate() {}
    
    public ASMMethod getMethod() {
      return TypesMc.Methods.EntityPlayerSP_onUpdate;
    }
    






    @Inject(description="Add hooks at top and bottom of method")
    public void inject(MethodNode main)
    {
      AbstractInsnNode top = new AsmPattern.Builder(7).opcodes(new int[] { 183, 25, 182, 153 }).build().test(main).getFirst();
      
      AbstractInsnNode afterRiding = ASMHelper.findPattern(main, new int[] { 167 });
      
      AbstractInsnNode afterWalking = ASMHelper.findPattern(main, new int[] { 183, 64870, 64870, 64870, 177 });
      AbstractInsnNode ret = ASMHelper.findPattern(main, new int[] { 177 });
      
      Objects.requireNonNull(top, "Find pattern failed for top node");
      Objects.requireNonNull(afterRiding, "Find pattern failed for afterRiding node");
      Objects.requireNonNull(afterWalking, "Find pattern failed for afterWalking node");
      
      LabelNode jmp = new LabelNode();
      
      InsnList pre = new InsnList();
      pre.add(new VarInsnNode(25, 0));
      pre.add(
        ASMHelper.call(184, TypesHook.Methods.ForgeHaxHooks_onUpdateWalkingPlayerPre));
      pre.add(new JumpInsnNode(154, jmp));
      
      InsnList postRiding = new InsnList();
      postRiding.add(new VarInsnNode(25, 0));
      postRiding.add(
        ASMHelper.call(184, TypesHook.Methods.ForgeHaxHooks_onUpdateWalkingPlayerPost));
      
      InsnList postWalking = new InsnList();
      postWalking.add(new VarInsnNode(25, 0));
      postWalking.add(
        ASMHelper.call(184, TypesHook.Methods.ForgeHaxHooks_onUpdateWalkingPlayerPost));
      
      instructions.insert(top, pre);
      instructions.insertBefore(afterRiding, postRiding);
      instructions.insert(afterWalking, postWalking);
      instructions.insertBefore(ret, jmp);
    }
  }
  
  @RegisterMethodTransformer
  private class pushOutOfBlocks extends MethodTransformer {
    private pushOutOfBlocks() {}
    
    public ASMMethod getMethod() {
      return TypesMc.Methods.EntityPlayerSP_pushOutOfBlocks;
    }
    
    @Inject(description="Add hook to disable pushing out of blocks")
    public void inject(MethodNode main) {
      AbstractInsnNode preNode = instructions.getFirst();
      
      AbstractInsnNode postNode = ASMHelper.findPattern(instructions.getFirst(), new int[] { 3, 172 }, "xx");
      
      Objects.requireNonNull(preNode, "Find pattern failed for pre node");
      Objects.requireNonNull(postNode, "Find pattern failed for post node");
      
      LabelNode endJump = new LabelNode();
      
      InsnList insnPre = new InsnList();
      insnPre.add(ASMHelper.call(184, TypesHook.Methods.ForgeHaxHooks_onPushOutOfBlocks));
      insnPre.add(new JumpInsnNode(154, endJump));
      
      instructions.insertBefore(preNode, insnPre);
      instructions.insertBefore(postNode, endJump);
    }
  }
  
  @RegisterMethodTransformer
  private class RowingBoat extends MethodTransformer {
    private RowingBoat() {}
    
    public ASMMethod getMethod() {
      return TypesMc.Methods.EntityPlayerSP_isRowingBoat;
    }
    
    @Inject(description="Add hook to override returned value of isRowingBoat")
    public void inject(MethodNode main) {
      AbstractInsnNode preNode = instructions.getFirst();
      
      Objects.requireNonNull(preNode, "Find pattern failed for pre node");
      
      LabelNode jump = new LabelNode();
      
      InsnList insnPre = new InsnList();
      



      insnPre.add(new InsnNode(3));
      insnPre.add(new InsnNode(172));
      

      instructions.insert(insnPre);
    }
  }
}
