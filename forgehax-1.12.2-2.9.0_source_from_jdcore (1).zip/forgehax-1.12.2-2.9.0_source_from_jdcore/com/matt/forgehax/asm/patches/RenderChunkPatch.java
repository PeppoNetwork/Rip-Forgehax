package com.matt.forgehax.asm.patches;

import com.matt.forgehax.asm.TypesHook.Methods;
import com.matt.forgehax.asm.TypesMc.Classes;
import com.matt.forgehax.asm.TypesMc.Methods;
import com.matt.forgehax.asm.utils.ASMHelper;
import com.matt.forgehax.asm.utils.asmtype.ASMMethod;
import com.matt.forgehax.asm.utils.transforming.ClassTransformer;
import com.matt.forgehax.asm.utils.transforming.Inject;
import com.matt.forgehax.asm.utils.transforming.MethodTransformer;
import com.matt.forgehax.asm.utils.transforming.RegisterMethodTransformer;
import java.util.Objects;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.FrameNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.InsnNode;
import org.objectweb.asm.tree.JumpInsnNode;
import org.objectweb.asm.tree.LabelNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.VarInsnNode;

public class RenderChunkPatch extends ClassTransformer
{
  public RenderChunkPatch()
  {
    super(TypesMc.Classes.RenderChunk);
  }
  
  @RegisterMethodTransformer
  private class RebuildChunk extends MethodTransformer {
    private RebuildChunk() {}
    
    public ASMMethod getMethod() {
      return TypesMc.Methods.RenderChunk_rebuildChunk;
    }
    

    @Inject(description="Add hooks before and after blocks are added to the buffer")
    public void inject(MethodNode main)
    {
      AbstractInsnNode top = ASMHelper.findPattern(instructions
        .getFirst(), new int[] { 178, 4, 96, 179 }, "xxxx");
      


      Objects.requireNonNull(top, "Find pattern failed for top");
      





      AbstractInsnNode loop = ASMHelper.findPattern(top, new int[] { 58, 0, 0, 25, 185, 58, 0, 0, 25, 185, 153 }, "x??xxx??xxx");
      















      Objects.requireNonNull(loop, "Find pattern failed for loop");
      

      AbstractInsnNode last = top;
      while ((last != null) && (!(last instanceof JumpInsnNode))) {
        last = last.getPrevious();
      }
      
      Objects.requireNonNull(last, "Failed to find jump node for 'last'");
      JumpInsnNode extendedLevelCheckJumpNode = (JumpInsnNode)last;
      LabelNode skipRenderingLabel = label;
      
      int STORE_AT = maxLocals++;
      

      main.visitMaxs(0, 0);
      
























      AbstractInsnNode beforeJump = extendedLevelCheckJumpNode.getPrevious();
      
      LabelNode jumpPast = new LabelNode();
      LabelNode falseNode = new LabelNode();
      
      InsnList patch = new InsnList();
      patch.add(new JumpInsnNode(154, falseNode));
      patch.add(new InsnNode(4));
      patch.add(new JumpInsnNode(167, jumpPast));
      patch.add(falseNode);
      patch.add(new FrameNode(3, 0, null, 0, null));
      patch.add(new InsnNode(3));
      patch.add(jumpPast);
      patch.add(new FrameNode(4, 0, null, 1, new Object[] { org.objectweb.asm.Opcodes.INTEGER }));
      patch.add(new InsnNode(89));
      patch.add(new VarInsnNode(54, STORE_AT));
      patch.add(new JumpInsnNode(153, skipRenderingLabel));
      
      instructions.remove(extendedLevelCheckJumpNode);
      instructions.insert(beforeJump, patch);
      

      extendedLevelCheckJumpNode = null;
      




      InsnList pre = new InsnList();
      pre.add(new VarInsnNode(25, 0));
      pre.add(ASMHelper.call(184, TypesHook.Methods.ForgeHaxHooks_onPreBuildChunk));
      
      instructions.insertBefore(top, pre);
      







      int BLOCK_STATE_INDEX = var;
      






      AbstractInsnNode prev = loop;
      while (prev.getOpcode() != 25) {
        prev = prev.getPrevious();
      }
      
      int BLOCK_POS_INDEX = var;
      


      AbstractInsnNode next2 = loop.getNext();
      while (next2.getOpcode() != 58) {
        next2 = next2.getNext();
      }
      
      int BLOCK_INDEX = var;
      


      InsnList list = new InsnList();
      list.add(new VarInsnNode(25, 0));
      list.add(new VarInsnNode(25, BLOCK_INDEX));
      list.add(new VarInsnNode(25, BLOCK_STATE_INDEX));
      list.add(new VarInsnNode(25, BLOCK_POS_INDEX));
      list.add(ASMHelper.call(184, TypesHook.Methods.ForgeHaxHooks_onBlockRenderInLoop));
      
      instructions.insert(next2, list);
      




      LabelNode jumpOver = new LabelNode();
      
      InsnList post = new InsnList();
      post.add(new FrameNode(3, 0, null, 0, null));
      post.add(new VarInsnNode(21, STORE_AT));
      post.add(new JumpInsnNode(153, jumpOver));
      post.add(new VarInsnNode(25, 0));
      post.add(ASMHelper.call(184, TypesHook.Methods.ForgeHaxHooks_onPostBuildChunk));
      post.add(jumpOver);
      
      instructions.insert(skipRenderingLabel, post);
    }
  }
  
  @RegisterMethodTransformer
  private class DeleteGlResources extends MethodTransformer {
    private DeleteGlResources() {}
    
    public ASMMethod getMethod() {
      return TypesMc.Methods.RenderChunk_deleteGlResources;
    }
    
    @Inject(description="Add hook callback at top of method")
    public void inject(MethodNode main) {
      AbstractInsnNode node = instructions.getFirst();
      
      Objects.requireNonNull(node, "Find pattern failed for node");
      
      InsnList insnList = new InsnList();
      insnList.add(new VarInsnNode(25, 0));
      insnList.add(
        ASMHelper.call(184, TypesHook.Methods.ForgeHaxHooks_onDeleteGlResources));
      
      instructions.insertBefore(node, insnList);
    }
  }
}
