package com.matt.forgehax.asm.patches;

import com.matt.forgehax.asm.TypesHook.Methods;
import com.matt.forgehax.asm.TypesMc.Methods;
import com.matt.forgehax.asm.utils.ASMHelper;
import com.matt.forgehax.asm.utils.asmtype.ASMMethod;
import com.matt.forgehax.asm.utils.transforming.ClassTransformer;
import com.matt.forgehax.asm.utils.transforming.Inject;
import com.matt.forgehax.asm.utils.transforming.RegisterMethodTransformer;
import java.util.Objects;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.InsnList;
import org.objectweb.asm.tree.JumpInsnNode;
import org.objectweb.asm.tree.LabelNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.VarInsnNode;

public class WorldPatch extends ClassTransformer
{
  public WorldPatch()
  {
    super(com.matt.forgehax.asm.TypesMc.Classes.World);
  }
  
  @RegisterMethodTransformer
  private class HandleMaterialAcceleration extends com.matt.forgehax.asm.utils.transforming.MethodTransformer {
    private HandleMaterialAcceleration() {}
    
    public ASMMethod getMethod() {
      return TypesMc.Methods.World_handleMaterialAcceleration;
    }
    
    @Inject(description="Add hook that allows water movement math to be skipped")
    public void inject(MethodNode method)
    {
      AbstractInsnNode preNode = ASMHelper.findPattern(instructions
        .getFirst(), new int[] { 25, 182, 58, 0, 0, 18, 57, 0, 0, 25, 89, 180, 25, 180, 18, 107, 99, 181 }, "xxx??xx??xxxxxxxxx");
      





















      AbstractInsnNode postNode = ASMHelper.findPattern(instructions.getFirst(), new int[] { 21, 172 }, "xx");
      
      Objects.requireNonNull(preNode, "Find pattern failed for preNode");
      Objects.requireNonNull(postNode, "Find pattern failed for postNode");
      
      LabelNode endJump = new LabelNode();
      
      InsnList insnPre = new InsnList();
      insnPre.add(new VarInsnNode(25, 3));
      insnPre.add(new VarInsnNode(25, 11));
      insnPre.add(ASMHelper.call(184, TypesHook.Methods.ForgeHaxHooks_onWaterMovement));
      insnPre.add(new JumpInsnNode(154, endJump));
      
      instructions.insertBefore(preNode, insnPre);
      instructions.insertBefore(postNode, endJump);
    }
  }
  
  @RegisterMethodTransformer
  private class CheckLightFor extends com.matt.forgehax.asm.utils.transforming.MethodTransformer {
    private CheckLightFor() {}
    
    public ASMMethod getMethod() {
      return TypesMc.Methods.World_checkLightFor;
    }
    
    @Inject(description="Add hook before everything")
    public void inject(MethodNode method) {
      AbstractInsnNode node = instructions.getFirst();
      
      Objects.requireNonNull(node, "Failed to find node.");
      
      LabelNode label = new LabelNode();
      
      InsnList list = new InsnList();
      list.add(new VarInsnNode(25, 1));
      list.add(new VarInsnNode(25, 2));
      list.add(ASMHelper.call(184, TypesHook.Methods.ForgeHaxHooks_onWorldCheckLightFor));
      list.add(new JumpInsnNode(153, label));
      list.add(new org.objectweb.asm.tree.InsnNode(3));
      list.add(new org.objectweb.asm.tree.InsnNode(172));
      list.add(label);
      
      instructions.insertBefore(node, list);
    }
  }
}
