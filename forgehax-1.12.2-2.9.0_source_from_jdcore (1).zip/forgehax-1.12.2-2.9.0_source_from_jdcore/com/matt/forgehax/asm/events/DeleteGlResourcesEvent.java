package com.matt.forgehax.asm.events;

import net.minecraft.client.renderer.chunk.RenderChunk;
import net.minecraftforge.fml.common.eventhandler.Event;


public class DeleteGlResourcesEvent
  extends Event
{
  private final RenderChunk renderChunk;
  
  public DeleteGlResourcesEvent(RenderChunk renderChunk)
  {
    this.renderChunk = renderChunk;
  }
  
  public RenderChunk getRenderChunk() {
    return renderChunk;
  }
}
