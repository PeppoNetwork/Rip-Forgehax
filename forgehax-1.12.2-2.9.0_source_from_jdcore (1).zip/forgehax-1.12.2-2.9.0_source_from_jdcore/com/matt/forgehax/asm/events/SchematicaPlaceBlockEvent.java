package com.matt.forgehax.asm.events;

import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraftforge.fml.common.eventhandler.Event;


public class SchematicaPlaceBlockEvent
  extends Event
{
  private ItemStack item;
  private BlockPos pos;
  private Vec3d vec;
  private EnumFacing side;
  
  public SchematicaPlaceBlockEvent(ItemStack itemIn, BlockPos posIn, Vec3d vecIn, EnumFacing sideIn)
  {
    item = itemIn;
    pos = posIn;
    vec = vecIn;
    side = sideIn;
  }
  
  public ItemStack getItem() {
    return item;
  }
  
  public BlockPos getPos() {
    return pos;
  }
  
  public Vec3d getVec() {
    return vec;
  }
  
  public EnumFacing getSide() {
    return side;
  }
}
