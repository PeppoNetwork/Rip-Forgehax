package com.matt.forgehax.asm.events;

import net.minecraftforge.fml.common.eventhandler.Cancelable;
import net.minecraftforge.fml.common.eventhandler.Event;

@Cancelable
public class PushOutOfBlocksEvent
  extends Event
{
  public PushOutOfBlocksEvent() {}
}
