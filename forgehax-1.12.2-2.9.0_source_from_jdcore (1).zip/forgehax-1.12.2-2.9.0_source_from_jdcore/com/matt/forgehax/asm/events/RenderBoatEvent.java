package com.matt.forgehax.asm.events;

import net.minecraft.entity.item.EntityBoat;
import net.minecraftforge.fml.common.eventhandler.Cancelable;
import net.minecraftforge.fml.common.eventhandler.Event;


@Cancelable
public class RenderBoatEvent
  extends Event
{
  private float yaw;
  private EntityBoat boat;
  
  public RenderBoatEvent(EntityBoat boatIn, float entityYaw)
  {
    boat = boatIn;
    yaw = entityYaw;
  }
  
  public void setYaw(float yawIn) {
    yaw = yawIn;
  }
  
  public float getYaw() {
    return yaw;
  }
  
  public EntityBoat getBoat() {
    return boat;
  }
}
