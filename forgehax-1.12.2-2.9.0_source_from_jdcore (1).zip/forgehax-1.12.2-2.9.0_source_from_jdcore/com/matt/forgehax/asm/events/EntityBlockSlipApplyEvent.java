package com.matt.forgehax.asm.events;

import net.minecraft.block.state.IBlockState;

public class EntityBlockSlipApplyEvent extends net.minecraftforge.fml.common.eventhandler.Event {
  private final Stage stage;
  private final net.minecraft.entity.EntityLivingBase entityLivingBase;
  
  public static enum Stage {
    FIRST, 
    SECOND;
    

    private Stage() {}
  }
  

  private final IBlockState blockStateUnder;
  
  private final float defaultSlipperiness;
  
  private float slipperiness;
  
  public EntityBlockSlipApplyEvent(Stage stage, net.minecraft.entity.EntityLivingBase entityLivingBase, IBlockState blockStateUnder, float defaultSlipperiness)
  {
    this.stage = stage;
    this.entityLivingBase = entityLivingBase;
    this.blockStateUnder = blockStateUnder;
    this.defaultSlipperiness = defaultSlipperiness;
    slipperiness = defaultSlipperiness;
  }
  
  public Stage getStage() {
    return stage;
  }
  
  public net.minecraft.entity.EntityLivingBase getEntityLivingBase() {
    return entityLivingBase;
  }
  
  public IBlockState getBlockStateUnder() {
    return blockStateUnder;
  }
  
  public float getDefaultSlipperiness() {
    return defaultSlipperiness;
  }
  
  public float getSlipperiness() {
    return slipperiness;
  }
  
  public void setSlipperiness(float slipperiness) {
    this.slipperiness = slipperiness;
  }
}
