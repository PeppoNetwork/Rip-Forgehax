package com.matt.forgehax.asm.events.listeners;

import com.google.common.collect.Sets;
import java.util.Collection;


public class ListenerObject<E>
{
  public ListenerObject() {}
  
  private Collection<E> listeners = Sets.newConcurrentHashSet();
  
  public void register(E listener) {
    listeners.add(listener);
  }
  
  public void unregister(E listener) {
    listeners.remove(listener);
  }
  
  public Collection<E> getAll() {
    return listeners;
  }
}
