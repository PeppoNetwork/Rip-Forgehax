package com.matt.forgehax.asm.events.listeners;

import net.minecraft.block.Block;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.renderer.chunk.RenderChunk;
import net.minecraft.util.math.BlockPos;

public abstract interface BlockModelRenderListener
  extends ListenerHook
{
  public abstract void onBlockRenderInLoop(RenderChunk paramRenderChunk, Block paramBlock, IBlockState paramIBlockState, BlockPos paramBlockPos);
}
