package com.matt.forgehax.asm.events.listeners;

public abstract interface ListenerHook {}
