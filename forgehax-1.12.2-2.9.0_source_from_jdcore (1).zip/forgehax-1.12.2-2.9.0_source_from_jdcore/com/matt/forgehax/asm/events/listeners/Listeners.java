package com.matt.forgehax.asm.events.listeners;




public abstract interface Listeners
{
  public static final ListenerObject<BlockModelRenderListener> BLOCK_MODEL_RENDER_LISTENER = new ListenerObject();
}
