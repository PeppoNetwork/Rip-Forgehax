package com.matt.forgehax.asm.events;

import net.minecraftforge.fml.common.eventhandler.Cancelable;

@Cancelable
public class HurtCamEffectEvent extends net.minecraftforge.fml.common.eventhandler.Event
{
  private final float partialTicks;
  
  public HurtCamEffectEvent(float pt)
  {
    partialTicks = pt;
  }
  
  public float getPartialTicks() {
    return partialTicks;
  }
}
