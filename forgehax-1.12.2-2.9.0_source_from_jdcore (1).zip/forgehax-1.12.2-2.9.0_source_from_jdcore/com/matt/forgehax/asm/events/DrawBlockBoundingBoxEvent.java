package com.matt.forgehax.asm.events;

import net.minecraftforge.fml.common.eventhandler.Event;

public class DrawBlockBoundingBoxEvent extends Event
{
  public float red;
  public float green;
  public float blue;
  public float alpha;
  
  public DrawBlockBoundingBoxEvent(float r, float g, float b, float a) {
    red = r;
    green = g;
    blue = b;
    alpha = a;
  }
  
  public static class Post extends Event { public Post() {}
  }
  
  public static class Pre extends DrawBlockBoundingBoxEvent { public Pre(float r, float g, float b, float a) { super(g, b, a); }
  }
}
