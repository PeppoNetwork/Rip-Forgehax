package com.matt.forgehax.asm.events;

import com.matt.forgehax.asm.reflection.FastReflection.Fields;
import net.minecraft.client.Minecraft;
import net.minecraftforge.fml.common.eventhandler.Cancelable;

@Cancelable
public class LeftClickCounterUpdateEvent extends net.minecraftforge.fml.common.eventhandler.Event
{
  private final Minecraft minecraft;
  private int value;
  
  public LeftClickCounterUpdateEvent(Minecraft minecraft, int value)
  {
    this.minecraft = minecraft;
    this.value = value;
  }
  
  public Minecraft getMinecraft() {
    return minecraft;
  }
  
  public int getCurrentValue() {
    return ((Integer)FastReflection.Fields.Minecraft_leftClickCounter.get(minecraft)).intValue();
  }
  
  public int getValue() {
    return value;
  }
  
  public void setValue(int value) {
    this.value = value;
  }
}
