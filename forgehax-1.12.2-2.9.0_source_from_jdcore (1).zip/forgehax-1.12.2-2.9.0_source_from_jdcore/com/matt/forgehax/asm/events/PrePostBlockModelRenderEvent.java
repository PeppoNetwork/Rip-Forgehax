package com.matt.forgehax.asm.events;

import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.chunk.RenderChunk;

public class PrePostBlockModelRenderEvent extends net.minecraftforge.fml.common.eventhandler.Event
{
  private final RenderChunk renderChunk;
  private final BufferBuilder buffer;
  private final net.minecraft.util.math.Vec3d pos;
  private final State state;
  
  public static enum State
  {
    PRE, 
    POST;
    



    private State() {}
  }
  


  public PrePostBlockModelRenderEvent(RenderChunk renderChunk, BufferBuilder BufferBuilder, State state, net.minecraft.util.math.Vec3d pos)
  {
    this.renderChunk = renderChunk;
    buffer = BufferBuilder;
    this.state = state;
    this.pos = pos;
  }
  
  public PrePostBlockModelRenderEvent(RenderChunk renderChunk, BufferBuilder BufferBuilder, State state, net.minecraft.util.math.BlockPos pos)
  {
    this(renderChunk, BufferBuilder, state, new net.minecraft.util.math.Vec3d(pos.func_177958_n(), pos.func_177956_o(), pos.func_177952_p()));
  }
  





  public PrePostBlockModelRenderEvent(RenderChunk renderChunk, BufferBuilder BufferBuilder, State state, float x, float y, float z)
  {
    this(renderChunk, BufferBuilder, state, new net.minecraft.util.math.Vec3d(x, y, z));
  }
  
  public RenderChunk getRenderChunk() {
    return renderChunk;
  }
  
  public BufferBuilder getBuffer() {
    return buffer;
  }
  
  public State getState() {
    return state;
  }
  
  public net.minecraft.util.math.Vec3d getPos() {
    return pos;
  }
}
