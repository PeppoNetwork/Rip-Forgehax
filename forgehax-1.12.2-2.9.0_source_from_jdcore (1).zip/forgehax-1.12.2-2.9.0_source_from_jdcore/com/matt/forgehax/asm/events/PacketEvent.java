package com.matt.forgehax.asm.events;

import net.minecraft.network.Packet;
import net.minecraftforge.fml.common.eventhandler.Cancelable;

public class PacketEvent extends net.minecraftforge.fml.common.eventhandler.Event
{
  private final Packet<?> packet;
  
  public PacketEvent(Packet<?> packetIn)
  {
    packet = packetIn;
  }
  
  public <T extends Packet<?>> T getPacket() {
    return packet;
  }
  
  public static class Outgoing extends PacketEvent
  {
    public Outgoing(Packet<?> packetIn) {
      super();
    }
    
    @Cancelable
    public static class Pre extends PacketEvent.Outgoing
    {
      public Pre(Packet<?> packetIn) {
        super();
      }
    }
    
    public static class Post extends PacketEvent.Outgoing
    {
      public Post(Packet<?> packetIn) {
        super();
      }
    }
  }
  
  public static class Incoming extends PacketEvent
  {
    public Incoming(Packet<?> packetIn) {
      super();
    }
    
    @Cancelable
    public static class Pre extends PacketEvent.Incoming
    {
      public Pre(Packet<?> packetIn) {
        super();
      }
    }
    
    public static class Post extends PacketEvent.Incoming
    {
      public Post(Packet<?> packetIn) {
        super();
      }
    }
  }
}
