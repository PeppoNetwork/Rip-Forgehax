package com.matt.forgehax.asm;

import com.matt.forgehax.asm.utils.asmtype.ASMClass;
import com.matt.forgehax.asm.utils.asmtype.ASMMethod;
import com.matt.forgehax.asm.utils.asmtype.builders.ASMBuilders;
import com.matt.forgehax.asm.utils.asmtype.builders.ASMClassBuilder;
import com.matt.forgehax.asm.utils.asmtype.builders.ASMMethodBuilder;
import com.matt.forgehax.asm.utils.asmtype.builders.ParameterBuilder;


public abstract interface TypesSpecial
{
  public static abstract interface Classes
  {
    public static final ASMClass SchematicPrinter = ASMBuilders.newClassBuilder()
      .setClassName("com/github/lunatrius/schematica/client/printer/SchematicPrinter")
      .build();
  }
  

  public static abstract interface Fields {}
  

  public static abstract interface Methods
  {
    public static final ASMMethod SchematicPrinter_placeBlock = TypesSpecial.Classes.SchematicPrinter
      .childMethod()
      .setName("placeBlock")
      .setReturnType(Boolean.TYPE)
      .beginParameters()
      .unobfuscated()
      .add(TypesMc.Classes.WorldClient)
      .add(TypesMc.Classes.EntityPlayerSP)
      .add(TypesMc.Classes.ItemStack)
      .add(TypesMc.Classes.BlockPos)
      .add(TypesMc.Classes.EnumFacing)
      .add(TypesMc.Classes.Vec3d)
      .add(TypesMc.Classes.EnumHand)
      .finish()
      .build();
  }
}
