package com.matt.forgehax.asm.reflection;

import com.google.common.collect.BiMap;
import com.matt.forgehax.asm.utils.fasttype.FastField;
import com.matt.forgehax.asm.utils.fasttype.FastTypeBuilder;
import java.util.Map;
import net.minecraftforge.fml.common.asm.transformers.deobf.FMLDeobfuscatingRemapper;











public abstract interface FastReflectionForge
{
  public static abstract interface Fields
  {
    public static final FastField<BiMap<String, String>> FMLDeobfuscatingRemapper_classNameBiMap = FastTypeBuilder.create()
      .setInsideClass(FMLDeobfuscatingRemapper.class)
      .setName("classNameBiMap")
      .asField();
    

    public static final FastField<Map<String, Map<String, String>>> FMLDeobfuscatingRemapper_rawFieldMaps = FastTypeBuilder.create()
      .setInsideClass(FMLDeobfuscatingRemapper.class)
      .setName("rawFieldMaps")
      .asField();
    
    public static final FastField<Map<String, Map<String, String>>> FMLDeobfuscatingRemapper_rawMethodMaps = FastTypeBuilder.create()
      .setInsideClass(FMLDeobfuscatingRemapper.class)
      .setName("rawMethodMaps")
      .asField();
    
    public static final FastField<Map<String, Map<String, String>>> FMLDeobfuscatingRemapper_fieldNameMaps = FastTypeBuilder.create()
      .setInsideClass(FMLDeobfuscatingRemapper.class)
      .setName("fieldNameMaps")
      .asField();
    
    public static final FastField<Map<String, Map<String, String>>> FMLDeobfuscatingRemapper_methodNameMaps = FastTypeBuilder.create()
      .setInsideClass(FMLDeobfuscatingRemapper.class)
      .setName("methodNameMaps")
      .asField();
  }
}
