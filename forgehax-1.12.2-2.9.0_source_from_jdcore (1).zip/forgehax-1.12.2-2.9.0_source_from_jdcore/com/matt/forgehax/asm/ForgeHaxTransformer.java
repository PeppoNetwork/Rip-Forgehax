package com.matt.forgehax.asm;

import com.matt.forgehax.asm.patches.BlockPatch;
import com.matt.forgehax.asm.patches.BoatPatch;
import com.matt.forgehax.asm.patches.BufferBuilderPatch;
import com.matt.forgehax.asm.patches.ChunkRenderContainerPatch;
import com.matt.forgehax.asm.patches.ChunkRenderDispatcherPatch;
import com.matt.forgehax.asm.patches.ChunkRenderWorkerPatch;
import com.matt.forgehax.asm.patches.EntityLivingBasePatch;
import com.matt.forgehax.asm.patches.EntityPatch;
import com.matt.forgehax.asm.patches.EntityPlayerSPPatch;
import com.matt.forgehax.asm.patches.EntityRendererPatch;
import com.matt.forgehax.asm.patches.KeyBindingPatch;
import com.matt.forgehax.asm.patches.MinecraftPatch;
import com.matt.forgehax.asm.patches.NetManager.4Patch;
import com.matt.forgehax.asm.patches.NetManagerPatch;
import com.matt.forgehax.asm.patches.PlayerControllerMCPatch;
import com.matt.forgehax.asm.patches.PlayerTabOverlayPatch;
import com.matt.forgehax.asm.patches.RenderBoatPatch;
import com.matt.forgehax.asm.patches.RenderChunkPatch;
import com.matt.forgehax.asm.patches.RenderGlobalPatch;
import com.matt.forgehax.asm.patches.VisGraphPatch;
import com.matt.forgehax.asm.patches.WorldPatch;
import com.matt.forgehax.asm.patches.special.SchematicPrinterPatch;
import com.matt.forgehax.asm.utils.ASMStackLogger;
import com.matt.forgehax.asm.utils.asmtype.ASMClass;
import com.matt.forgehax.asm.utils.transforming.ClassTransformer;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;
import javax.annotation.Resource;
import net.minecraft.launchwrapper.IClassTransformer;
import net.minecraftforge.fml.relauncher.IFMLLoadingPlugin.SortingIndex;
import org.apache.logging.log4j.Logger;
import org.objectweb.asm.ClassReader;
import org.objectweb.asm.ClassWriter;
import org.objectweb.asm.tree.ClassNode;

@Resource
@IFMLLoadingPlugin.SortingIndex(1001)
public class ForgeHaxTransformer implements IClassTransformer, ASMCommon
{
  private HashMap<String, ClassTransformer> transformingClasses = new HashMap();
  private int transformingLevel = 0;
  
  public ForgeHaxTransformer()
  {
    registerTransformer(new BlockPatch());
    registerTransformer(new ChunkRenderContainerPatch());
    registerTransformer(new ChunkRenderDispatcherPatch());
    registerTransformer(new ChunkRenderWorkerPatch());
    registerTransformer(new EntityLivingBasePatch());
    registerTransformer(new EntityPatch());
    registerTransformer(new EntityPlayerSPPatch());
    registerTransformer(new EntityRendererPatch());
    registerTransformer(new MinecraftPatch());
    registerTransformer(new NetManagerPatch());
    registerTransformer(new NetManager.4Patch());
    registerTransformer(new PlayerControllerMCPatch());
    registerTransformer(new RenderChunkPatch());
    registerTransformer(new RenderGlobalPatch());
    registerTransformer(new BufferBuilderPatch());
    registerTransformer(new VisGraphPatch());
    registerTransformer(new WorldPatch());
    

    registerTransformer(new BoatPatch());
    registerTransformer(new RenderBoatPatch());
    registerTransformer(new PlayerTabOverlayPatch());
    registerTransformer(new KeyBindingPatch());
    registerTransformer(new SchematicPrinterPatch());
    


    try
    {
      int count = addExcludedTransformersToMixin(new String[] { ForgeHaxTransformer.class.getName() });
      LOGGER.info("ForgeHax transformer exclusions successfully added into {} phases", Integer.valueOf(count));
    } catch (MixinMissingException e) {
      LOGGER.info("Mixin not detected running, skipped adding transformer exclusions");


    }
    catch (NullPointerException|ClassNotFoundException|NoSuchFieldException|IllegalAccessException|NoSuchMethodException|InvocationTargetException e)
    {

      LOGGER.info("Failed to add ForgeHax transformer exclusion into Mixin environment");
      ASMStackLogger.printStackTrace(e);
    }
  }
  
  private void registerTransformer(ClassTransformer transformer) {
    transformingClasses.put(transformer.getTransformingClassName(), transformer);
  }
  
  public byte[] transform(String name, String realName, byte[] bytes)
  {
    if (transformingLevel > 0) {
      LOGGER.warn("Reentrant class loaded {} at level {}", realName, Integer.valueOf(transformingLevel));
    }
    
    transformingLevel += 1;
    if (transformingClasses.containsKey(realName)) {
      ClassTransformer transformer = (ClassTransformer)transformingClasses.get(realName);
      try {
        LOGGER.info("Transforming class " + realName);
        
        ClassNode classNode = new ClassNode();
        ClassReader classReader = new ClassReader(bytes);
        classReader.accept(classNode, 0);
        
        transformer.transform(classNode);
        
        ClassWriter classWriter = new NoClassLoadingClassWriter(3);
        

        classNode.accept(classWriter);
        

        transformingClasses.remove(realName);
        
        bytes = classWriter.toByteArray();
      } catch (Exception e) {
        LOGGER.error(e
          .getClass().getSimpleName() + " thrown from transforming class " + realName + ": " + e
          


          .getMessage());
        ASMStackLogger.printStackTrace(e);
      }
    }
    
    transformingLevel -= 1;
    return bytes;
  }
  






  private static int addExcludedTransformersToMixin(String... excludedTransformers)
    throws ForgeHaxTransformer.MixinMissingException, NullPointerException, ClassNotFoundException, NoSuchFieldException, IllegalAccessException, NoSuchMethodException, InvocationTargetException
  {
    try
    {
      class_MixinEnvironment = Class.forName("org.spongepowered.asm.mixin.MixinEnvironment");
    } catch (ClassNotFoundException e) { Class<?> class_MixinEnvironment;
      throw new MixinMissingException(null);
    }
    Class<?> class_MixinEnvironment;
    int count = 0;
    

    Method method_addTransformerExclusion = class_MixinEnvironment.getDeclaredMethod("addTransformerExclusion", new Class[] { String.class });
    method_addTransformerExclusion.setAccessible(true);
    


    Class<?> class_MixinEnvironment$Phase = Class.forName("org.spongepowered.asm.mixin.MixinEnvironment$Phase");
    

    Field field_phases = class_MixinEnvironment$Phase.getDeclaredField("phases");
    field_phases.setAccessible(true);
    

    Method method_getEnvironment = class_MixinEnvironment$Phase.getDeclaredMethod("getEnvironment", new Class[0]);
    method_getEnvironment.setAccessible(true);
    

    List<Object> phases = (List)field_phases.get(null);
    Objects.requireNonNull(phases, "phases instance is null!");
    
    for (Object phase : phases)
    {
      Object instance;
      try {
        instance = method_getEnvironment.invoke(phase, new Object[0]);
      }
      catch (IllegalArgumentException e) {}
      continue;
      Object instance;
      Objects.requireNonNull(instance, "MixinEnvironment$Phase::getEnvironment returned null!");
      
      for (String className : excludedTransformers) {
        method_addTransformerExclusion.invoke(instance, new Object[] { className });
        count++;
      }
    }
    
    return count;
  }
  
  private static class MixinMissingException extends Exception { private MixinMissingException() {}
  }
  
  private class NoClassLoadingClassWriter extends ClassWriter { NoClassLoadingClassWriter(int flags) { super(); }
    

    protected String getCommonSuperClass(String type1, String type2)
    {
      if (type1.matches(TypesMc.Classes.GuiMainMenu.getRuntimeInternalName())) {
        return TypesMc.Classes.GuiScreen.getRuntimeInternalName();
      }
      return "java/lang/Object";
    }
  }
}
