package com.matt.forgehax.asm;

import com.matt.forgehax.asm.utils.environment.IStateMapper;
import com.matt.forgehax.asm.utils.environment.RuntimeState;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;




public abstract interface ASMCommon
{
  public static final Logger LOGGER = LogManager.getLogger("ForgeHaxASM");
  public static final IStateMapper MAPPER = RuntimeState.getMapper();
}
