package com.matt.forgehax.asm;

import com.matt.forgehax.asm.utils.environment.RuntimeState;
import java.util.Map;

public class ForgeHaxCoreMod implements net.minecraftforge.fml.relauncher.IFMLLoadingPlugin, ASMCommon
{
  public ForgeHaxCoreMod() {}
  
  public String[] getASMTransformerClass()
  {
    return new String[] { ForgeHaxTransformer.class.getName() };
  }
  
  public String getModContainerClass()
  {
    return null;
  }
  
  public String getSetupClass()
  {
    return null;
  }
  
  public void injectData(Map<String, Object> data)
  {
    if (data.containsKey("runtimeDeobfuscationEnabled")) {
      try {
        Boolean isObfuscated = (Boolean)data.get("runtimeDeobfuscationEnabled");
        if (isObfuscated.booleanValue()) {
          RuntimeState.markDefaultAsObfuscated();
        } else {
          RuntimeState.markDefaultAsNormal();
        }
      }
      catch (Exception e) {
        LOGGER.error("Failed to obtain runtimeDeobfuscationEnabled: " + e.getMessage());
        com.matt.forgehax.asm.utils.ASMStackLogger.printStackTrace(e);
      }
    }
  }
  
  public String getAccessTransformerClass()
  {
    return null;
  }
}
