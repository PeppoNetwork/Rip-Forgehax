package bspkrs.mmv;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;






























public class SrgFile
{
  public final Map<String, ClassSrgData> srgClassName2ClassData = new TreeMap();
  
  public final Map<String, Set<ClassSrgData>> srgPkg2ClassDataSet = new TreeMap();
  
  public final Map<String, FieldSrgData> srgFieldName2FieldData = new TreeMap();
  
  public final Map<String, MethodSrgData> srgMethodName2MethodData = new TreeMap();
  
  public final Map<ClassSrgData, Set<MethodSrgData>> class2MethodDataSet = new TreeMap();
  
  public final Map<ClassSrgData, Set<FieldSrgData>> class2FieldDataSet = new TreeMap();
  
  public final Map<String, ClassSrgData> srgMethodName2ClassData = new TreeMap();
  
  public final Map<String, ClassSrgData> srgFieldName2ClassData = new TreeMap();
  
  public static String getLastComponent(String s)
  {
    String[] parts = s.split("/");
    return parts[(parts.length - 1)];
  }
  
  public SrgFile(File f, ExcFile excFile, StaticMethodsFile staticMethods) throws IOException {
    Scanner in = new Scanner(new BufferedReader(new FileReader(f)));
    try {
      while (in.hasNextLine()) {
        if (in.hasNext("CL:"))
        {
          in.next();
          String obf = in.next();
          String deobf = in.next();
          String srgName = getLastComponent(deobf);
          String pkgName = deobf.substring(0, deobf.lastIndexOf('/'));
          
          ClassSrgData classData = new ClassSrgData(obf, srgName, pkgName, in.hasNext("#C"));
          
          if (!srgPkg2ClassDataSet.containsKey(pkgName)) {
            srgPkg2ClassDataSet.put(pkgName, new TreeSet());
          }
          ((Set)srgPkg2ClassDataSet.get(pkgName)).add(classData);
          
          srgClassName2ClassData.put(pkgName + "/" + srgName, classData);
          
          if (!class2MethodDataSet.containsKey(classData)) {
            class2MethodDataSet.put(classData, new TreeSet());
          }
          
          if (!class2FieldDataSet.containsKey(classData)) {
            class2FieldDataSet.put(classData, new TreeSet());
          }
        } else if (in.hasNext("FD:"))
        {
          in.next();
          String[] obf = in.next().split("/");
          String obfOwner = obf[0];
          String obfName = obf[1];
          String deobf = in.next();
          String srgName = getLastComponent(deobf);
          String srgPkg = deobf.substring(0, deobf.lastIndexOf('/'));
          String srgOwner = getLastComponent(srgPkg);
          srgPkg = srgPkg.substring(0, srgPkg.lastIndexOf('/'));
          

          FieldSrgData fieldData = new FieldSrgData(obfOwner, obfName, srgOwner, srgPkg, srgName, in.hasNext("#C"));
          
          srgFieldName2FieldData.put(srgName, fieldData);
          
          ((Set)class2FieldDataSet.get(srgClassName2ClassData.get(srgPkg + "/" + srgOwner)))
            .add(fieldData);
          srgFieldName2ClassData.put(srgName, srgClassName2ClassData.get(srgPkg + "/" + srgOwner));
        } else if (in.hasNext("MD:"))
        {

          in.next();
          String[] obf = in.next().split("/");
          String obfOwner = obf[0];
          String obfName = obf[1];
          String obfDescriptor = in.next();
          String deobf = in.next();
          String srgName = getLastComponent(deobf);
          String srgPkg = deobf.substring(0, deobf.lastIndexOf('/'));
          String srgOwner = getLastComponent(srgPkg);
          srgPkg = srgPkg.substring(0, srgPkg.lastIndexOf('/'));
          String srgDescriptor = in.next();
          









          MethodSrgData methodData = new MethodSrgData(obfOwner, obfName, obfDescriptor, srgOwner, srgPkg, srgName, srgDescriptor, in.hasNext("#C"));
          
          srgMethodName2MethodData.put(srgName, methodData);
          
          ((Set)class2MethodDataSet.get(srgClassName2ClassData.get(srgPkg + "/" + srgOwner)))
            .add(methodData);
          srgMethodName2ClassData.put(srgName, srgClassName2ClassData.get(srgPkg + "/" + srgOwner));
          



          ExcData toAdd = new ExcData(srgOwner, srgName, srgDescriptor, new String[0], staticMethods.contains(srgName));
          ExcData existing = (ExcData)srgMethodName2ExcData.get(srgName);
          
          if ((existing == null) || 
            (existing.getParameters().length < toAdd.getParameters().length)) {
            srgMethodName2ExcData.put(srgName, toAdd);
            for (String parameter : toAdd.getParameters()) {
              srgParamName2ExcData.put(parameter, toAdd);
            }
          }
        } else {
          in.nextLine();
        }
      }
    } finally {
      in.close();
    }
  }
}
