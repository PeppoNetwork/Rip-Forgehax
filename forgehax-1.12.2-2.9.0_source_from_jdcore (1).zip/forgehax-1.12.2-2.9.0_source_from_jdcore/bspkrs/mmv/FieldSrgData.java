package bspkrs.mmv;






























public class FieldSrgData
  extends MemberSrgData
  implements Comparable<FieldSrgData>
{
  public FieldSrgData(String obfOwner, String obfName, String srgOwner, String srgPkg, String srgName, boolean isClientOnly)
  {
    super(obfOwner, obfName, srgOwner, srgPkg, srgName, isClientOnly);
  }
  
  public int compareTo(FieldSrgData o)
  {
    if (o != null) {
      return getSrgName().compareTo(o.getSrgName());
    }
    return 1;
  }
}
