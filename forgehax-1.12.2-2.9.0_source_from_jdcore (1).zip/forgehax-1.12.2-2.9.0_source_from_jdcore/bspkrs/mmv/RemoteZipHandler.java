package bspkrs.mmv;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.security.DigestException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;



























public class RemoteZipHandler
{
  private static final String MMV_VERSION = "1.0.1";
  private final URL zipUrl;
  private final URL digestUrl;
  private final File localDir;
  private final String digestType;
  private final String zipFileName;
  
  public RemoteZipHandler(String urlString, File dir, String digestType)
    throws MalformedURLException
  {
    zipUrl = new URL(urlString);
    if (digestType != null) {
      digestUrl = new URL(urlString + "." + digestType.toLowerCase());
    } else {
      digestUrl = null;
    }
    String[] tokens = urlString.split("/");
    zipFileName = tokens[(tokens.length - 1)];
    localDir = dir;
    this.digestType = digestType;
  }
  
  public void checkRemoteZip() throws IOException, NoSuchAlgorithmException, DigestException
  {
    boolean fetchZip = true;
    String remoteHash = null;
    File digestFile = null;
    if (digestType != null)
    {
      remoteHash = loadTextFromURL(digestUrl, new String[] { "" })[0];
      if (!remoteHash.isEmpty()) {
        digestFile = new File(localDir, zipFileName + "." + digestType.toLowerCase());
        

        if (digestFile.exists()) {
          String existingHash = loadTextFromFile(digestFile, new String[] { "" })[0];
          if ((!existingHash.isEmpty()) && (remoteHash.equals(existingHash))) {
            fetchZip = false;
          }
        }
      }
    }
    
    if (fetchZip)
    {
      File localZip = new File(localDir, zipFileName);
      if (localZip.exists()) {
        localZip.delete();
      }
      OutputStream output = new FileOutputStream(localZip);
      try {
        URLConnection uc = zipUrl.openConnection();
        uc.addRequestProperty("User-Agent", "MMV/1.0.1");
        byte[] buffer = new byte['Ѐ'];
        
        InputStream is = uc.getInputStream();Throwable localThrowable3 = null;
        try { int bytesRead; while ((bytesRead = is.read(buffer)) > 0) {
            output.write(buffer, 0, bytesRead);
          }
        }
        catch (Throwable localThrowable1)
        {
          localThrowable3 = localThrowable1;throw localThrowable1;
        }
        finally
        {
          if (is != null) if (localThrowable3 != null) try {}catch (Throwable localThrowable2) { localThrowable3.addSuppressed(localThrowable2);
              }
        } } finally { output.close();
      }
      

      if ((digestType != null) && (!remoteHash.isEmpty())) {
        String downloadHash = getFileDigest(new FileInputStream(localZip), digestType);
        if (!remoteHash.equals(downloadHash)) {
          throw new DigestException("Remote digest does not match digest of downloaded file!");
        }
      }
      


      extractZip(localZip, localDir);
      if (localZip.exists()) {
        localZip.delete();
      }
      

      if ((digestType != null) && (!remoteHash.isEmpty())) {
        if (digestFile.exists()) {
          digestFile.delete();
        }
        digestFile.createNewFile();
        PrintWriter out = new PrintWriter(new FileWriter(digestFile));
        out.print(remoteHash);
        out.close();
      }
    }
  }
  
  public static String[] loadTextFromURL(URL url, String[] defaultValue) {
    List<String> arraylist = new ArrayList();
    Scanner scanner = null;
    try {
      URLConnection uc = url.openConnection();
      uc.addRequestProperty("User-Agent", "MMV/1.0.1");
      is = uc.getInputStream();
      scanner = new Scanner(is, "UTF-8");
      
      while (scanner.hasNextLine())
        arraylist.add(scanner.nextLine());
    } catch (Throwable e) {
      InputStream is;
      return defaultValue;
    } finally {
      if (scanner != null) {
        scanner.close();
      }
    }
    return (String[])arraylist.toArray(new String[arraylist.size()]);
  }
  
  public static String[] loadTextFromFile(File file, String[] defaultValue) {
    ArrayList<String> lines = new ArrayList();
    
    Scanner scanner = null;
    try {
      scanner = new Scanner(file);
      while (scanner.hasNextLine()) {
        lines.add(scanner.nextLine());
      }
    } catch (FileNotFoundException e) {
      return defaultValue;
    } finally {
      if (scanner != null) {
        scanner.close();
      }
    }
    
    return (String[])lines.toArray(new String[lines.size()]);
  }
  
  public static String getFileDigest(InputStream is, String digestType) throws NoSuchAlgorithmException, IOException
  {
    MessageDigest md = MessageDigest.getInstance(digestType);
    byte[] dataBytes = new byte['Ѐ'];
    
    int nread = 0;
    
    while ((nread = is.read(dataBytes)) != -1) {
      md.update(dataBytes, 0, nread);
    }
    
    is.close();
    
    byte[] mdbytes = md.digest();
    

    StringBuffer sb = new StringBuffer();
    for (int i = 0; i < mdbytes.length; i++) {
      sb.append(Integer.toString((mdbytes[i] & 0xFF) + 256, 16).substring(1));
    }
    return sb.toString();
  }
  
  public static void extractZip(File zipFile, File destDir) throws IOException {
    byte[] buffer = new byte['Ѐ'];
    if (!destDir.exists()) {
      destDir.mkdirs();
    }
    
    ZipInputStream zis = new ZipInputStream(new FileInputStream(zipFile));
    ZipEntry ze = zis.getNextEntry();
    try {
      while (ze != null) {
        String fileName = ze.getName();
        File newFile = new File(destDir, fileName);
        if (ze.isDirectory()) {
          if (newFile.exists()) {
            deleteDirAndContents(newFile);
          }
          newFile.mkdirs();
        } else {
          if (newFile.exists()) {
            newFile.delete();
          }
          if ((newFile.getParentFile() != null) && (!newFile.getParentFile().exists())) {
            newFile.getParentFile().mkdirs();
          }
          FileOutputStream fos = new FileOutputStream(newFile);
          int len;
          while ((len = zis.read(buffer)) > 0) {
            fos.write(buffer, 0, len);
          }
          
          fos.close();
        }
        ze = zis.getNextEntry();
      }
    } finally {
      zis.closeEntry();
      zis.close();
    }
  }
  
  public static boolean deleteDirAndContents(File dir) {
    if (dir.isDirectory()) {
      String[] children = dir.list();
      for (int i = 0; i < children.length; i++) {
        boolean success = deleteDirAndContents(new File(dir, children[i]));
        if (!success) {
          return false;
        }
      }
    }
    return dir.delete();
  }
}
