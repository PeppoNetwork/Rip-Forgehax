package bspkrs.mmv;

import com.google.gson.Gson;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

























public class VersionFetcher
{
  private final String jsonUrl = "http://export.mcpbot.bspk.rs/versions.json";
  private List<String> versions;
  
  public VersionFetcher() {}
  
  public List<String> getVersions(boolean force) throws IOException { if ((versions == null) || (force)) {
      URL url = new URL("http://export.mcpbot.bspk.rs/versions.json");
      URLConnection connection = url.openConnection();
      connection.addRequestProperty("User-Agent", "MMV/1.0.0");
      BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
      
      Map<String, Object> json = (Map)new Gson().fromJson(br, Map.class);
      
      versions = new ArrayList();
      for (Iterator localIterator1 = json.keySet().iterator(); localIterator1.hasNext();) { mcVer = (String)localIterator1.next();
        for (localIterator2 = ((Map)json.get(mcVer)).keySet().iterator(); localIterator2.hasNext();) { channel = (String)localIterator2.next();
          for (Double ver : (ArrayList)((Map)json.get(mcVer)).get(channel))
            versions.add(mcVer + "_" + channel + "_" + String.format("%.0f", new Object[] { ver })); } }
      String mcVer;
      Iterator localIterator2;
      String channel;
      Collections.sort(versions, Collections.reverseOrder(new SplittedNaturalComparator("_")));
      return versions;
    }
    return versions;
  }
}
