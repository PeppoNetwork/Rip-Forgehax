package bspkrs.mmv;





public class ClassSrgData
  implements Comparable<ClassSrgData>
{
  private final String obfName;
  



  private final String srgName;
  



  private String srgPkgName;
  



  private final boolean isClientOnly;
  



  public static enum SortType
  {
    PKG, 
    OBF;
    


    private SortType() {}
  }
  

  public static SortType sortType = SortType.PKG;
  
  public ClassSrgData(String obfName, String srgName, String srgPkgName, boolean isClientOnly) {
    this.obfName = obfName;
    this.srgName = srgName;
    this.srgPkgName = srgPkgName;
    this.isClientOnly = isClientOnly;
  }
  
  public String getObfName() {
    return obfName;
  }
  
  public String getSrgName() {
    return srgName;
  }
  
  public String getSrgPkgName() {
    return srgPkgName;
  }
  
  public ClassSrgData setSrgPkgName(String pkg) {
    srgPkgName = pkg;
    return this;
  }
  
  public boolean isClientOnly() {
    return isClientOnly;
  }
  
  public String getFullyQualifiedSrgName() {
    return srgPkgName + "/" + srgName;
  }
  
  public int compareTo(ClassSrgData o)
  {
    if (sortType == SortType.PKG) {
      if (o != null) {
        return getFullyQualifiedSrgName().compareTo(o.getFullyQualifiedSrgName());
      }
      return 1;
    }
    if (o != null) {
      if (obfName.length() != obfName.length()) {
        return obfName.length() - obfName.length();
      }
      return obfName.compareTo(obfName);
    }
    
    return 1;
  }
  
  public boolean contains(String s)
  {
    return (srgName.contains(s)) || (obfName.contains(s)) || (srgPkgName.contains(s));
  }
}
