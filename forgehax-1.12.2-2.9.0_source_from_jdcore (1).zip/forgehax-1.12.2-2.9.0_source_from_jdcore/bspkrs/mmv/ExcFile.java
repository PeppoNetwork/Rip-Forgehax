package bspkrs.mmv;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;


























public class ExcFile
{
  public final Map<String, ExcData> srgMethodName2ExcData;
  public final Map<String, ExcData> srgParamName2ExcData;
  
  public ExcFile(File f)
    throws IOException
  {
    srgMethodName2ExcData = new HashMap();
    srgParamName2ExcData = new HashMap();
    






    Scanner in = new Scanner(new FileReader(f));
    try {
      while (in.hasNextLine()) {
        if (in.hasNext("#")) {
          in.nextLine();
        }
        else
        {
          in.useDelimiter("\\.");
          String srgOwner = in.next();
          in.useDelimiter("\\(");
          
          if (!in.hasNext()) {
            if (!in.hasNextLine()) break;
            in.nextLine();
          }
          



          String srgName = in.next().substring(1);
          in.useDelimiter("=");
          String descriptor = in.next();
          in.useDelimiter("\\|");
          String excs = in.next().substring(1);
          String params = in.nextLine().substring(1);
          






          ExcData toAdd = new ExcData(srgOwner, srgName, descriptor, excs.length() > 0 ? excs.split(",") : new String[0], params.length() > 0 ? params.split(",") : new String[0]);
          
          ExcData existing = (ExcData)srgMethodName2ExcData.get(srgName);
          
          if ((existing == null) || 
            (existing.getParameters().length < toAdd.getParameters().length)) {
            srgMethodName2ExcData.put(srgName, toAdd);
            
            for (String parameter : toAdd.getParameters())
              srgParamName2ExcData.put(parameter, toAdd);
          }
        }
      }
    } finally {
      in.close();
    }
  }
}
