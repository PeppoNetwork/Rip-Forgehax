package bspkrs.mmv;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

























public class StaticMethodsFile
{
  private final File file;
  public List<String> staticMethods;
  
  public StaticMethodsFile(File file)
    throws IOException
  {
    this.file = file;
    staticMethods = new ArrayList();
    readFromFile();
  }
  
  public void readFromFile() throws IOException {
    Scanner in = new Scanner(new BufferedReader(new FileReader(file)));
    try {
      while (in.hasNextLine()) {
        staticMethods.add(in.nextLine());
      }
      
      in.close(); } finally { in.close();
    }
  }
  
  public boolean contains(String srgName) {
    return staticMethods.contains(srgName);
  }
}
