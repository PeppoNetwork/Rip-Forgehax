package bspkrs.mmv;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;





























public class ExcData
  implements Comparable<ExcData>
{
  private final String srgOwner;
  private final String srgName;
  private final String descriptor;
  private final String[] exceptions;
  private final String[] parameters;
  private final String[] paramTypes;
  
  public ExcData(String srgOwner, String srgName, String descriptor, String[] exceptions, String[] parameters)
  {
    this.srgOwner = srgOwner;
    this.srgName = srgName;
    this.descriptor = descriptor;
    this.exceptions = exceptions;
    paramTypes = splitMethodDesc(descriptor);
    this.parameters = parameters;
  }
  
  public ExcData(String srgOwner, String srgName, String descriptor, String[] exceptions, boolean isStatic)
  {
    this.srgOwner = srgOwner;
    this.srgName = srgName;
    this.descriptor = descriptor;
    this.exceptions = exceptions;
    paramTypes = splitMethodDesc(descriptor);
    parameters = genParamNames(getSrgId(srgName), paramTypes, isStatic);
  }
  
  public String getSrgClassOwner() {
    return srgOwner;
  }
  
  public String getSrgMethodName() {
    return srgName;
  }
  
  public String getDescriptor() {
    return descriptor;
  }
  
  public String[] getExceptions() {
    return exceptions;
  }
  
  public String[] getParameters() {
    return parameters;
  }
  
  public String[] getParamTypes() {
    return paramTypes;
  }
  
  public boolean contains(String s) {
    if (srgName.contains(s)) {
      return true;
    }
    for (String param : parameters) {
      if (param.contains(s)) {
        return true;
      }
    }
    

    return false;
  }
  
  public int compareTo(ExcData o)
  {
    return srgName.compareTo(srgName);
  }
  
  public static String[] splitMethodDesc(String desc)
  {
    int beginIndex = desc.indexOf('(');
    int endIndex = desc.lastIndexOf(')');
    if (((beginIndex == -1) && (endIndex != -1)) || ((beginIndex != -1) && (endIndex == -1))) {
      System.err.println(beginIndex);
      System.err.println(endIndex);
      throw new RuntimeException(); }
    String x0;
    String x0;
    if ((beginIndex == -1) && (endIndex == -1)) {
      x0 = desc;
    } else {
      x0 = desc.substring(beginIndex + 1, endIndex);
    }
    Pattern pattern = Pattern.compile("\\[*L[^;]+;|\\[[ZBCSIFDJ]|[ZBCSIFDJ]");
    Matcher matcher = pattern.matcher(x0);
    
    ArrayList<String> listMatches = new ArrayList();
    
    while (matcher.find()) {
      listMatches.add(matcher.group());
    }
    
    return (String[])listMatches.toArray(new String[listMatches.size()]);
  }
  
  public static String[] genParamNames(String srgId, String[] paramTypes, boolean isStatic) {
    if (paramTypes.length >= 4) {}
    



    boolean skip2 = (paramTypes[0].equals("Ljava/lang/String;")) && (paramTypes[1].equals(Character.valueOf('I'))) && (paramTypes[0].equals(paramTypes[2])) && (paramTypes[1].equals(paramTypes[3]));
    
    String[] ret = new String[paramTypes.length];
    int idOffset = isStatic ? 0 : 1;
    if (skip2) {
      idOffset += 2;
    }
    
    for (int i = 0; i < paramTypes.length; i++) {
      ret[i] = ("p_" + srgId + "_" + (i + idOffset) + "_");
      if ((paramTypes[i].equals("D")) || (paramTypes[i].equals("J"))) {
        idOffset++;
      }
    }
    
    return ret;
  }
  
  public static String getSrgId(String srgName) {
    Pattern pattern = Pattern.compile("func_(i?[0-9]+)_");
    Matcher matcher = pattern.matcher(srgName);
    if (matcher.find()) {
      return matcher.group(1);
    }
    return srgName;
  }
  
  public String toString()
  {
    return String.format("  Owner: %s\n  SRG Name: %s\n  Descriptor: %s\n  Exceptions: %s\n  Parameters: %s\n  Param Types: %s", new Object[] { srgOwner, srgName, descriptor, 
    



      Arrays.toString(exceptions), 
      Arrays.toString(parameters), 
      Arrays.toString(paramTypes) });
  }
}
