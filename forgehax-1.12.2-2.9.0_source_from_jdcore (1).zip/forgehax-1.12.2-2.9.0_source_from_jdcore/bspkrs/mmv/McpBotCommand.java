package bspkrs.mmv;


public class McpBotCommand
{
  private final BotCommand command;
  
  private final String srgName;
  
  private final String newName;
  
  private final String comment;
  

  public static enum BotCommand
  {
    SF, 
    SM, 
    SP, 
    FSF, 
    FSM, 
    FSP;
    
    private BotCommand() {} }
  
  public static enum MemberType { FIELD, 
    METHOD, 
    PARAM;
    
    private MemberType() {} }
  
  public static BotCommand getCommand(MemberType type, boolean isForced) { switch (1.$SwitchMap$bspkrs$mmv$McpBotCommand$MemberType[type.ordinal()]) {
    case 1: 
      return isForced ? BotCommand.FSM : BotCommand.SM;
    case 2: 
      return isForced ? BotCommand.FSP : BotCommand.SP;
    }
    return isForced ? BotCommand.FSF : BotCommand.SF;
  }
  





  public McpBotCommand(BotCommand command, String srgName, String newName, String comment)
  {
    this.command = command;
    this.srgName = srgName;
    this.newName = newName;
    this.comment = comment;
  }
  
  public McpBotCommand(BotCommand command, String srgName, String newName) {
    this(command, srgName, newName, "");
  }
  
  public static McpBotCommand getMcpBotCommand(MemberType type, boolean isForced, String srgName, String newName, String comment)
  {
    return new McpBotCommand(getCommand(type, isForced), srgName, newName, comment);
  }
  
  public BotCommand getCommand() {
    return command;
  }
  
  public String getNewName() {
    return newName;
  }
  
  public String toString()
  {
    return String.format("!%s %s %s %s", new Object[] {command
      .toString().toLowerCase(), srgName, newName, comment });
  }
}
